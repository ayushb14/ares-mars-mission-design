# Sources

Retrieval date for NAIF index pages and kernel checksums: **2026-10-26**
(Asia/Calcutta). Record a new date if you re-download kernels.

ARES Stage 1 uses only the datasets below. GitHub repositories were not used
as sources of physical truth.

## 1. NASA/JPL NAIF generic kernels

| Field | Value |
| --- | --- |
| Source | NASA/JPL Navigation and Ancillary Information Facility (NAIF) |
| Authority | NASA / JPL |
| Root URL | <https://naif.jpl.nasa.gov/pub/naif/generic_kernels/> |
| What ARES uses | Official leapseconds kernel and DE440 short planetary SPK |
| How to obtain | `python scripts/download_kernels.py` (HTTPS only) |

### 1.1 Leapseconds kernel (LSK)

| Field | Value |
| --- | --- |
| Files | `naif0012.tls` (unix/LF), `naif0012.tls.pc` (Windows/CRLF) |
| URL | <https://naif.jpl.nasa.gov/pub/naif/generic_kernels/lsk/naif0012.tls> |
| README | <https://naif.jpl.nasa.gov/pub/naif/generic_kernels/lsk/aareadme.txt> |
| Used for | UTC → TAI leap-second history consumed by SPICE `str2et` |
| Status | Current LSK as of NAIF announcement 2026-07-18 (IERS Bulletin C 72: no leap second at 2026-12-31; `naif0012.tls` current at least through 2027-07-01) |
| SHA256 (`naif0012.tls`) | `678e32bdb5a744117a467cd9601cd6b373f0e9bc9bbde1371d5eee39600a039b` (computed from the NAIF file downloaded 2026-10-26; NAIF did not publish an LSK MD5 in `aa_checksums.txt`) |
| SHA256 (`naif0012.tls.pc`) | `f15293b0747e5fb01a865596281cb0534f7c77274e78184bd64260cc92be3706` (same retrieval) |

### 1.2 Planetary SPK, DE440 short

| Field | Value |
| --- | --- |
| File | `de440s.bsp` |
| URL | <https://naif.jpl.nasa.gov/pub/naif/generic_kernels/spk/planets/de440s.bsp> |
| Summary | <https://naif.jpl.nasa.gov/pub/naif/generic_kernels/spk/planets/aa_summaries.txt> |
| Checksums | <https://naif.jpl.nasa.gov/pub/naif/generic_kernels/spk/planets/aa_checksums.txt> |
| NAIF MD5 | `3917ee56769db332790c751e2168843d` (verified on download 2026-10-26) |
| SHA256 (computed) | `c1c7feeab882263fc493a9d5a5b2ddd71b54826cdf65d8d17a76126b260a49f2` |
| Size | 32 726 016 bytes |
| Coverage (ET) | 1849 DEC 26 00:00:00.000 — 2150 JAN 22 00:00:00.000 |
| Bodies used | Sun (10), Earth body (399), Mars barycenter (4); also EMB (3), Moon (301) |
| Not present | Mars body center (499) |
| Used for | Heliocentric geometric states via SPICE `spkezr` |

Technical comments for the parent ephemeris DE440:

- <https://naif.jpl.nasa.gov/pub/naif/generic_kernels/spk/planets/de440_tech-comments.txt>

Peer-reviewed description of DE440/DE441:

- Park, R. S., Folkner, W. M., Williams, J. G., & Boggs, D. H. (2021). The JPL Planetary and Lunar Ephemerides DE440 and DE441. *The Astronomical Journal*, 161, 105. <https://doi.org/10.3847/1538-3881/abd414>

NAIF also publishes `de442s.bsp` (integrated 2024-05-13; primarily a Uranus update with additional Mars/Juno ranging). Stage 1 uses **DE440s** because it is the documented DE440 short kernel with a published MD5 and the Park et al. (2021) reference. Switching ephemerides is a later, explicit decision.

## 2. NAIF SPICE documentation

| Document | URL | Used for |
| --- | --- | --- |
| `spkezr_c` | <https://naif.jpl.nasa.gov/pub/naif/toolkit_docs/C/cspice/spkezr_c.html> | State-vector API, units km and km/s, abcorr `NONE` |
| `str2et` | <https://naif.jpl.nasa.gov/pub/naif/toolkit_docs/C/cspice/str2et_c.html> | UTC/calendar string → ET (TDB seconds past J2000). NAIF recommends `str2et` over `utc2et`. |
| `utc2et` | <https://naif.jpl.nasa.gov/pub/naif/toolkit_docs/C/cspice/utc2et_c.html> | Historical UTC converter; not called by ARES |
| NAIF IDs | <https://naif.jpl.nasa.gov/pub/naif/toolkit_docs/C/req/naif_ids.html> | Body integer codes 10, 399, 4, 499 |
| SPK required reading | <https://naif.jpl.nasa.gov/pub/naif/toolkit_docs/C/req/spk.html> | Geometric vs aberration-corrected states |
| Kernel required reading | <https://naif.jpl.nasa.gov/pub/naif/toolkit_docs/C/req/kernel.html> | `furnsh` / `kclear` |
| Time required reading | <https://naif.jpl.nasa.gov/pub/naif/toolkit_docs/C/req/time.html> | ET/TDB, LSK role |
| NAIF announcements | <https://naif.jpl.nasa.gov/naif/announcements.html> | LSK currency through 2026/2027 |

## 3. SpiceyPy (Python interface to CSPICE)

| Field | Value |
| --- | --- |
| Authority | SpiceyPy project; wraps official NAIF CSPICE |
| Docs | <https://spiceypy.readthedocs.io/> |
| Used for | Python bindings: `furnsh`, `str2et`, `spkezr`, `bodn2c`, `kclear` |
| Role | Interface only. Physical content comes from NAIF kernels + CSPICE. |

## 4. JPL Horizons (independent validation source)

| Field | Value |
| --- | --- |
| Authority | NASA/JPL Solar System Dynamics |
| Manual | <https://ssd.jpl.nasa.gov/horizons/manual.html> |
| HTTP API | <https://ssd.jpl.nasa.gov/api/horizons.api> |
| API doc | <https://ssd-api.jpl.nasa.gov/doc/horizons.html> |
| Used for | Independent state-vector comparison. Not used as a runtime ephemeris. |

Exact query configuration: `docs/VALIDATION.md`.

## 5. Defining constants (not ephemeris)

| Quantity | Value | Authority |
| --- | --- | --- |
| Astronomical unit | 149 597 870 700 m exactly | IAU 2012 Resolution B2, <https://iauarchive.eso.org/static/resolutions/IAU2012_English.pdf> |
| Speed of light | 299 792 458 m/s exactly | SI defining constant; NIST CODATA <https://physics.nist.gov/cgi-bin/cuu/Value?c> |
| TT − TAI | 32.184 s exactly | IAU definition of TT; NAIF LSK `DELTET/DELTA_T_A` |
| GM_Sun | 132712440041.279419 km³/s² | Park et al. (2021) AJ 161:105 Table 2; NAIF `de440_tech-comments.txt` GMS; NAIF `gm_de440.tpc` BODY10_GM |

## 6. NSSDCA planetary fact sheets (sanity envelopes only)

These are **not** used to compute states. Tests use perihelion, aphelion, and
min/max orbital speed as physically-meaningful bounds.

| Body | URL | Quantities |
| --- | --- | --- |
| Earth | <https://nssdc.gsfc.nasa.gov/planetary/factsheet/earthfact.html> | perihelion 147.095×10⁶ km, aphelion 152.100×10⁶ km, orbital speed 29.29–30.29 km/s |
| Mars | <https://nssdc.gsfc.nasa.gov/planetary/factsheet/marsfact.html> | perihelion 206.650×10⁶ km, aphelion 249.261×10⁶ km, orbital speed 21.97–26.50 km/s |

Curator stated on those pages: Dr. David R. Williams, NSSDCA, NASA GSFC.

## 7. Lambert solver (interface only)

| Field | Value |
| --- | --- |
| Package | `lamberthub` 1.0.0 (PyPI) |
| Docs | <https://pypi.org/project/lamberthub/> |
| Function | `izzo2015(mu, r1, r2, tof, M=0, prograde=True, low_path=True, maxiter, atol, rtol)` — signature taken from the installed package, not from memory |
| Algorithm paper | Izzo, D. (2015). Revisiting Lambert’s problem. *Celestial Mechanics and Dynamical Astronomy*, 121(1), 1–15. <https://doi.org/10.1007/s10569-014-9587-y> |
| Units | Solver is unit-agnostic; ARES passes km, s, km³/s² and reads km/s |
| Role | Numerical Lambert solver. ARES validates inputs, selects M=0/prograde, and independently checks the solution by two-body propagation. |
| Not used | poliastro as a dependency (archived). lamberthub’s Izzo code historically descends from poliastro; ARES treats Izzo (2015) as the algorithm authority. |

## 8. Two-body integrator

| Field | Value |
| --- | --- |
| Package | SciPy `scipy.integrate.solve_ivp` |
| Method | DOP853 (Dormand–Prince 8(7)) |
| Docs | <https://docs.scipy.org/doc/scipy/reference/generated/scipy.integrate.solve_ivp.html> |
| Used for | Independent Lambert endpoint check under \(\ddot r = -\mu r/\|r\|^3\) |

## 9. NASA Earth→Mars mission-design handbook (validation comparison)

| Field | Value |
| --- | --- |
| Document | NASA/TM-2010-216764 |
| Title | Interplanetary Mission Design Handbook: Earth-to-Mars Mission Opportunities 2026 to 2045 |
| Authors | Burke, L. M., Falck, R. D., and McGuire, M. L. |
| Date | October 2010 |
| Center | NASA Glenn Research Center |
| NTRS | <https://ntrs.nasa.gov/citations/20100037210> |
| PDF | <https://ntrs.nasa.gov/api/citations/20100037210/downloads/20100037210.pdf> |
| Used for | Independent comparison of 2026 Type I/II energy minima (C3, dates, Mars arrival \(v_\infty\)). **Not** a runtime data source. ARES does not ingest MIDAS output. |

MIDAS (the program that generated those contours) is a patched-conic
interplanetary optimizer. ARES Stage 3 is a heliocentric two-body Lambert
grid on DE440 geometric states. See `docs/VALIDATION.md` for what is
compared and what is not.

NSSDCA semimajor axes used only to **document** the Hohmann TOF scale
(~259 days) that motivates the 100–500 day TOF gate:

| Body | SMA (\(10^6\) km) | URL |
| --- | --- | --- |
| Earth | 149.598 | <https://nssdc.gsfc.nasa.gov/planetary/factsheet/earthfact.html> |
| Mars | 227.956 | <https://nssdc.gsfc.nasa.gov/planetary/factsheet/marsfact.html> |

## 10. Plotly (visualization only)

| Field | Value |
| --- | --- |
| Package | `plotly` (PyPI) |
| Used for | Interactive porkchop HTML. Does not compute C3, Lambert, or SPICE states. |

## 11. Intentionally not used

- Approximate circular/Keplerian planetary orbits as production ephemeris
- poliastro as a core dependency
- NASA GMAT (later independent trajectory check)
- PCK / body-fixed frames
- Satellite SPKs as production kernels. Official `mar099s.bsp` (NAIF MD5
  `fd7302dfbaa0c63ce85b1e98923ee6a1`,
  <https://naif.jpl.nasa.gov/pub/naif/generic_kernels/spk/satellites/mar099s.bsp>)
  was loaded **once** for a 4 vs 499 audit (see `docs/VALIDATION.md`). It is
  not a Stage 1–3 runtime dependency and is not stored in this repository.
- Horizons as a production data source
- Launch-vehicle ΔV, MOI ΔV
- Deep-space maneuvers / broken-plane burns
- Stage 4+ (EDL, landing, habitat)
