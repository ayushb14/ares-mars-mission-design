# Physics — Stages 1, 2, and 3

ARES Stage 1 does **not** implement an independent planetary ephemeris.
It loads official NASA/JPL NAIF kernels and asks CSPICE (via SpiceyPy) for
geometric state vectors.

If a formula below is implemented inside ARES, the implementation location
is named. Formulas executed inside CSPICE are identified as such; ARES
does not re-code them.

## 1. Units and frames

Internal units:

| Quantity | Unit |
| --- | --- |
| Distance | km |
| Velocity | km/s |
| Time | seconds |
| Angles | radians (unused in Stage 1) |
| Mass | kg (unused in Stage 1) |

SPICE `spkezr` returns km and km/s. ARES does not convert those outputs.

Default geometry request:

| Item | Value | Meaning |
| --- | --- | --- |
| Target (Earth) | `EARTH` / NAIF 399 | Earth body center, not the Earth-Moon barycenter (3) |
| Target (Mars) | `MARS BARYCENTER` / NAIF 4 | Mars+moons barycenter. Body 499 is **not** in `de440s.bsp` |
| Observer | `SUN` / NAIF 10 | Heliocentric. Not solar-system barycenter (0) |
| Frame | `J2000` | SPICE built-in inertial frame |
| Aberration | `NONE` | Geometric state; no light-time, no stellar aberration |
| Time input | UTC | Converted to ET/TDB by SPICE |
| Time at observer | ET (TDB seconds past J2000) | SPICE `spkezr` epoch |

These four states are **not** interchangeable:

- heliocentric = relative to Sun (10)
- barycentric = relative to SSB (0)
- planet-centered = relative to a planet body or barycenter
- body-fixed = rotating with a planet (requires a PCK; not loaded)

Requesting a body-fixed frame in Stage 1 raises `EphemerisError`.

### 1.1 J2000 and ICRF

Park et al. (2021) state that DE440/DE441 are aligned to the International
Celestial Reference Frame (ICRF). ARES requests the SPICE frame name `J2000`
and does **not** apply a separate J2000↔ICRF rotation.

For a Horizons comparison use `REF_SYSTEM=ICRF` and `REF_PLANE=FRAME`
(ICRF equatorial axes), not the ecliptic plane.

`ECLIPJ2000` is available as an explicit opt-in (mean ecliptic of J2000).
It is a rotation of the same geometric vector; radius is unchanged.

### 1.2 Reference bodies (NAIF targets)

Verified against NAIF IDs Required Reading
(<https://naif.jpl.nasa.gov/pub/naif/toolkit_docs/C/req/naif_ids.html>)
and the DE440s body list in `aa_summaries.txt`. Runtime confirmation:
`spkobj(de440s.bsp)` and SpiceyPy `bodn2c`.

| NAIF ID | Name | In `de440s.bsp`? | ARES Lambert role |
| --- | --- | --- | --- |
| 10 | `SUN` | yes (w.r.t. SSB 0) | **observer / center** of every heliocentric vector |
| 399 | `EARTH` | yes (w.r.t. EMB 3) | **Earth endpoint** — body center / geocenter |
| 3 | `EARTH BARYCENTER` / EMB | yes (w.r.t. SSB 0) | **not used** for Lambert |
| 4 | `MARS BARYCENTER` | yes (w.r.t. SSB 0) | **Mars endpoint** — Mars+Phobos+Deimos barycenter |
| 499 | `MARS` | **no** | Mars body center; not available in Stage 1 kernels |
| 0 | `SOLAR SYSTEM BARYCENTER` | via chain | **not** the Lambert observer |

SPICE `spkezr` is called as target relative to observer `SUN` in frame
`J2000` with `abcorr=NONE`. That is heliocentric geometric, not
barycentric (SSB) and not planetocentric.

**Why 399, not 3.** Earth-relative \(v_\infty\) and \(C_3\) are defined
with respect to Earth's mass center (the body that owns the SOI in a
patched-conic departure). EMB (3) is offset from 399 by ~4 500 km and
~0.013 km/s (Moon). Using 3 would be a different physical problem.

**Why 4, not 499.** `de440s.bsp` has no 499 segment. NAIF planetary SPKs
store Mars system barycenter (4) w.r.t. SSB and do not include Mars body
w.r.t. that barycenter; 499 lives in a satellite SPK (e.g. `mar099s.bsp`).
ARES does not load satellite SPKs in production and does not silently
substitute 499 when 4 is requested.

The 4 vs 499 offset is **not** tens of km. Phobos SMA ~9378 km times
\(m_{\mathrm{Phobos}}/M_{\mathrm{Mars}} \approx 1.65\times10^{-8}\) is
~0.15 m. Direct SPICE comparison with official `mar099s.bsp` (audit only;
NAIF MD5 `fd7302dfbaa0c63ce85b1e98923ee6a1`) gives |Δr| ≈ 0.00012–0.00020 km
and |Δv| ≈ \(3\times10^{-8}\) km/s at the 2026/27 epochs. That change in
C3 is ~10⁻¹¹ km²/s². Production therefore keeps NAIF 4, labelled as
**system barycenter**, not as Mars body center.

## 2. Time: UTC → ET (TDB)

**Implemented in:** `ares.time.utc_to_et` (calls SpiceyPy `str2et`).

ARES validates the civil timestamp, then passes CSPICE a space-separated
calendar string ``YYYY-MM-DD HH:MM:SS.ffffff UTC``. CSPICE N0067 rejects
ISO-8601 strings that combine the ``T`` delimiter with a trailing ``UTC``
token (`SPICE(UNPARSEDTIME)`).

| Symbol | Meaning | Unit |
| --- | --- | --- |
| UTC | Coordinated Universal Time, civil input | calendar |
| TAI | International Atomic Time | SI seconds |
| TT | Terrestrial Time | SI seconds |
| ET / TDB | SPICE ephemeris time = Barycentric Dynamical Time | seconds past J2000 TDB |
| ΔAT | TAI − UTC | integer seconds (leap seconds) |

ARES does not evaluate leap seconds or the TDB periodic term itself.
CSPICE reads them from `naif0012.tls`. The LSK header documents the model
CSPICE uses (NAIF `DELTET`):

1. `ΔAT = TAI − UTC` from the leap-second table.
2. `TT − TAI = 32.184 s` (`DELTET/DELTA_T_A`).
3. A small periodic term approximates `TDB − TT` (LSK symbols `K`, `EB`, `M0`, `M1`). The LSK states that this approximation of `ET − TAI` is accurate to about 3×10⁻⁵ s.

**Assumptions**

- Input strings are UTC. Non-UTC offsets are rejected.
- The leap-second table in `naif0012.tls` is complete for the requested date.
  IERS Bulletin C 72 / NAIF 2026-07-18: no leap second at 2026-12-31.
- Dates outside DE440s coverage will fail at the SPK lookup, not at time
  conversion.

**Limitations**

- Pre-1972 UTC is a different system; Stage 1 mission dates are modern.
- ARES does not convert TT or TDB input strings. Pass UTC.

**Reference:** NAIF `str2et` / `time.req`; `naif0012.tls` header.

## 3. Geometric state vector

**Implemented in:** `ares.ephemeris.state` (calls SpiceyPy `spkezr`).

SPICE computes the state of target *T* relative to observer *O* at observer
epoch `et`:

\[
\mathbf{r}_{T/O}(\mathrm{et}) = \mathbf{r}_{T/\mathrm{SSB}} - \mathbf{r}_{O/\mathrm{SSB}}
\]

\[
\mathbf{v}_{T/O}(\mathrm{et}) = \mathbf{v}_{T/\mathrm{SSB}} - \mathbf{v}_{O/\mathrm{SSB}}
\]

by chaining SPK segments (DE440s stores planet barycenters w.r.t. SSB, Earth
and Moon w.r.t. EMB, Sun w.r.t. SSB). ARES does not interpolate Chebyshev
coefficients; CSPICE does.

| Symbol | Meaning | Unit |
| --- | --- | --- |
| \(\mathbf{r}\) | Cartesian position, observer → target | km |
| \(\mathbf{v}\) | d\(\mathbf{r}\)/dt in the requested inertial frame | km/s |
| `lt` | one-way light time returned by `spkezr` | s |

With `abcorr=NONE`, `lt` is the geometric range over the speed of light
(SPICE `spkezr` documentation). ARES checks this against

\[
c = 299\,792.458\,\mathrm{km\,s^{-1}}
\]

(SI defining value 299 792 458 m/s).

**Assumptions**

- `abcorr=NONE` is the correct default for patched-conic / Lambert mission
  design (geometric states, not apparent planet directions).
- Earth = body 399 (geocenter), never EMB 3.
- Mars = system barycenter 4 because 499 is absent from `de440s.bsp`.
  Callers see `target_id = 4`. The 4↔499 offset is ~0.2 m (see §1.2),
  not tens of kilometres.

**Limitations**

- No light-time iteration unless the caller passes a non-default `abcorr`.
- No relativistic aberration beyond what CSPICE implements for the chosen flag.
- Heliocentric, not barycentric. SSB-relative states require `observer='SSB'`
  via the generic `state()` function; they are not the Stage 1 default.
- Coverage limited to DE440s: 1849–2150.

**Reference:** NAIF `spkezr_c`; Park et al. (2021); NAIF `aa_summaries.txt`.

## 4. What Stage 1 does not model

Stage 1 stops at planetary states. Rocket equation, n-body spacecraft
propagation, GMAT, atmospheres, and EDL are **not implemented**. The
Earth→Mars launch-window grid is Stage 3 (`ares.porkchop`) and reuses
Stage 1 states unchanged.

## 5. Solar gravitational parameter

**Stored in:** `ares.constants.GM_SUN_KM3_S2`

\[
\mu_{\odot} = 132712440041.279419\,\mathrm{km}^{3}\,\mathrm{s}^{-2}
\]

**Source:** Park et al. (2021), *The Astronomical Journal* 161:105, Table 2
(“GMSun … estimated from DE440”). The same digits appear as `GMS` in
`de440_tech-comments.txt` (column KM**3/SEC**2) and as `BODY10_GM` in NAIF
`gm_de440.tpc` (`1.3271244004127942E+11` km³/s², the float64 rendering).

ARES does not mix this with au³/day². All Lambert and two-body work uses
km³/s².

## 6. Lambert's problem

**Implemented in:** `ares.lambert.solve_lambert` (calls `lamberthub.izzo2015`).

Given \(\mathbf{r}_1\), \(\mathbf{r}_2\) (km) and \(\Delta t > 0\) (s) about a
point-mass Sun with \(\mu_{\odot}\), find inertial velocities \(\mathbf{v}_1\),
\(\mathbf{v}_2\) (km/s) of the unique two-body conic that passes through both
positions in that time, for a chosen branch.

Stage 2 branch (explicit, not an undocumented default):

| Parameter | Value | Meaning |
| --- | --- | --- |
| \(M\) | 0 | zero extra revolutions (direct transfer) |
| `prograde` | `True` | transfer angular momentum has positive frame-\(Z\) |
| `low_path` | `True` | unused at \(M=0\) (lamberthub user guide) |

`prograde` follows Izzo / lamberthub: the \(z\)-component of
\(\hat{r}_1\times\hat{r}_2\) is used to orient the transfer in the input
inertial frame. Stage 2’s frame is SPICE `J2000`. Earth and Mars heliocentric
motion is prograde about this \(+Z\), so this is the ordinary Earth→Mars sense.

If that sense requires a transfer angle \(>\pi\), ARES keeps it (Type II /
long-way). It does **not** switch to retrograde to shorten the angle.

**Assumptions**

- Two-body: Sun is the only gravity on the spacecraft.
- Positions come from SPICE (n-body planets); the *spacecraft* path is two-body.
- Geometric states (`abcorr=NONE`), same frame for \(\mathbf{r}\) and \(\mathbf{v}\).

**Limitations**

- Not n-body cruise. Planetary perturbations, SRP, TCMs, finite burns,
  spacecraft mass, non-spherical gravity, launch-site geometry, and atmosphere
  are neglected.
- \(M=0\) only. Multi-revolution transfers are rejected.
- Collinear \(\mathbf{r}_1,\mathbf{r}_2\) (0° or 180°) is rejected: no unique plane.

**Reference:** Izzo (2015), *Celestial Mechanics and Dynamical Astronomy* 121:1–15.
Implementation: lamberthub 1.x `izzo2015` (API verified from the installed
package). ARES does not re-code Izzo.

## 7. Hyperbolic excess velocity and C3

**Implemented in:** `ares.energetics`.

\[
\mathbf{v}_{\infty,\mathrm{E}} = \mathbf{v}_{1,\mathrm{transfer}} - \mathbf{v}_{\mathrm{Earth}}(t_0)
\]

\[
\mathbf{v}_{\infty,\mathrm{M}} = \mathbf{v}_{2,\mathrm{transfer}} - \mathbf{v}_{\mathrm{Mars}}(t_1)
\]

\[
C_3 = |\mathbf{v}_{\infty,\mathrm{E}}|^{2}
\]

| Quantity | Unit | What it is **not** |
| --- | --- | --- |
| \(\mathbf{v}_\infty\) | km/s | not launch-vehicle ΔV |
| \(C_3\) | km²/s² | not Mars orbit-insertion ΔV |

No parking orbit or launch vehicle is assumed, so those ΔV values are not
computed.

## 8. Two-body propagation check

**Implemented in:** `ares.trajectory.propagate_two_body`.

\[
\ddot{\mathbf{r}} = -\mu_{\odot}\,\mathbf{r}/|\mathbf{r}|^{3}
\]

Integrated with `scipy.integrate.solve_ivp`, method **DOP853**
(Dormand–Prince 8(7)), `rtol=1e-12`, `atol=1e-9` (state in km and km/s).

Initial condition: \(\mathbf{r}(t_0)=\mathbf{r}_{\mathrm{Earth}}(t_0)\),
\(\mathbf{v}(t_0)=\mathbf{v}_{1,\mathrm{transfer}}\).
Compare \(\mathbf{r}(t_0+\Delta t)\) to \(\mathbf{r}_{\mathrm{Mars}}(t_1)\).

Tolerance: \(|\Delta\mathbf{r}| \le 1\,\mathrm{km}\).

Justification: \(1\times10^{-12}\) relative on \(|\mathbf{r}|\sim 1.5\times10^{8}\,\mathrm{km}\)
is a ~0.15 m local scale; 1 km is a verification ceiling for the *same*
two-body model Lambert solved, not a fit to n-body Mars.

This check confirms the Lambert velocities, not that the path is a real
spacecraft trajectory.

## 9. Porkchop (launch-window) grid

**Implemented in:** `ares.porkchop.compute_porkchop`

Stage 3 does **not** introduce a second Lambert solver, a second C3 formula,
or a second ephemeris. For each grid node it calls the same
`lambert_energetics` path used by `compute_earth_mars_transfer` (without the
DOP853 endpoint check, which is a per-trajectory verification, not a
grid metric).

### 9.1 Date-grid formulation

UTC civil dates are generated by `utc_date_grid(start, end, step_days)`:

- start and end are inclusive
- step is a positive number of SI days (`SECONDS_PER_DAY = 86400`)
- if `end` does not fall on a step, it is appended so both bounds appear
- a pair with arrival epoch ≤ departure epoch is **not** solved

Shape of every data array: `(n_departure, n_arrival)`.

Default exploratory search (not an asserted optimum):

| Bound | Default | Role |
| --- | --- | --- |
| Earth departure | 2026-07-01 → 2027-03-01 UTC | covers the 2026 Mars opportunity |
| Mars arrival | 2027-03-01 → 2028-06-01 UTC | covers Type I and Type II arrivals |
| Step | 5 days | coarse scan; finer grids are opt-in |
| Min TOF | 100 days | see §9.2 |
| Max TOF | 500 days | see §9.2 |

Smaller step → higher resolution + more Lambert solves + more CPU.
A 5-day coarse grid of these bounds is 50 × 93 = 4650 potential cells.
Optional `refine_around` rebuilds a 1-day grid in a window about one
coarse-grid candidate.

### 9.2 Time-of-flight constraints

A cell is solved only if

\[
t_{\min} < t_{\mathrm{arrival}} - t_{\mathrm{departure}} < t_{\max}
\]

on the TDB (ET) scale. Outside that gate the cell is `skipped_tof` with
**NaN** metrics (never 0; C3 = 0 would be a real Hohmann-limit case).

**Why 100–500 days**

Circular-coplanar Hohmann Earth→Mars TOF is

\[
\Delta t_{\mathrm{H}} = \pi\sqrt{a_t^3/\mu_{\odot}},\quad
a_t = (a_E + a_M)/2
\]

Using NSSDCA fact-sheet semimajor axes \(a_E = 149.598\times10^6\,\mathrm{km}\),
\(a_M = 227.956\times10^6\,\mathrm{km}\) and DE440 \(\mu_{\odot}\) gives
\(a_t = 188.777\times10^6\,\mathrm{km}\) and \(\Delta t_{\mathrm{H}} \approx 258.88\) days
(~259 days). That is a scale check, not the ARES transfer model.

NASA/TM-2010-216764 displays ballistic Earth→Mars TOFs from **100 to 450
days** on its 2026–2045 porkchop plots. ARES defaults **100–500 days** as a
slightly broader exploratory envelope that admits M=0 Type I (~180°) and
Type II (>180°) transfers without opening multi-revolution (M≥1) branches.
The limits are configurable; they are not a claim about vehicle capability.

### 9.3 Cached planetary states

Earth heliocentric state is computed once per departure epoch.
Mars heliocentric state is computed once per arrival epoch.
Lambert then uses those cached \((\mathbf{r},\mathbf{v})\) vectors. This
avoids repeating SPICE `spkezr` on the Cartesian product.

### 9.4 C3 on the grid

Unchanged from Stage 2:

\[
C_3 = |\mathbf{v}_{\infty,\mathrm{Earth}}|^2
\quad(\mathrm{km}^2\,\mathrm{s}^{-2})
\]

\(C_3\) is characteristic energy. It is **not** launch ΔV.
Earth \(v_\infty\) is **not** pad ΔV.
Mars \(v_\infty\) is **not** MOI ΔV.

Invalid / failed cells: `valid=False`, `status` in
`{skipped_tof, lambert_failed, ephemeris_failed}`, metrics = NaN.
A Lambert exception on one cell does not abort the grid.

### 9.5 Candidates

Extrema over valid cells, named precisely, never “best mission”:

- Minimum C3 Candidate
- Minimum Earth v∞ Candidate (identical cell to min C3, because \(C_3=|v_\infty|^2\))
- Minimum Arrival v∞ Candidate
- Shortest TOF Candidate

Optional filters (`max_c3`, `max_mars_vinf`, TOF bounds) restrict the
search. They are user-supplied numbers, not launch-vehicle performance.

### 9.6 Plot

Plotly heatmap of sampled C3 with contour lines as a **visualization aid**.
Contour interpolation is not written back to the CSV. Color scale may be
clipped at 50 km²/s² for display (NASA/TM-2010-216764 treated C3 > 50 as
generally not of interest); stored values are unclipped.

## 10. Model assumptions (Stage 3)

- Same two-body Sun, same DE440 geometric states, same Izzo M=0 prograde
  Lambert as Stage 2.
- Serial evaluation. No multiprocessing.
- Grid sampling: the true continuous minimum may lie between nodes.
  Use `refine_around` (1-day) after a coarse scan.

## 11. Interpretation limitations

- Not n-body cruise, not finite burns, not launch-vehicle C3 capability.
- Not a full mission optimizer (no mass, no MOI, no DSM, no launch site).
- NASA porkchop products (MIDAS, etc.) may include patched-conic
  planetocentric legs, different ephemerides, and 2-day / 0.01 C3
  rounding. Agreement is expected in **opportunity location and relative
  C3 structure**, not bit-identical contours.
- Shortest-TOF extrema often sit on the TOF floor and have huge C3;
  they are listed for completeness, not as recommended missions.

## 12. Stage 4 application (no additional physics)

The FastAPI service (`src/ares/api/`) and the React workspace (`frontend/`)
serialize and display Stage 1–3 results. They do not implement Lambert,
C3, \(v_\infty\), SPICE, time conversion, or two-body propagation.
Trajectory plots are DOP853 samples of the same Lambert arc used in Stage 2.
Porkchop plots are the Stage 3 grid. Selecting a cell recomputes Stage 2
through `compute_earth_mars_transfer`; the chart is not interpolated.
