# Validation — Stage 1

ARES using NAIF kernels is **not** the same as “NASA validated.”
Kernels supply the ephemeris; tests check that ARES called SPICE correctly
and that results are physically plausible. Independent numerical comparison
is JPL Horizons, recorded below when a query has been executed.

Legend: **PASS** / **FAIL** / **PENDING**.

## 1. Automated tests (pytest)

Run from the repository root after installing the package and kernels:

```text
python -m pytest
```

| Quantity | ARES result | Reference | Abs. diff | Rel. diff | Tolerance | Status | Reference source |
| --- | --- | --- | --- | --- | --- | --- | --- |
| IAU au in km | `AU_KM * 1000 = 149597870700` | 149 597 870 700 m exactly | 0 | 0 | exact | PASS if pytest passes | IAU 2012 Res. B2 |
| ET at 2000-01-01 12:00:00 UTC | `utc_to_et` | 64.184 s + (TDB−TT) | < 0.002 s | — | 0.002 s | PASS if pytest passes | naif0012.tls ΔAT=32; TT−TAI=32.184 s; LSK K=1.657e-3 s |
| ΔET over one UTC day (no leap second) | `et(Nov 1)−et(Oct 31)` 2026 | 86400 s | < 0.001 s | — | 0.001 s | PASS if pytest passes | SI day; LSK periodic term ≪ 1 ms/day |
| Earth–Sun distance 2026-10-31 | `earth.radius_km` | NSSDCA peri/aphelion 147.095–152.100 million km | inside envelope | — | ±2% of (aph−per) | PASS if pytest passes | NSSDCA Earth fact sheet |
| Mars–Sun distance 2026-10-31 | `mars.radius_km` | NSSDCA peri/aphelion 206.650–249.261 million km | inside envelope | — | ±2% of (aph−per) | PASS if pytest passes | NSSDCA Mars fact sheet |
| Geometric light time | `lt` | `\|r\|/c` with c = 299792.458 km/s | rel < 1e-12 | < 1e-12 | 1e-12 | PASS if pytest passes | SI *c*; NAIF `spkezr` NONE |
| Epoch sensitivity | Δr over 1 day | v_min×86400 … v_max×86400 | inside envelope | — | ±2% on v | PASS if pytest passes | NSSDCA min/max orbital speed |
| Mars target ID | 4 | DE440s body list | 0 | 0 | exact | PASS if pytest passes | NAIF `aa_summaries.txt` |
| Mars 499 request | exception | insufficient SPK data | — | — | must raise | PASS if pytest passes | NAIF `aa_summaries.txt` (499 absent) |

These tests do **not** replace Horizons.

## 2. Independent Horizons comparison

**Status: PENDING** until a Horizons vector table is obtained for the same
configuration. Do not paste guessed numbers here.

### 2.1 Why this is PENDING (2026-10-26)

ARES must not invent a Horizons value. On 2026-10-26 the JPL Horizons HTTP
API (`https://ssd.jpl.nasa.gov/api/horizons.api`) returned a **server-side**
failure, not a usable vector table:

```text
API VERSION: 1.2
API SOURCE: NASA/JPL Horizons API

wldini(): missing required file LTKERNL

 ERROR in VLRDC: Var not declared: IP_ADDR
```

No Horizons state vector is recorded. Re-run the URLs in §2.3 when Horizons
is healthy and fill §2.4. The web form at
<https://ssd.jpl.nasa.gov/horizons/app.html> is the same configuration if
the API remains down.

### 2.2 Configuration that matches ARES defaults

| ARES | Horizons |
| --- | --- |
| UTC 2026-10-31 00:00:00 | `TIME_TYPE=UT`, calendar `2026-10-31 00:00:00` |
| Frame `J2000` / DE440-ICRF | `REF_SYSTEM=ICRF`, `REF_PLANE=FRAME` |
| Units km, km/s | `OUT_UNITS=KM-S` |
| Geometric | `VEC_CORR=NONE` |
| Observer Sun (10) | `CENTER='@10'` |
| Earth body (399) | `COMMAND='399'` |
| Mars barycenter (4) | `COMMAND='4'` |

Do **not** use Horizons default `REF_PLANE=ECLIPTIC` if you are comparing to
ARES `J2000`. Do **not** use `COMMAND='499'` if you are comparing to ARES
Mars (barycenter 4). Do **not** omit `TIME_TYPE=UT` (vector tables can
default to TDB).

### 2.3 Exact API URLs

Earth (399) relative to Sun (10):

```text
https://ssd.jpl.nasa.gov/api/horizons.api?format=text&COMMAND='399'&OBJ_DATA='NO'&MAKE_EPHEM='YES'&EPHEM_TYPE='VECTORS'&CENTER='@10'&REF_PLANE='FRAME'&REF_SYSTEM='ICRF'&OUT_UNITS='KM-S'&VEC_TABLE='2'&VEC_CORR='NONE'&CAL_TYPE='GREGORIAN'&TIME_TYPE='UT'&TLIST='2026-10-31 00:00:00'&TLIST_TYPE='CAL'
```

Mars barycenter (4) relative to Sun (10):

```text
https://ssd.jpl.nasa.gov/api/horizons.api?format=text&COMMAND='4'&OBJ_DATA='NO'&MAKE_EPHEM='YES'&EPHEM_TYPE='VECTORS'&CENTER='@10'&REF_PLANE='FRAME'&REF_SYSTEM='ICRF'&OUT_UNITS='KM-S'&VEC_TABLE='2'&VEC_CORR='NONE'&CAL_TYPE='GREGORIAN'&TIME_TYPE='UT'&TLIST='2026-10-31 00:00:00'&TLIST_TYPE='CAL'
```

Web-form equivalent: <https://ssd.jpl.nasa.gov/horizons/app.html>

- Ephemeris type: **Vector Table**
- Target: `399` then `4`
- Coordinate center: `@10` (Sun)
- Time: `2026-10-31 00:00:00`, calendar, **UT**
- Reference plane: **frame** (ICRF)
- Output units: **km/s**
- Aberration corrections: **NONE**
- Vector table: position + velocity

Record the Horizons `Ephemeris Type` source line (e.g. DE441 vs DE440).
A mismatch of DE version is a real difference, not an ARES bug. Expected
agreement for DE440 vs DE441 Earth/Mars at this epoch is at the meter-to-
kilometer level for position **UNVERIFIED** until measured; do not treat
that sentence as a pass criterion.

### 2.4 Comparison table (fill after Horizons returns)

Example epoch: **2026-10-31 00:00:00 UTC**

ARES results are written here only after `python -m ares.ephemeris` is run
on this repository. Horizons columns stay empty until a real query returns.

ARES numbers below are from `python -m ares.ephemeris --date "2026-10-31T00:00:00"`
on this repository (DE440s, `naif0012.tls`, SpiceyPy/CSPICE N0067). They are
**not** Horizons numbers.

#### Earth (399) wrt Sun (10), J2000 / ICRF-frame, geometric, km and km/s

| Component | ARES | Horizons | Abs. diff | Rel. diff | Tolerance | Pass/Fail | Horizons source |
| --- | --- | --- | --- | --- | --- | --- | --- |
| X km | 1.1830853943129119e+08 | PENDING | — | — | 1 km (same DE); record DE if different | PENDING | Horizons API error 2026-10-26, see §2.1 |
| Y km | 8.2410935719657779e+07 | PENDING | — | — | 1 km (same DE) | PENDING | |
| Z km | 3.5722421125493914e+07 | PENDING | — | — | 1 km (same DE) | PENDING | |
| VX km/s | -1.8484375569608581e+01 | PENDING | — | — | 1e-6 km/s (same DE) | PENDING | |
| VY km/s | 2.1667047760685282e+01 | PENDING | — | — | 1e-6 km/s (same DE) | PENDING | |
| VZ km/s | 9.3931948346226672e+00 | PENDING | — | — | 1e-6 km/s (same DE) | PENDING | |

#### Mars barycenter (4) wrt Sun (10), same configuration

| Component | ARES | Horizons | Abs. diff | Rel. diff | Tolerance | Pass/Fail | Horizons source |
| --- | --- | --- | --- | --- | --- | --- | --- |
| X km | -4.1148329224363036e+07 | PENDING | — | — | 1 km (same DE) | PENDING | Horizons API error 2026-10-26, see §2.1 |
| Y km | 2.1296948584252018e+08 | PENDING | — | — | 1 km (same DE) | PENDING | |
| Z km | 9.8793943168231577e+07 | PENDING | — | — | 1 km (same DE) | PENDING | |
| VX km/s | -2.2947830338191338e+01 | PENDING | — | — | 1e-6 km/s (same DE) | PENDING | |
| VY km/s | -2.1571953089860965e+00 | PENDING | — | — | 1e-6 km/s (same DE) | PENDING | |
| VZ km/s | -3.7054851727568078e-01 | PENDING | — | — | 1e-6 km/s (same DE) | PENDING | |

Tolerances above are for a **same-ephemeris** comparison (Horizons using
DE440). If Horizons reports a different DE, do not tighten or loosen
tolerances to force a pass; record the DE and the observed difference.

## 3. Example ARES run

Command:

```text
python -m ares.ephemeris --date "2026-10-31T00:00:00"
```

Verification run (this repository, 2026-10-26, Asia/Calcutta). Kernels:
`de440s.bsp` MD5 `3917ee56769db332790c751e2168843d`, `naif0012.tls`.

```text
ARES Stage 1 — heliocentric geometric states
Source: NASA/JPL NAIF SPICE via SpiceyPy (spkezr)
SPK: de440s.bsp
LSK: naif0012.tls
Frame: J2000 (SPICE inertial; DE440 aligned to ICRF)
Observer: SUN (NAIF 10) — heliocentric, not barycentric
Aberration correction: NONE
UTC: 2026-10-31T00:00:00.000000 UTC
ET  : 846676869.182498932 seconds TDB past J2000
Units: position km, velocity km/s, light time s

Earth body center
  target           : EARTH (NAIF 399)
  position_km      : [1.1830853943129119e+08, 8.2410935719657779e+07, 3.5722421125493914e+07]
  velocity_km_s    : [-1.8484375569608581e+01, 2.1667047760685282e+01, 9.3931948346226672e+00]
  radius_km        : 1.4854145616501164e+08
  speed_km_s       : 2.9989418268171551e+01
  light_time_s     : 4.9548096425098089e+02
  radius_au        : 9.9293830500363967e-01  (IAU 2012 au)

Mars system barycenter
  target           : MARS BARYCENTER (NAIF 4)
  position_km      : [-4.1148329224363036e+07, 2.1296948584252018e+08, 9.8793943168231577e+07]
  velocity_km_s    : [-2.2947830338191338e+01, -2.1571953089860965e+00, -3.7054851727568078e-01]
  radius_km        : 2.3834728885538375e+08
  speed_km_s       : 2.3051978549252155e+01
  light_time_s     : 7.9504097749978678e+02
  radius_au        : 1.5932532177102958e+00  (IAU 2012 au)
```

`radius_au` uses the IAU 2012 defining au (149597870.7 km), not a fitted
Earth–Sun mean distance.

## 4. Stage 2 — Lambert engine (automated)

| Quantity | ARES | Reference | Difference | Tolerance | Status | Source |
| --- | --- | --- | --- | --- | --- | --- |
| GM_sun km³/s² | `132712440041.279419` | Park et al. 2021 Table 2 | 0 (same digits) | exact (stored) | PASS | Park et al. 2021 |
| C3 vs \|v∞,E\|² | identity in `excess_velocity` | \(C_3=\|v_\infty\|^2\) | 0 to 1e-12 rel | 1e-12 rel | PASS | definition |
| Kepler reconstruction v1,v2 | `solve_lambert` | perifocal two-body (Vallado formulae in test) | < 1e-6 km/s | 1e-6 km/s | PASS | two-body ellipse, not lamberthub examples |
| Lambert endpoint (ellipse) | DOP853 of (r1,v1) | r2 of same ellipse | < 1 km | 1 km | PASS | same two-body μ |

These tests do **not** replace an external mission-design C3 table.

## 5. Stage 2 — ARES computed Earth→Mars case

Not an optimum. Not a NASA-published window product. Dates:

- Departure: 2026-10-31T00:00:00 UTC
- Arrival: 2027-09-07T00:00:00 UTC
- Solver: `lamberthub.izzo2015`, M=0, prograde=True
- Frame: J2000, observer Sun, `abcorr=NONE`
- μ: DE440 GM_sun

Command:

```text
python -m ares.trajectory --departure "2026-10-31T00:00:00" --arrival "2027-09-07T00:00:00"
```

| Quantity | ARES | Reference | Difference | Tolerance | Status |
| --- | --- | --- | --- | --- | --- |
| TOF | 311.000000 SI days (26870400.000044 s) | arrival−departure UTC, no leap second | ΔET−ΔUTC ≈ 44 µs | — | computed |
| Transfer angle | 3.590948 rad (205.746°) | r1,r2 geometry, prograde sense | — | — | computed (Type II / long-way) |
| Earth v∞ | 3.043789902 km/s | — | — | — | computed |
| Mars v∞ | 2.570159534 km/s | — | — | — | computed |
| C3 | 9.264656968 km²/s² | \|v∞,E\|² | 0 by construction | 1e-12 rel | PASS (identity) |
| Lambert endpoint \|Δr\| | 4.675935×10⁻⁴ km | r_Mars(t1) under two-body Sun | 0.4676 m | 1 km | PASS |
| Relative endpoint | 2.058×10⁻¹² | \|Δr\|/\|r_Mars\| | — | — | PASS |
| NASA/JPL published C3 for this pair | — | not queried | — | — | PENDING |
| GMAT n-body comparison | — | not run | — | — | PENDING |
| Horizons planet states | — | API error 2026-10-26, §2.1 | — | — | PENDING |

Endpoint method: SciPy DOP853, rtol=1e-12, atol=1e-9. This is a **two-body
self-consistency** check of Izzo+integrator, not n-body accuracy.

Manual external check (when Horizons/GMAT are available):

1. Confirm Earth(399) and Mars barycenter(4) states vs Horizons (§2.3) at both
   epochs, `CENTER=@10`, `REF_PLANE=FRAME`, `TIME_TYPE=UT`, `VEC_CORR=NONE`.
2. Optionally reproduce the Lambert in GMAT two-body Sun-centered mode with
   the same μ and compare v∞ and C3.
3. Do not treat a porkchop contour as truth for a single date pair without
   matching TOF, frame, and μ.

## 6. Stage 3 — automated porkchop tests

| Quantity | ARES | Reference | Difference | Tolerance | Status | Source |
| --- | --- | --- | --- | --- | --- | --- |
| Date grid inclusive + ordered | `utc_date_grid` | start/end/step definition | 0 | exact | PASS if pytest passes | `tests/test_porkchop.py` |
| Arrival before departure | skipped, NaN | TOF gate | — | must not crash | PASS if pytest passes | same |
| Invalid TOF | NaN, not 0 | failure encoding | — | NaN | PASS if pytest passes | same |
| Grid C3 vs Stage 2 C3 (2026-10-31 → 2027-09-07) | porkchop cell | `compute_earth_mars_transfer(...).c3` | 0 to ~1e-12 rel | 1e-12 rel | PASS if pytest passes | identity of `lambert_energetics` |
| C3 vs \|v∞,E\|² on grid | identity | definition | 0 to 1e-12 rel | 1e-12 rel | PASS | Stage 2 energetics |
| Lambert failure | NaN + `lambert_failed` | must not abort grid | — | NaN, not 0 | PASS if pytest passes | forced `LambertError` |
| SPICE cache | n_Earth + n_Mars calls | Cartesian product would be n_E×n_A | — | n_E and n_A lookups | PASS if pytest passes | monkeypatch counters |
| CSV | empty numerics if invalid | schema | — | no 0-as-failure | PASS if pytest passes | same |

These tests do **not** replace a NASA contour overlay.

## 7. Stage 3 — coarse 2026/27 production grid

Command (this repository):

```text
python -m ares.porkchop --refine-days 15 --output outputs/earth_mars_2026_porkchop
```

Defaults: departure 2026-07-01–2027-03-01, arrival 2027-03-01–2028-06-01,
step 5 days, TOF 100–500 days. Frame J2000, observer Sun, `abcorr=NONE`,
μ = DE440 GM_sun. Run 2026-10-26 (Asia/Calcutta).

| Item | Value |
| --- | --- |
| Departure epochs | 50 |
| Arrival epochs | 93 |
| Potential cells | 4650 |
| Valid Lambert solutions | 3558 |
| Lambert failures | 0 |
| Skipped (TOF/order) | 1092 |
| Cached Earth / Mars states | 50 / 93 |
| Runtime | 3.46 s (serial) |

### 7.1 Coarse-grid candidates (5-day nodes)

Not a “best mission” ranking.

| Candidate | Departure UTC | Arrival UTC | TOF days | C3 km²/s² | Earth v∞ km/s | Mars v∞ km/s |
| --- | --- | --- | --- | --- | --- | --- |
| Minimum C3 | 2026-10-29 | 2027-08-23 | 298.000 | 9.222593 | 3.036872 | 2.670571 |
| Minimum Arrival v∞ | 2026-11-08 | 2027-09-07 | 303.000 | 9.886858 | 3.144337 | 2.564784 |
| Shortest TOF | 2027-02-26 | 2027-06-09 | 103.000 | 428.168745 | 20.692239 | 9.991714 |

Shortest TOF sits on the 100-day gate and is energetically useless; it is
listed only because the selector reports the TOF minimum.

### 7.2 Optional 1-day refinement (±15 days about coarse min C3)

31 × 31 = 961 cells, all valid, 0.06 s.

| Candidate | Departure UTC | Arrival UTC | TOF days | C3 km²/s² | Earth v∞ km/s | Mars v∞ km/s |
| --- | --- | --- | --- | --- | --- | --- |
| Minimum C3 | 2026-10-31 | 2027-08-20 | 293.000 | 9.183492 | 3.030428 | 2.712437 |
| Minimum Arrival v∞ (in this window) | 2026-11-07 | 2027-09-07 | 304.000 | 9.718980 | 3.117528 | 2.564524 |

The refined arrival window ends 2027-09-07, so it does not include the
NASA Table 2 Type II min-arrival-\(v_\infty\) date 2027-09-08.

### 7.3 Direct Stage 2 cross-check

Same physics path; difference is 0 at printed precision.

| Date pair | Grid C3 km²/s² | Direct `compute_earth_mars_transfer` C3 | Abs. diff | Status |
| --- | --- | --- | --- | --- |
| 2026-10-29 → 2027-08-23 (coarse min C3) | 9.222592733691 | 9.222592733691 | 0 | PASS |
| 2026-10-31 → 2027-08-20 (refined min C3) | 9.183492293759 | 9.183492293759 | 0 | PASS |
| 2026-10-31 → 2027-09-07 (Stage 2 reference) | 9.264656967849 | 9.264656967849 | 0 | PASS |
| 2026-11-08 → 2027-09-07 (coarse min Mars v∞) | 9.886858094907 | 9.886858094907 | 0 | PASS |

## 8. Stage 3 — NASA/TM-2010-216764 comparison

**Reference:** Burke, Falck, McGuire, NASA/TM-2010-216764, Table 2
“Earth to Mars—2026 Opportunity—Energy Minima”. Generated by **MIDAS**
(patched-conic optimizer, two-day date search, C3 reported to 0.01).
ARES uses heliocentric two-body Lambert on DE440 geometric states,
M=0 prograde, no DSM, no parking orbit.

ARES is **not** tuned to these numbers.

### 8.1 Table 2 ballistic Type II (no DSM)

| Quantity compared | ARES (same civil dates, 00:00:00 UTC) | NASA Table 2 | Difference | Status |
| --- | --- | --- | --- | --- |
| Type II min-C3 dates | — | Earth 10/31/26, Mars 8/19/27 | — | NASA published |
| C3 at those dates | 9.184132 km²/s² | 9.144 km²/s² | 0.040 km²/s² (~0.4%) | **not equal; models differ** |
| Mars arrival v∞ at those dates | 2.728454 km/s | 2.729 km/s | 0.0005 km/s | close; not a pass criterion |
| ARES 1-day min C3 | 10/31/26 → 8/20/27, C3 9.183492 | 10/31/26 → 8/19/27, C3 9.144 | 1 day in arrival | opportunity **location** agrees |
| Type II min arrival v∞ dates | — | Earth 11/6/26, Mars 9/8/27 | — | NASA published |
| C3 at those dates | 9.582104 km²/s² | 9.646 km²/s² | 0.064 km²/s² | models differ |
| Mars v∞ at those dates | 2.564025 km/s | 2.565 km/s | 0.001 km/s | close; not a pass criterion |
| ARES coarse min arrival v∞ | 11/8/26 → 9/7/27, 2.564784 km/s | 11/6/26 → 9/8/27, 2.565 km/s | 2 days / ~0 | location agrees |

NASA Table 2 Type I min C3: 11/14/26 → 8/9/27, C3 11.11, Mars v∞ 2.915.
ARES does not isolate Type I vs Type II in the selector (prograde M=0
includes both; the 180° ridge appears as high C3). Exact Type I minimum
extraction is **PENDING**.

### 8.2 What this does and does not show

- **Shows:** the 2026 Earth→Mars low-C3 region found by ARES sits in the
  same calendar neighborhood as NASA’s 2026 Type II ballistic minimum
  (late October 2026 departure, mid/late August 2027 arrival), with C3
  near 9 km²/s² and Mars arrival v∞ near 2.6–2.7 km/s.
- **Does not show:** that ARES reproduces MIDAS contours, parking-orbit
  injection, launch-asymptote RA/Dec, or DSM-optimized paths.
- Exact same-model (GMAT two-body Sun, DE440, identical μ) C3 table:
  **PENDING**.
- Horizons planet states at the grid epochs: **PENDING** (API error
  2026-10-26, §2.1).

Do not treat a 0.04 km²/s² C3 offset as an ARES bug or as a reason to
edit μ, the Lambert branch, or the dates.

## 9. Reference-body audit (2026-10-26)

Runtime `spkobj(de440s.bsp)` matches NAIF `aa_summaries.txt` for `de440s.bsp`:
bodies 1–10, 199, 299, 301, 399. **499 is absent.** `bodn2c('EARTH')=399`,
`bodn2c('EARTH BARYCENTER')=3`, `bodn2c('MARS BARYCENTER')=4`,
`bodn2c('MARS')=499`, `bodn2c('SUN')=10` (NAIF IDs Required Reading).

Production Lambert endpoints (unchanged):

| Role | Name | NAIF ID | Meaning |
| --- | --- | --- | --- |
| Earth | `EARTH` | 399 | body center / geocenter |
| Mars | `MARS BARYCENTER` | 4 | Mars system barycenter |
| Observer | `SUN` | 10 | heliocentric geometric center |
| Frame | `J2000` | — | SPICE inertial |
| Aberration | `NONE` | — | geometric |

### 9.1 Earth 399 vs EMB 3 (both in de440s)

Epoch 2026-10-31 00:00:00 UTC, observer Sun, J2000, NONE:

| | Value |
| --- | --- |
| \|r_399 − r_3\| | 4462.527 km |
| \|v_399 − v_3\| | 0.012968 km/s |

Using EMB as the Lambert Earth endpoint on 2026-10-31 → 2027-08-19 would
give C3 = 9.148847 km²/s² vs production 9.184132 km²/s² (ΔC3 = −0.035 km²/s²).
That is closer to NASA/TM-2010-216764 Table 2 Type II C3 9.144, and is
**rejected**: C3 is defined on Earth body-relative \(v_\infty\), not EMB.
ARES is not tuned to the NASA table.

### 9.2 Mars 4 vs Mars body 499 (499 requires `mar099s.bsp`)

`de440s.bsp` cannot compute 499 (`SPICE(SPKINSUFFDATA)`). Audit-only load of
NAIF `mar099s.bsp` (MD5 `fd7302dfbaa0c63ce85b1e98923ee6a1`; not a production
kernel). Same observer/frame/abcorr. Offset is Mars body minus barycenter.

| Epoch UTC | \|Δr\| km | \|Δv\| km/s |
| --- | --- | --- |
| 2026-10-31 00:00:00 | 0.000125 | 3.35×10⁻⁸ |
| 2027-08-19 00:00:00 | 0.000204 | 3.88×10⁻⁸ |
| 2027-08-20 00:00:00 | 0.000146 | 3.48×10⁻⁸ |

Earth remains 399 in both conventions, so Earth |Δr| = 0, |Δv| = 0.

### 9.3 Trajectory 2026-10-31 → 2027-08-19 (NASA Table 2 Type II dates)

Same Lambert path (`lambert_energetics`). Planet-center = Earth 399 + Mars 499.

| Quantity | Production (399 / 4) | Planet-center (399 / 499) | Difference |
| --- | --- | --- | --- |
| C3 km²/s² | 9.184131505524 | 9.184131505536 | 1.24×10⁻¹¹ |
| Earth v∞ km/s | 3.030533204821 | 3.030533204823 | 2.04×10⁻¹² |
| Mars v∞ km/s | 2.728453965898 | 2.728453970647 | 4.75×10⁻⁹ |

2026-10-31 → 2027-08-20 (ARES 1-day min C3): ΔC3 = 4.24×10⁻¹² km²/s².

### 9.4 Decision

Keep production targets **399 / 4 / 10**. Do not switch Earth to 3 to
approach NASA C3. Do not add `mar099s.bsp` solely to relabel Mars as 499;
the dynamical effect is ~10⁻¹¹ in C3. Label Mars as **system barycenter**,
never as “Mars body center.”

Stage 2 regression (Earth 399, Mars 4, Sun 10, 2026-10-31 → 2027-09-07):
C3 = 9.264656967849 km²/s². Encoded in `test_stage2_reference_c3_regression`.
