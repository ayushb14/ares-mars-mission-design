# ARES

**Mars Mission Design & Systems Simulator**

Technical Report — Stages 1–4

Local heliocentric two-body Lambert Earth→Mars mission design using NASA/JPL NAIF SPICE ephemerides.

**Status.** Compared against published NASA mission-design data. Not NASA-certified. Using NAIF kernels does not constitute NASA endorsement.

**Document date.** 2026-10-26.

**Companion files.** `docs/PHYSICS.md` (models and units), `docs/SOURCES.md` (authority and URLs), `docs/VALIDATION.md` (tests and comparison tables). This report does not introduce new numerical results.

---

## 1. Title Page Content

| Field | Value |
| --- | --- |
| Title | ARES: Mars Mission Design & Systems Simulator |
| Subtitle | Stages 1–4 — SPICE ephemerides, Lambert transfers, porkchop search, local application |
| Software version | 0.4.0 |
| Physics core | `src/ares/` (Python) |
| Application | FastAPI + React / TypeScript / Vite |
| Ephemeris | NASA/JPL NAIF DE440 short (`de440s.bsp`) + leapseconds `naif0012.tls` |
| Frame | J2000 |
| Aberration | NONE (geometric) |
| Earth target | NAIF 399 (Earth body center) |
| Mars target | NAIF 4 (Mars system barycenter) |
| Observer | NAIF 10 (Sun) |
| License | MIT (kernels remain NASA/JPL data) |

---

## 2. Abstract

ARES is a local Earth→Mars mission-design system whose physical results are produced by a Python engine that loads official NASA/JPL NAIF kernels and solves a heliocentric two-body Lambert problem. Stage 1 converts UTC to ephemeris time and requests geometric heliocentric states. Stage 2 connects Earth (NAIF 399) at departure to the Mars system barycenter (NAIF 4) at arrival with Izzo’s 2015 Lambert solver (\(M=0\), prograde), then reports hyperbolic excess velocities and characteristic energy \(C_3 = |v_{\infty,\mathrm{Earth}}|^2\). Stage 3 evaluates the same Lambert path on a launch-window grid (porkchop). Stage 4 exposes that engine through FastAPI and a React workspace. The frontend does not implement orbital equations.

ARES was compared against NASA/TM-2010-216764 Table 2 Type II ballistic dates 2026-10-31 → 2027-08-19. NASA/MIDAS published \(C_3 = 9.144\,\mathrm{km}^2\,\mathrm{s}^{-2}\). ARES two-body Lambert on DE440 geometric states yields \(C_3 \approx 9.184131505524\,\mathrm{km}^2\,\mathrm{s}^{-2}\). Exact equality is not expected and was not forced. Horizons state-vector comparison remains pending after a 2026-10-26 Horizons API failure.

---

## 3. Introduction

Interplanetary mission design begins with an ephemeris, a transfer model, and a clear statement of what is *not* modeled. ARES is built so that those three things are explicit.

Planetary positions and velocities are not approximated as circular Keplerian orbits. They are geometric states from the JPL Development Ephemeris DE440, delivered as NAIF SPK and evaluated by CSPICE (SpiceyPy). The spacecraft path between those states *is* a two-body conic about a point-mass Sun. That split is intentional: the planets follow an n-body ephemeris; the cruise model in this version does not.

The 2026 Earth→Mars opportunity is used as the working example because NASA/TM-2010-216764 publishes Type I/II energy minima for that cycle. ARES uses those civil dates as a comparison case, not as an ingested MIDAS product and not as a claimed ARES optimum.

---

## 4. Project Objectives

1. Call official NAIF kernels for Earth, Mars-system, and Sun states in a documented frame and aberration convention.
2. Solve Lambert’s problem once, in Python, with a named algorithm and branch.
3. Define \(v_\infty\) and \(C_3\) in SI-consistent internal units (km, km/s, s) and never present them as launch ΔV or MOI ΔV.
4. Search a launch window by repeating that same Lambert path on a date grid, encoding failures as NaN rather than zero.
5. Present results in a local application whose frontend cannot silently diverge from the engine.
6. Record comparison to published NASA mission-design data without claiming NASA certification.

Non-objectives for Stages 1–4: n-body spacecraft integration, deep-space maneuvers, finite burns, launch-vehicle performance, parking-orbit ΔV, Mars orbit insertion ΔV, EDL, communications, and surface systems.

---

## 5. System Architecture

Dependency direction:

```text
NASA/JPL SPICE (DE440s, LSK)
        ↓
ARES Python physics engine     src/ares/
        ↓
FastAPI                        src/ares/api/
        ↓
React / TypeScript             frontend/
        ↓
Plotly visualization
```

| Layer | Responsibility | Must not |
| --- | --- | --- |
| CSPICE / kernels | Time and geometric states | Be re-derived in ARES |
| `ares.time`, `ares.ephemeris` | Validate inputs; call `str2et` / `spkezr` | Invent leap seconds or Chebyshev interpolation |
| `ares.lambert` | Call `lamberthub.izzo2015`; select \(M=0\), prograde | Re-code Izzo |
| `ares.energetics` | \(v_\infty\), \(C_3\) | Treat \(C_3\) as ΔV |
| `ares.trajectory` | Orchestrate one transfer; DOP853 check; sample the arc | Draw decorative curves |
| `ares.porkchop` | Date grid of the same Lambert path | A second C3 formula |
| FastAPI | HTTP, Pydantic, JSON | Orbital equations |
| React | Forms, Plotly, navigation | Orbital equations |

Selecting a porkchop cell sends its departure and arrival timestamps to `POST /api/trajectory`. Interpolation of the heatmap is not used as a trajectory.

---

## 6. Technology Stack

| Component | Choice | Role |
| --- | --- | --- |
| Language (engine) | Python ≥ 3.11 | Physics and API |
| SPICE binding | SpiceyPy ≥ 6 | CSPICE |
| Array / ODE | NumPy, SciPy `solve_ivp` DOP853 | Propagation check |
| Lambert | lamberthub 1.x `izzo2015` | Transfer velocities |
| HTTP | FastAPI, Uvicorn, Pydantic | Local API |
| UI | React, TypeScript, Vite | Presentation |
| Charts | Plotly | 3D transfer and C3 heatmap |
| Tests | pytest, FastAPI TestClient | Physics + API identity |
| Kernels | NAIF generic archive via `scripts/download_kernels.py` | LSK + DE440s |

No API keys are required for core local use. Docker, Celery, Redis, and CesiumJS are not part of Stage 4.

---

## 7. Astrodynamics Model

ARES Stage 2–4 cruise model is **heliocentric two-body Lambert**:

- Central body: Sun, point mass, \(\mu_\odot\) from DE440 (Section 10 / constants).
- Boundary conditions: geometric heliocentric position of Earth body center at \(t_0\) and Mars system barycenter at \(t_1\).
- Path: unique two-body conic with \(M=0\) extra revolutions and prograde sense about J2000 \(+Z\). If that sense yields a transfer angle \(>\pi\), ARES keeps the long-way (Type II) solution; it does not switch to retrograde.

Planets are **not** two-body. Their states come from DE440 through SPICE. The inconsistency (n-body planets, two-body spacecraft) is a standard patched-conic / Lambert approximation and is stated in the UI model panel.

Internal units:

| Quantity | Unit |
| --- | --- |
| Distance | km |
| Velocity | km/s |
| Time | seconds (SI); days labelled with 86400 s exactly |
| Angles | radians |
| \(C_3\) | km²/s² |
| \(\mu\) | km³/s² |

The astronomical unit is the IAU 2012 defining value \(149\,597\,870.7\,\mathrm{km}\) (exact). It is used for display (AU axes) and sanity envelopes, not as a second ephemeris.

---

## 8. NASA/JPL SPICE Ephemerides

ARES does not implement an independent planetary ephemeris. It furnishes official kernels and calls CSPICE.

| File | NAIF path | Use |
| --- | --- | --- |
| `naif0012.tls` | `generic_kernels/lsk/naif0012.tls` | Leap seconds for `str2et` (LF) |
| `naif0012.tls.pc` | same, CRLF | Preferred on Windows |
| `de440s.bsp` | `generic_kernels/spk/planets/de440s.bsp` | Planetary SPK, 1849–2150 ET |

`de440s.bsp` MD5 published by NAIF in `aa_checksums.txt`: `3917ee56769db332790c751e2168843d` (verified on download 2026-10-26). Size 32 726 016 bytes.

SPICE `spkezr` is invoked as target relative to observer `SUN` in frame `J2000` with `abcorr=NONE`. CSPICE chains SPK segments (planet barycenters w.r.t. SSB, Earth and Moon w.r.t. EMB, Sun w.r.t. SSB). ARES does not interpolate Chebyshev coefficients.

Peer-reviewed description of DE440/DE441: Park et al. (2021), *The Astronomical Journal* 161:105. DE440 is aligned to the ICRF. ARES requests the SPICE frame name `J2000` and does not apply a separate J2000↔ICRF rotation.

Full DE440 (`de440.bsp`) and DE441 are not downloaded. Mars body 499 is not present in `de440s.bsp`. Satellite SPK `mar099s.bsp` was loaded once for an audit (Section 9) and is not a production dependency.

---

## 9. Reference Frames and Body Conventions

Default geometry request:

| Item | Value | Meaning |
| --- | --- | --- |
| Earth | `EARTH` / **NAIF 399** | Body center / geocenter |
| Mars | `MARS BARYCENTER` / **NAIF 4** | Mars + Phobos + Deimos barycenter |
| Observer | `SUN` / **NAIF 10** | Heliocentric geometric center |
| Frame | **J2000** | SPICE built-in inertial frame |
| Aberration | **NONE** | No light-time, no stellar aberration |

These four states are not interchangeable: heliocentric (Sun 10), barycentric (SSB 0), planet-centered, and body-fixed (requires a PCK; not loaded).

**Why 399, not 3.** Earth-relative \(v_\infty\) and \(C_3\) are defined with respect to Earth’s mass center. EMB (3) is offset from 399 by \(\lvert\Delta\mathbf{r}\rvert = 4462.527\,\mathrm{km}\) and \(\lvert\Delta\mathbf{v}\rvert = 0.012968\,\mathrm{km\,s^{-1}}\) at 2026-10-31 00:00:00 UTC (Sun, J2000, NONE). Using EMB as the Lambert Earth endpoint on 2026-10-31 → 2027-08-19 would give \(C_3 = 9.148847\,\mathrm{km}^2\,\mathrm{s}^{-2}\) versus production \(9.184132\,\mathrm{km}^2\,\mathrm{s}^{-2}\). That is closer to NASA Table 2 \(C_3 = 9.144\) and is **rejected**: ARES is not tuned to the NASA table.

**Why 4, not 499.** `de440s.bsp` has no 499 segment (`SPICE(SPKINSUFFDATA)`). An audit-only load of NAIF `mar099s.bsp` (MD5 `fd7302dfbaa0c63ce85b1e98923ee6a1`) gives \(\lvert\Delta\mathbf{r}\rvert \approx 0.00012\)–\(0.00020\,\mathrm{km}\) and \(\lvert\Delta\mathbf{v}\rvert \approx 3\times10^{-8}\,\mathrm{km\,s^{-1}}\) at the 2026/27 epochs. Production \(C_3\) difference 399/4 vs 399/499 on 2026-10-31 → 2027-08-19 is \(1.24\times10^{-11}\,\mathrm{km}^2\,\mathrm{s}^{-2}\). Production keeps NAIF 4, labelled **system barycenter**, never “Mars body center.”

Runtime confirmation: `spkobj(de440s.bsp)` matches NAIF `aa_summaries.txt` (bodies 1–10, 199, 299, 301, 399; **499 absent**). `bodn2c('EARTH')=399`, `bodn2c('MARS BARYCENTER')=4`, `bodn2c('SUN')=10`.

---

## 10. Lambert Transfer Method

**Module:** `ares.lambert.solve_lambert` → `lamberthub.izzo2015`.

Given \(\mathbf{r}_1\), \(\mathbf{r}_2\) (km) and \(\Delta t > 0\) (s) about a point-mass Sun,

\[
\mathbf{v}_1,\;\mathbf{v}_2
= \mathrm{Izzo}_{M=0,\,\mathrm{prograde}}(\mu_\odot,\,\mathbf{r}_1,\,\mathbf{r}_2,\,\Delta t).
\]

| Parameter | Value | Meaning |
| --- | --- | --- |
| \(M\) | 0 | Zero extra revolutions |
| `prograde` | True | Transfer angular momentum has positive frame-\(Z\) |
| `low_path` | True | Unused at \(M=0\) (lamberthub) |
| `atol`, `rtol` | \(10^{-12}\), \(10^{-10}\) | Tighter than lamberthub defaults |

Solar gravitational parameter (Park et al. 2021 Table 2; NAIF `GMS` / `BODY10_GM`):

\[
\mu_\odot = 132712440041.279419\,\mathrm{km}^{3}\,\mathrm{s}^{-2}.
\]

Collinear \(\mathbf{r}_1,\mathbf{r}_2\) (0° or 180°) is rejected: the transfer plane is undefined. Multi-revolution transfers (\(M\ge 1\)) are rejected.

Time of flight is \(\Delta t = \mathrm{ET}(t_1) - \mathrm{ET}(t_0)\) on the TDB scale after `str2et`. Arrival must be strictly after departure.

ARES does not re-implement Izzo (2015). Algorithm authority: Izzo, D. (2015), *Celestial Mechanics and Dynamical Astronomy* 121:1–15.

---

## 11. Hyperbolic Excess Velocity

**Module:** `ares.energetics`.

\[
\mathbf{v}_{\infty,\mathrm{E}}
= \mathbf{v}_{1,\mathrm{transfer}} - \mathbf{v}_{\mathrm{Earth}}(t_0)
\]

\[
\mathbf{v}_{\infty,\mathrm{M}}
= \mathbf{v}_{2,\mathrm{transfer}} - \mathbf{v}_{\mathrm{Mars}}(t_1)
\]

All vectors share J2000. Units: km/s.

Earth \(v_\infty\) is **not** pad ΔV. Mars \(v_\infty\) is **not** MOI ΔV. No parking orbit or launch vehicle is assumed, so those ΔV values are not computed.

---

## 12. Characteristic Energy \(C_3\)

\[
C_3 = \lvert\mathbf{v}_{\infty,\mathrm{E}}\rvert^{2}
\qquad [\mathrm{km}^{2}\,\mathrm{s}^{-2}].
\]

\(C_3\) is characteristic energy at Earth departure. It is **not** launch ΔV and **not** Mars orbit-insertion ΔV. By construction \(C_3 = |v_{\infty,\mathrm{E}}|^2\) to numerical identity (tested at relative \(10^{-12}\)).

Zero is a physically meaningful \(C_3\) (parabolic / Hohmann-limit neighborhood) and is **never** used as a failure flag on the porkchop grid.

---

## 13. Trajectory Propagation and Verification

**Module:** `ares.trajectory.propagate_two_body`.

Two-body equation about the Sun:

\[
\ddot{\mathbf{r}} = -\mu_\odot\,\mathbf{r}/\lvert\mathbf{r}\rvert^{3}.
\]

Integrated with SciPy `solve_ivp`, method **DOP853** (Dormand–Prince 8(7)), `rtol=1e-12`, `atol=1e-9` (state in km and km/s).

Initial condition: \(\mathbf{r}(t_0)=\mathbf{r}_{\mathrm{Earth}}(t_0)\), \(\mathbf{v}(t_0)=\mathbf{v}_{1,\mathrm{transfer}}\). Compare \(\mathbf{r}(t_0+\Delta t)\) to \(\mathbf{r}_{\mathrm{Mars}}(t_1)\).

Pass criterion: \(\lvert\Delta\mathbf{r}\rvert \le 1\,\mathrm{km}\). Justification: \(10^{-12}\) relative on \(\lvert\mathbf{r}\rvert\sim 1.5\times10^{8}\,\mathrm{km}\) is a ~0.15 m local scale; 1 km is a verification ceiling for the *same* two-body model, not a fit to n-body Mars.

Visualization samples (`sample_transfer_points`, default 201, maximum 400) use the same DOP853 dense output. They are not Bézier curves and not decorative circular arcs.

---

## 14. Earth–Mars Launch Window Search

**Module:** `ares.porkchop.compute_porkchop`.

Stage 3 does not introduce a second Lambert solver, C3 formula, or ephemeris. Each grid node calls `lambert_energetics` (the Stage 2 energetics path without the per-arc DOP853 check).

UTC grids are inclusive of start and end. Step is a positive number of SI days. A pair with arrival epoch ≤ departure epoch is not solved.

Default exploratory search (not an asserted optimum):

| Bound | Default |
| --- | --- |
| Earth departure | 2026-07-01 → 2027-03-01 UTC |
| Mars arrival | 2027-03-01 → 2028-06-01 UTC |
| Step | 5 days |
| Min TOF | 100 days |
| Max TOF | 500 days |

A cell is solved only if

\[
t_{\min} < t_{\mathrm{arrival}} - t_{\mathrm{departure}} < t_{\max}
\]

on the TDB scale. Outside that gate the cell is `skipped_tof` with **NaN** metrics.

**Why 100–500 days.** Circular-coplanar Hohmann Earth→Mars TOF with NSSDCA semimajor axes \(a_E = 149.598\times10^6\,\mathrm{km}\), \(a_M = 227.956\times10^6\,\mathrm{km}\) and DE440 \(\mu_\odot\) is \(\Delta t_H \approx 258.88\) days. NASA/TM-2010-216764 displays ballistic TOFs from 100 to 450 days. ARES defaults 100–500 days as a slightly broader envelope that admits \(M=0\) Type I and Type II without opening multi-revolution branches. The Hohmann figure is a scale check, not the ARES transfer model.

Earth state is cached once per departure epoch; Mars once per arrival epoch.

API/CLI safety cap: **12 000** potential cells. Requests above the cap are **rejected**, not truncated.

---

## 15. Porkchop Plot Generation

Arrays have shape `(n_departure, n_arrival)`: \(C_3\), Earth \(v_\infty\), Mars \(v_\infty\), TOF, validity, status.

CLI/HTML Plotly heatmap is a visualization aid. Contour interpolation is not written back to CSV. Color scale may be clipped at \(50\,\mathrm{km}^2\,\mathrm{s}^{-2}\) for display (NASA/TM-2010-216764 treated \(C_3>50\) as generally not of interest); stored values are unclipped.

Named extrema over valid cells (never “best mission”):

- Minimum \(C_3\) Candidate
- Minimum Earth \(v_\infty\) Candidate (same cell as min \(C_3\), because \(C_3=|v_\infty|^2\))
- Minimum Arrival \(v_\infty\) Candidate
- Shortest TOF Candidate

Shortest-TOF extrema often sit on the TOF floor with large \(C_3\); they are listed for completeness.

The React Launch Window page plots the API grid. Clicking a valid cell or a candidate, then **Open trajectory**, recomputes Stage 2.

Coarse 5-day 2026/27 production grid (documented in `docs/VALIDATION.md`, run 2026-10-26): 50 × 93 = 4650 potential cells, 3558 valid, 0 Lambert failures, 1092 skipped, serial runtime a few seconds. Minimum \(C_3\) on that grid: 2026-10-29 → 2027-08-23, \(C_3 = 9.222593\,\mathrm{km}^2\,\mathrm{s}^{-2}\). Optional 1-day refinement about that cell found 2026-10-31 → 2027-08-20, \(C_3 = 9.183492\,\mathrm{km}^2\,\mathrm{s}^{-2}\). Grid \(C_3\) matches `compute_earth_mars_transfer` \(C_3\) at printed precision on those pairs.

---

## 16. Backend Architecture

Package: `src/ares/api/`. Process: `python -m ares.api` (Uvicorn, `127.0.0.1:8765`).

| Method | Path | Engine call |
| --- | --- | --- |
| GET | `/api/health` | `engine_identity()` + kernel load probe |
| POST | `/api/trajectory` | `compute_earth_mars_transfer` + `sample_transfer_points` |
| POST | `/api/porkchop` | `compute_porkchop` + `select_candidates` |
| GET | `/api/reference-case` | NASA Table 2 civil dates through Stage 2 |

Pydantic rejects invalid timestamps, non-positive steps, inverted TOF bounds, and `n_points` outside \([2, 400]\). Domain errors (`TrajectoryError`, `LambertError`, `KernelError`, …) map to JSON `{error, detail}` without Python tracebacks. Grid-size violations return HTTP 400 with an explicit “rejected, not truncated” message.

OpenAPI is served at `/docs`. CORS allows the local Vite origin (`4177`).

Tests in `tests/test_api.py` require API \(C_3\), Earth \(v_\infty\), and Mars \(v_\infty\) to match the Python engine to relative/absolute \(10^{-12}\) on the NASA civil dates.

---

## 17. Frontend Architecture

`frontend/` is a Vite + React + TypeScript application. It talks to FastAPI over `/api` (dev-server proxy to port 8765).

| Page | Role |
| --- | --- |
| Mission Design | Departure/arrival inputs, Calculate, 3D Lambert plot, metric cards |
| Launch Window | Porkchop controls, C3 heatmap, candidates, Open trajectory |
| Validation | Model table, live NASA comparison, limitations |

Display precision (cards): \(C_3\) three decimals (km²/s²), \(v_\infty\) three decimals (km/s), TOF one decimal (days). Full precision remains in the API JSON. Units are always shown.

Model status (unobtrusive): heliocentric two-body Lambert; J2000; Earth NAIF 399; Mars NAIF 4 system barycenter; Sun NAIF 10; aberration NONE.

If the backend is unreachable, the UI reports “ARES physics engine unavailable.” It does not substitute placeholder physics.

Plotly 3D uses `aspectmode=data` (equal axis scaling) and AU coordinates. Body labels are Sun, Earth (399), Mars (4).

---

## 18. Validation Methodology

Legend in `docs/VALIDATION.md`: **PASS** / **FAIL** / **PENDING**. ARES using NAIF kernels is not “NASA validated.”

Layers:

1. **Automated pytest** — constants (IAU au, \(c\), \(\mu_\odot\)), UTC→ET, DE440s body list, 399 vs 3 vs 4 vs 499 availability, Lambert identities, two-body endpoint ≤ 1 km, porkchop NaN policy, grid \(C_3\) vs Stage 2 \(C_3\), API vs engine.
2. **Independent Horizons** — same observer/frame/abcorr/epochs. **PENDING** (Horizons HTTP API returned a server-side error on 2026-10-26; no invented vectors were recorded).
3. **NASA/TM-2010-216764 Table 2** — same civil dates, different model. Offset is documented, not tuned away.
4. **Reference-body audit** — 399 vs 3, 4 vs 499, recorded in Validation §9.

Automated tests do not replace Horizons.

---

## 19. NASA Comparison

**Reference.** Burke, Falck, McGuire, NASA/TM-2010-216764, Table 2 “Earth to Mars—2026 Opportunity—Energy Minima,” generated by **MIDAS** (patched-conic optimizer, two-day date search, \(C_3\) reported to 0.01).

**ARES model.** Heliocentric two-body Lambert, DE440 geometric states, \(M=0\) prograde, no DSM, no parking orbit.

ARES is **not** tuned to these numbers.

### 19.1 Verified comparison mission (production targets 399 / 4 / 10)

| Item | Value |
| --- | --- |
| Departure | 2026-10-31 (UTC 00:00:00) |
| Arrival | 2027-08-19 (UTC 00:00:00) |
| NASA published \(C_3\) | \(9.144\,\mathrm{km}^2\,\mathrm{s}^{-2}\) |
| ARES \(C_3\) | \(9.184131505524\,\mathrm{km}^2\,\mathrm{s}^{-2}\) |
| ARES Earth \(v_\infty\) | \(3.030533204821\,\mathrm{km\,s^{-1}}\) |
| ARES Mars \(v_\infty\) | \(2.728453965898\,\mathrm{km\,s^{-1}}\) |

NASA Table 2 Mars arrival \(v_\infty\) at those dates: \(2.729\,\mathrm{km\,s^{-1}}\) (difference \(0.0005\,\mathrm{km\,s^{-1}}\); close, not a pass criterion).

Difference in \(C_3\): \(0.040\,\mathrm{km}^2\,\mathrm{s}^{-2}\) (~0.4%). Status: **not equal; models differ**. Do not treat this offset as an ARES bug or as a reason to edit \(\mu\), the Lambert branch, Earth/Mars targets, or the dates.

### 19.2 Opportunity location

ARES 1-day refined minimum \(C_3\) in the 2026 window: 2026-10-31 → 2027-08-20, \(C_3 = 9.183492\,\mathrm{km}^2\,\mathrm{s}^{-2}\). NASA Type II min-\(C_3\) dates are 10/31/26 → 8/19/27. Calendar neighborhood agrees (late October 2026 departure, mid/late August 2027 arrival).

NASA Type II min arrival \(v_\infty\): Earth 11/6/26, Mars 9/8/27, \(C_3=9.646\), Mars \(v_\infty=2.565\,\mathrm{km\,s^{-1}}\). ARES at those civil dates: \(C_3=9.582104\,\mathrm{km}^2\,\mathrm{s}^{-2}\), Mars \(v_\infty=2.564025\,\mathrm{km\,s^{-1}}\). ARES coarse-grid min arrival \(v_\infty\): 11/8/26 → 9/7/27.

Exact Type I minimum extraction is **PENDING**. Exact same-model GMAT two-body comparison is **PENDING**.

---

## 20. Results

Frozen Stage 2 regression (Earth 399, Mars 4, Sun 10, 2026-10-31 → 2027-09-07), encoded in `test_stage2_reference_c3_regression`:

| Quantity | ARES |
| --- | --- |
| \(C_3\) | \(9.264656967849\,\mathrm{km}^2\,\mathrm{s}^{-2}\) |
| Earth \(v_\infty\) | \(3.043789902055\,\mathrm{km\,s^{-1}}\) |
| Mars \(v_\infty\) | \(2.570159533603\,\mathrm{km\,s^{-1}}\) |
| Transfer angle | \(3.590948\,\mathrm{rad}\) (205.746°, Type II) |
| Endpoint \(\lvert\Delta\mathbf{r}\rvert\) | \(4.675935\times10^{-4}\,\mathrm{km}\) (PASS vs 1 km) |

NASA-date pair (Section 19.1) is the Stage 4 full-stack regression: Python engine = FastAPI JSON = UI cards (engineering rounding 9.184 km²/s², 3.031 km/s, 2.728 km/s, 292.0 days).

Stage 3 coarse-grid candidates (5-day nodes, not a best-mission ranking):

| Candidate | Departure | Arrival | TOF d | \(C_3\) | Earth \(v_\infty\) | Mars \(v_\infty\) |
| --- | --- | --- | --- | --- | --- | --- |
| Minimum \(C_3\) | 2026-10-29 | 2027-08-23 | 298 | 9.222593 | 3.036872 | 2.670571 |
| Minimum arrival \(v_\infty\) | 2026-11-08 | 2027-09-07 | 303 | 9.886858 | 3.144337 | 2.564784 |
| Shortest TOF | 2027-02-26 | 2027-06-09 | 103 | 428.168745 | 20.692239 | 9.991714 |

Direct Stage 2 cross-check of those grid \(C_3\) values: absolute difference 0 at printed precision (`docs/VALIDATION.md` §7.3).

---

## 21. Testing

Run from the repository root after `pip install -e ".[dev]"` and kernel download:

```text
python -m pytest
cd frontend && npx tsc -b && npm run build
```

Physics tests cover time, ephemeris, Lambert, energetics, trajectory, and porkchop. API tests cover health metadata, trajectory identity with the engine, invalid dates, porkchop identity, invalid TOF bounds, grid-size protection, and the NASA-date reference case. Frontend verification is TypeScript compilation and production build (no large browser test stack).

Stage 4 API identity requirement: JSON \(C_3\) equals `compute_earth_mars_transfer(...).c3` within \(10^{-12}\).

---

## 22. Limitations

ARES Stages 1–4 do **not** model:

- n-body cruise perturbations
- deep-space maneuvers / broken-plane burns
- finite burns
- launch-vehicle performance or C3 capability
- parking-orbit departure ΔV
- Mars orbit insertion ΔV
- atmosphere, EDL, landing
- spacecraft mass, propellant, communications, surface mission
- body-fixed frames / PCK
- Mars body center 499 as a production endpoint

The porkchop is a discrete grid; the true continuous minimum may lie between nodes. Display clipping of \(C_3\) at 50 km²/s² does not alter stored values. Horizons comparison is PENDING. Type I vs Type II isolation in the candidate selector is PENDING.

---

## 23. Future Development

Not started:

- Parking-orbit and launch-vehicle ΔV
- MOI ΔV
- n-body integrator / GMAT comparison
- Horizons vector table when the SSD API is healthy
- EDL and landing-site products
- Cesium planetary globe

Later stages must not re-implement Lambert or C3 in TypeScript.

---

## 24. Conclusion

ARES Stage 4 is a complete local loop around a single Python physics engine: NAIF SPICE states, Izzo Lambert, documented \(v_\infty\) and \(C_3\), a porkchop grid, and a FastAPI + React workspace that cannot invent orbital mechanics. Production reference bodies are Earth **399**, Mars system barycenter **4**, Sun **10**, frame **J2000**, aberration **NONE**.

On the NASA/TM-2010-216764 Table 2 Type II civil dates, ARES reports \(C_3 \approx 9.184\,\mathrm{km}^2\,\mathrm{s}^{-2}\) against a published NASA value of \(9.144\,\mathrm{km}^2\,\mathrm{s}^{-2}\). That comparison is documented, not tuned. The software is compared against published NASA mission-design data; it is not NASA-certified.

---

## 25. References

URLs and checksums: `docs/SOURCES.md`. Retrieval date for NAIF index pages: 2026-10-26.

1. Park, R. S., Folkner, W. M., Williams, J. G., & Boggs, D. H. (2021). The JPL Planetary and Lunar Ephemerides DE440 and DE441. *The Astronomical Journal*, 161, 105. https://doi.org/10.3847/1538-3881/abd414
2. Izzo, D. (2015). Revisiting Lambert’s problem. *Celestial Mechanics and Dynamical Astronomy*, 121(1), 1–15. https://doi.org/10.1007/s10569-014-9587-y
3. Burke, L. M., Falck, R. D., & McGuire, M. L. (2010). *Interplanetary Mission Design Handbook: Earth-to-Mars Mission Opportunities 2026 to 2045.* NASA/TM-2010-216764. https://ntrs.nasa.gov/citations/20100037210
4. NASA/JPL NAIF. Generic kernels. https://naif.jpl.nasa.gov/pub/naif/generic_kernels/
5. NASA/JPL NAIF. `spkezr_c`, `str2et`, NAIF IDs Required Reading, SPK Required Reading. https://naif.jpl.nasa.gov/pub/naif/toolkit_docs/C/
6. IAU 2012 Resolution B2 (astronomical unit). https://iauarchive.eso.org/static/resolutions/IAU2012_English.pdf
7. BIPM. SI Brochure (speed of light).
8. JPL Horizons. https://ssd.jpl.nasa.gov/horizons/ (independent validation source; not a runtime ephemeris)
9. NSSDCA Earth and Mars fact sheets (sanity envelopes and Hohmann scale only).
10. SpiceyPy documentation. https://spiceypy.readthedocs.io/
11. SciPy `solve_ivp`. https://docs.scipy.org/doc/scipy/reference/generated/scipy.integrate.solve_ivp.html
12. lamberthub 1.x, `izzo2015`. https://pypi.org/project/lamberthub/
