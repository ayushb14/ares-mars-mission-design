# ARES frontend

React + TypeScript + Vite presentation layer for the ARES physics engine.

This package does **not** compute Lambert transfers, C3, or ephemerides.
It calls the local FastAPI service (`python -m ares.api`) and plots the
returned two-body samples with Plotly.

See the repository root `README.md` for install, kernel download, and
the two-terminal Windows workflow.
