export type Vec3 = [number, number, number];

export interface TrajectoryPoint {
  t_s: number;
  et_seconds: number;
  x_km: number;
  y_km: number;
  z_km: number;
}

export interface BodyState {
  target: string;
  target_id: number;
  meaning: string;
  utc: string;
  et_seconds: number;
  position_km: number[];
  velocity_km_s: number[];
}

export interface TrajectoryResponse {
  departure: string;
  arrival: string;
  time_of_flight_days: number;
  time_of_flight_s: number;
  c3_km2_s2: number;
  earth_vinf_km_s: number;
  mars_vinf_km_s: number;
  earth_vinf_vector_km_s: number[];
  mars_vinf_vector_km_s: number[];
  transfer_departure_velocity_km_s: number[];
  transfer_arrival_velocity_km_s: number[];
  transfer_angle_rad: number;
  earth: BodyState;
  mars: BodyState;
  trajectory_points: TrajectoryPoint[];
  verification_position_error_km: number;
  verification_within_tolerance: boolean;
  model: string;
  frame: string;
  aberration_correction: string;
  observer: string;
  observer_id: number;
  earth_target: string;
  earth_target_id: number;
  mars_target: string;
  mars_target_id: number;
  mu_km3_s2: number;
}

export interface PorkchopCandidate {
  name: string;
  key: string;
  departure_utc: string;
  arrival_utc: string;
  tof_days: number;
  c3_km2_s2: number;
  earth_vinf_km_s: number;
  mars_vinf_km_s: number;
  departure_index: number;
  arrival_index: number;
}

export interface PorkchopResponse {
  departure_utc: string[];
  arrival_utc: string[];
  tof_days: Array<Array<number | null>>;
  c3_km2_s2: Array<Array<number | null>>;
  earth_vinf_km_s: Array<Array<number | null>>;
  mars_vinf_km_s: Array<Array<number | null>>;
  valid: boolean[][];
  status: string[][];
  n_departure: number;
  n_arrival: number;
  n_potential: number;
  n_lambert_success: number;
  n_lambert_failed: number;
  n_skipped_tof: number;
  runtime_s: number;
  step_days: number;
  min_tof_days: number;
  max_tof_days: number;
  max_cells: number;
  frame: string;
  aberration_correction: string;
  earth_target_id: number;
  mars_target_id: number;
  observer_id: number;
  mu_km3_s2: number;
  candidates: Record<string, PorkchopCandidate>;
  model: string;
}

export interface HealthResponse {
  status: string;
  engine: string;
  version: string;
  physics_model: string;
  frame: string;
  earth_target: number;
  earth_target_name: string;
  mars_target: number;
  mars_target_name: string;
  observer: number;
  observer_name: string;
  aberration_correction: string;
  kernels_loaded: boolean;
  kernel_detail: string | null;
  max_porkchop_cells: number;
}

export interface ReferenceCaseResponse {
  label: string;
  departure: string;
  arrival: string;
  nasa_published_c3_km2_s2: number;
  nasa_source: string;
  note: string;
  transfer: TrajectoryResponse | null;
}

export interface ApiErrorBody {
  error?: string;
  detail?: string | Array<{ msg?: string; type?: string }>;
}
