import { useEffect, useRef } from "react";
import Plotly from "plotly.js-dist-min";
import { toDateInput } from "../api/client";
import type { PorkchopCandidate, PorkchopResponse } from "../types/ares";

export function PorkchopPlot({
  grid,
  onSelect,
}: {
  grid: PorkchopResponse;
  onSelect: (departureUtc: string, arrivalUtc: string) => void;
}) {
  const el = useRef<HTMLDivElement>(null);
  const onSelectRef = useRef(onSelect);
  onSelectRef.current = onSelect;

  useEffect(() => {
    const node = el.current;
    if (!node) {
      return;
    }
    const x = grid.arrival_utc.map(toDateInput);
    const y = grid.departure_utc.map(toDateInput);
    const custom = grid.departure_utc.map((_, i) =>
      grid.arrival_utc.map((_, j) => [
        grid.tof_days[i][j],
        grid.c3_km2_s2[i][j],
        grid.earth_vinf_km_s[i][j],
        grid.mars_vinf_km_s[i][j],
      ]),
    );

    const traces: Plotly.Data[] = [
      {
        type: "heatmap",
        x,
        y,
        z: grid.c3_km2_s2,
        customdata: custom as unknown as Plotly.Datum[][],
        zmin: 0,
        zmax: 50,
        colorscale: "Viridis",
        reversescale: true,
        colorbar: { title: { text: "C3 [km²/s²]" }, thickness: 14 },
        hovertemplate:
          "Departure: %{y}<br>Arrival: %{x}<br>TOF: %{customdata[0]:.1f} days<br>C3: %{customdata[1]:.2f} km²/s²<br>Earth v∞: %{customdata[2]:.3f} km/s<br>Mars v∞: %{customdata[3]:.3f} km/s<extra></extra>",
      },
    ];

    const markers: Array<[PorkchopCandidate, string, string]> = [];
    const minC3 = grid.candidates.minimum_c3;
    const minVinf = grid.candidates.minimum_mars_vinf;
    if (minC3) {
      markers.push([minC3, "star", "Minimum C3"]);
    }
    if (
      minVinf &&
      (!minC3 ||
        minVinf.departure_index !== minC3.departure_index ||
        minVinf.arrival_index !== minC3.arrival_index)
    ) {
      markers.push([minVinf, "diamond", "Minimum Arrival v∞"]);
    }
    for (const [cand, symbol, name] of markers) {
      traces.push({
        type: "scatter",
        mode: "markers",
        x: [toDateInput(cand.arrival_utc)],
        y: [toDateInput(cand.departure_utc)],
        name,
        marker: {
          symbol,
          size: 11,
          color: "#ffffff",
          line: { color: "#000000", width: 1 },
        },
        hovertemplate: `${name}<br>C3: ${cand.c3_km2_s2.toFixed(3)} km²/s²<extra></extra>`,
      });
    }

    const layout: Partial<Plotly.Layout> = {
      paper_bgcolor: "#0b0d11",
      plot_bgcolor: "#0b0d11",
      font: { color: "#c5cad1", size: 11, family: "Segoe UI, sans-serif" },
      margin: { l: 70, r: 18, t: 24, b: 56 },
      xaxis: { title: { text: "Arrival date (UTC)" }, gridcolor: "#2a303a" },
      yaxis: { title: { text: "Departure date (UTC)" }, gridcolor: "#2a303a" },
      legend: { orientation: "h", y: -0.18 },
    };

    const plot = node as unknown as Plotly.PlotlyHTMLElement;
    void Plotly.react(plot, traces, layout, {
      displaylogo: false,
      responsive: true,
    }).then(() => {
      plot.on("plotly_click", (event: Plotly.PlotMouseEvent) => {
        const pt = event.points[0];
        if (pt === undefined) {
          return;
        }
        const index = pt.pointIndex;
        let i: number;
        let j: number;
        if (Array.isArray(index)) {
          i = Number(index[0]);
          j = Number(index[1]);
        } else {
          i = y.indexOf(String(pt.y));
          j = x.indexOf(String(pt.x));
        }
        if (!Number.isFinite(i) || !Number.isFinite(j)) {
          i = y.indexOf(String(pt.y));
          j = x.indexOf(String(pt.x));
        }
        if (i < 0 || j < 0) {
          return;
        }
        if (!grid.valid[i]?.[j]) {
          return;
        }
        onSelectRef.current(grid.departure_utc[i], grid.arrival_utc[j]);
      });
    });

    const onResize = () => {
      void Plotly.Plots.resize(plot);
    };
    window.addEventListener("resize", onResize);
    return () => {
      window.removeEventListener("resize", onResize);
      Plotly.purge(plot);
    };
  }, [grid]);

  return (
    <div className="plot-frame">
      <div ref={el} style={{ width: "100%", height: "100%" }} />
      <div className="plot-caption">
        C3 [km²/s²] from the Stage 3 engine. Invalid / skipped cells are blank.
        Color scale clipped at 50 km²/s² for display only.
      </div>
    </div>
  );
}
