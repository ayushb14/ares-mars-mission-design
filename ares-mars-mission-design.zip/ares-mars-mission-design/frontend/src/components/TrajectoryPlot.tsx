import { useEffect, useRef } from "react";
import Plotly from "plotly.js-dist-min";
import type { TrajectoryResponse } from "../types/ares";

const AU = 149597870.7;

export function TrajectoryPlot({ data }: { data: TrajectoryResponse | null }) {
  const el = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const node = el.current;
    if (!node) {
      return;
    }
    if (!data) {
      node.replaceChildren();
      return;
    }

    const xs = data.trajectory_points.map((p) => p.x_km / AU);
    const ys = data.trajectory_points.map((p) => p.y_km / AU);
    const zs = data.trajectory_points.map((p) => p.z_km / AU);
    const custom = data.trajectory_points.map((p) => [p.t_s / 86400]);

    const traces = [
      {
        type: "scatter3d",
        mode: "lines",
        x: xs,
        y: ys,
        z: zs,
        customdata: custom,
        name: "Lambert transfer",
        line: { color: "#d8dde3", width: 3 },
        hovertemplate:
          "TOF %{customdata[0]:.1f} d<br>x %{x:.4f} au<br>y %{y:.4f} au<br>z %{z:.4f} au<extra>transfer</extra>",
      },
      {
        type: "scatter3d",
        mode: "text+markers",
        x: [0],
        y: [0],
        z: [0],
        name: "Sun",
        text: ["Sun"],
        textposition: "top center",
        textfont: { size: 11, color: "#e6c35c" },
        marker: { size: 8, color: "#e6c35c" },
        hovertemplate: "Sun (NAIF 10)<extra></extra>",
      },
      {
        type: "scatter3d",
        mode: "text+markers",
        x: [data.earth.position_km[0] / AU],
        y: [data.earth.position_km[1] / AU],
        z: [data.earth.position_km[2] / AU],
        name: "Earth departure (399)",
        text: ["Earth"],
        textposition: "top center",
        textfont: { size: 11, color: "#5b9bd5" },
        marker: { size: 6, color: "#5b9bd5" },
        hovertemplate: "Earth body center (NAIF 399)<extra></extra>",
      },
      {
        type: "scatter3d",
        mode: "text+markers",
        x: [data.mars.position_km[0] / AU],
        y: [data.mars.position_km[1] / AU],
        z: [data.mars.position_km[2] / AU],
        name: "Mars arrival (4)",
        text: ["Mars"],
        textposition: "top center",
        textfont: { size: 11, color: "#c45c26" },
        marker: { size: 6, color: "#c45c26" },
        hovertemplate: "Mars system barycenter (NAIF 4)<extra></extra>",
      },
    ] as unknown as Plotly.Data[];

    const layout: Partial<Plotly.Layout> = {
      paper_bgcolor: "#0b0d11",
      plot_bgcolor: "#0b0d11",
      font: { color: "#c5cad1", size: 11, family: "Segoe UI, sans-serif" },
      margin: { l: 0, r: 0, t: 8, b: 0 },
      showlegend: true,
      legend: { x: 0.01, y: 0.99, bgcolor: "rgba(17,20,26,0.7)" },
      scene: {
        aspectmode: "data",
        xaxis: axis("X [au]"),
        yaxis: axis("Y [au]"),
        zaxis: axis("Z [au]"),
        bgcolor: "#0b0d11",
      },
    };

    const plot = node as unknown as Plotly.PlotlyHTMLElement;
    void Plotly.react(plot, traces, layout, {
      displaylogo: false,
      responsive: true,
      modeBarButtonsToRemove: ["toImage"],
    });

    const onResize = () => {
      void Plotly.Plots.resize(plot);
    };
    window.addEventListener("resize", onResize);
    return () => {
      window.removeEventListener("resize", onResize);
      Plotly.purge(plot);
    };
  }, [data]);

  return (
    <div className="plot-frame">
      <div ref={el} style={{ width: "100%", height: "100%" }} />
      {data ? (
        <div className="plot-caption">
          Heliocentric J2000 · AU · Plotly aspectmode=data (equal axis scale) ·
          transfer = two-body DOP853 samples of the Lambert arc, not a spline
        </div>
      ) : null}
    </div>
  );
}

function axis(title: string) {
  return {
    title: { text: title },
    gridcolor: "#2a303a",
    zerolinecolor: "#3d4552",
    color: "#8d949e",
    showbackground: false,
  };
}
