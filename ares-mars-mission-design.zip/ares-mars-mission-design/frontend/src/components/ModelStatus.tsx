import type { HealthResponse } from "../types/ares";

export function ModelStatus({ health }: { health: HealthResponse | null }) {
  return (
    <dl className="model">
      <dt>Model</dt>
      <dd>{health?.physics_model ?? "heliocentric two-body Lambert"}</dd>
      <dt>Frame</dt>
      <dd>{health?.frame ?? "J2000"}</dd>
      <dt>Earth</dt>
      <dd>NAIF {health?.earth_target ?? 399} — body center</dd>
      <dt>Mars target</dt>
      <dd>NAIF {health?.mars_target ?? 4} — system barycenter</dd>
      <dt>Observer</dt>
      <dd>Sun / NAIF {health?.observer ?? 10}</dd>
      <dt>Aberration</dt>
      <dd>{health?.aberration_correction ?? "NONE"}</dd>
    </dl>
  );
}
