import { useEffect, useState, type FormEvent } from "react";
import { ModelStatus } from "../components/ModelStatus";
import { TrajectoryPlot } from "../components/TrajectoryPlot";
import { getHealth, postTrajectory, toDateInput } from "../api/client";
import type { HealthResponse, TrajectoryResponse } from "../types/ares";

export function MissionDesign({
  departure,
  arrival,
  onDates,
  autoKey,
}: {
  departure: string;
  arrival: string;
  onDates: (departure: string, arrival: string) => void;
  autoKey: number;
}) {
  const [health, setHealth] = useState<HealthResponse | null>(null);
  const [result, setResult] = useState<TrajectoryResponse | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    getHealth()
      .then(setHealth)
      .catch(() => setHealth(null));
  }, []);

  async function calculate(dep = departure, arr = arrival) {
    setLoading(true);
    setError(null);
    try {
      const body = await postTrajectory(dep, arr);
      setResult(body);
    } catch (err) {
      setResult(null);
      setError(err instanceof Error ? err.message : "ARES physics engine unavailable.");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    void calculate();
    // Recalculate when the porkchop workflow bumps autoKey or dates change from parent.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [autoKey]);

  function onSubmit(event: FormEvent) {
    event.preventDefault();
    void calculate();
  }

  const kernelWarn =
    health && !health.kernels_loaded ? health.kernel_detail : null;

  return (
    <div className="workspace">
      <aside className="side">
        <div className="section-label">Mission parameters</div>
        <form onSubmit={onSubmit}>
          <div className="field">
            <label htmlFor="dep">Earth departure (UTC)</label>
            <input
              id="dep"
              type="date"
              value={toDateInput(departure)}
              onChange={(e) => onDates(e.target.value, arrival)}
            />
          </div>
          <div className="field" style={{ marginTop: 10 }}>
            <label htmlFor="arr">Mars arrival (UTC)</label>
            <input
              id="arr"
              type="date"
              value={toDateInput(arrival)}
              onChange={(e) => onDates(departure, e.target.value)}
            />
          </div>
          <div className="btn-row" style={{ marginTop: 14 }}>
            <button className="btn" type="submit" disabled={loading}>
              {loading ? "Computing…" : "Calculate"}
            </button>
          </div>
        </form>
        {kernelWarn ? <div className="banner warn">{kernelWarn}</div> : null}
        {error ? <div className="banner error">{error}</div> : null}
        {loading ? (
          <div className="banner info">Evaluating heliocentric two-body Lambert transfer.</div>
        ) : null}
        {result ? (
          <div className="banner info">
            {toDateInput(result.departure)} → {toDateInput(result.arrival)} ·{" "}
            {result.trajectory_points.length} two-body samples · endpoint check{" "}
            {result.verification_within_tolerance ? "PASS" : "FAIL"} (
            {result.verification_position_error_km.toExponential(2)} km)
          </div>
        ) : null}
        <p className="lede" style={{ marginTop: 8, fontSize: 12 }}>
          Defaults are the NASA/TM-2010-216764 Table 2 Type II civil dates, used as
          editable example parameters — not an ARES-claimed optimum.
        </p>
        <ModelStatus health={health} />
      </aside>
      <section className="main">
        <div className="plot-wrap">
          {result ? (
            <TrajectoryPlot data={result} />
          ) : (
            <div className="page">
              <p className="lede">
                No transfer yet. Set departure and arrival, then Calculate. The curve
                is a two-body DOP853 sample of the Lambert arc, not a decorative spline.
              </p>
            </div>
          )}
        </div>
        <div className="metrics">
          <Metric
            label="C3"
            value={result ? result.c3_km2_s2.toFixed(3) : "—"}
            unit="km²/s²"
          />
          <Metric
            label="Earth v∞"
            value={result ? result.earth_vinf_km_s.toFixed(3) : "—"}
            unit="km/s"
          />
          <Metric
            label="Mars v∞"
            value={result ? result.mars_vinf_km_s.toFixed(3) : "—"}
            unit="km/s"
          />
          <Metric
            label="TOF"
            value={result ? result.time_of_flight_days.toFixed(1) : "—"}
            unit="days"
          />
        </div>
      </section>
    </div>
  );
}

function Metric({
  label,
  value,
  unit,
}: {
  label: string;
  value: string;
  unit: string;
}) {
  return (
    <div className="metric">
      <div className="k">{label}</div>
      <div className="v">
        {value}
        <span className="u">{unit}</span>
      </div>
    </div>
  );
}
