import { useEffect, useState } from "react";
import { getHealth, getReferenceCase } from "../api/client";
import type { HealthResponse, ReferenceCaseResponse } from "../types/ares";

export function Validation() {
  const [health, setHealth] = useState<HealthResponse | null>(null);
  const [refCase, setRefCase] = useState<ReferenceCaseResponse | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    getHealth()
      .then(setHealth)
      .catch(() => setHealth(null));
    getReferenceCase()
      .then(setRefCase)
      .catch((err: unknown) => {
        setError(err instanceof Error ? err.message : "ARES physics engine unavailable.");
      });
  }, []);

  const t = refCase?.transfer ?? null;

  return (
    <div className="page">
      <h1>Validation</h1>
      <p className="lede">
        Compared against published NASA mission-design data. Using NAIF kernels does
        not mean this software is NASA-certified. ARES is a two-body Lambert
        mission-design tool, not a NASA product.
      </p>
      {error ? <div className="banner error">{error}</div> : null}

      <table className="table">
        <tbody>
          <tr>
            <th>Current model</th>
            <td>{health?.physics_model ?? "unavailable"}</td>
          </tr>
          <tr>
            <th>Ephemerides</th>
            <td>NASA/JPL NAIF SPICE, DE440 short kernel (de440s.bsp)</td>
          </tr>
          <tr>
            <th>Reference frame</th>
            <td>{health?.frame ?? "J2000"} / aberration {health?.aberration_correction ?? "NONE"}</td>
          </tr>
          <tr>
            <th>Earth</th>
            <td>
              Body center NAIF {health?.earth_target ?? 399} ({health?.earth_target_name ?? "EARTH"})
            </td>
          </tr>
          <tr>
            <th>Mars target</th>
            <td>
              System barycenter NAIF {health?.mars_target ?? 4} (
              {health?.mars_target_name ?? "MARS BARYCENTER"}) — not Mars body 499
            </td>
          </tr>
          <tr>
            <th>Observer</th>
            <td>Sun / NAIF {health?.observer ?? 10}</td>
          </tr>
          <tr>
            <th>Engine</th>
            <td>
              {health ? (
                <>
                  <span className={`status-dot ${health.kernels_loaded ? "" : "bad"}`} />
                  {health.engine} {health.version} · kernels{" "}
                  {health.kernels_loaded ? "loaded" : "missing"}
                </>
              ) : (
                "unavailable"
              )}
            </td>
          </tr>
        </tbody>
      </table>

      <h1 style={{ marginTop: 28 }}>NASA comparison (live ARES values)</h1>
      <p className="lede">
        NASA/TM-2010-216764 Table 2 Type II civil dates 2026-10-31 → 2027-08-19.
        NASA published C3 = 9.144 km²/s² (MIDAS patched-conic). ARES numbers below
        are computed now by the Python engine, not hardcoded in this page.
      </p>
      {t ? (
        <table className="table">
          <tbody>
            <tr>
              <th>ARES C3</th>
              <td className="mono">{t.c3_km2_s2.toFixed(3)} km²/s²</td>
            </tr>
            <tr>
              <th>ARES Earth v∞</th>
              <td className="mono">{t.earth_vinf_km_s.toFixed(3)} km/s</td>
            </tr>
            <tr>
              <th>ARES Mars v∞</th>
              <td className="mono">{t.mars_vinf_km_s.toFixed(3)} km/s</td>
            </tr>
            <tr>
              <th>ARES TOF</th>
              <td className="mono">{t.time_of_flight_days.toFixed(1)} days</td>
            </tr>
            <tr>
              <th>NASA published C3</th>
              <td className="mono">
                {refCase?.nasa_published_c3_km2_s2.toFixed(3)} km²/s² ({refCase?.nasa_source})
              </td>
            </tr>
          </tbody>
        </table>
      ) : (
        <div className="banner info">ARES comparison values unavailable.</div>
      )}
      <p className="lede">{refCase?.note}</p>

      <h1 style={{ marginTop: 28 }}>Automated tests</h1>
      <p className="lede">
        Stage 1–3 physics plus Stage 4 API tests run with pytest. Stage 2 Lambert
        endpoint is checked by two-body DOP853 (≤ 1 km). Stage 3 grid C3 is required
        to match compute_earth_mars_transfer C3. This page does not execute pytest;
        it reports the model, not a live CI badge.
      </p>

      <h1 style={{ marginTop: 28 }}>Not modeled</h1>
      <p className="lede">
        n-body cruise, deep-space maneuvers, finite burns, launch-vehicle performance,
        parking-orbit ΔV, Mars orbit insertion ΔV, atmosphere, EDL, spacecraft mass,
        propellant, communications, or surface mission. C3 is characteristic energy,
        not launch ΔV. Earth v∞ is not pad ΔV. Mars v∞ is not MOI ΔV.
      </p>
    </div>
  );
}
