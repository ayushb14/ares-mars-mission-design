import { useState, type FormEvent } from "react";
import { useNavigate } from "react-router-dom";
import { postPorkchop, toDateInput } from "../api/client";
import { PorkchopPlot } from "../components/PorkchopPlot";
import type { PorkchopCandidate, PorkchopResponse } from "../types/ares";

export function LaunchWindow({
  onOpenTrajectory,
}: {
  onOpenTrajectory: (departure: string, arrival: string) => void;
}) {
  const navigate = useNavigate();
  const [depStart, setDepStart] = useState("2026-07-01");
  const [depEnd, setDepEnd] = useState("2027-03-01");
  const [arrStart, setArrStart] = useState("2027-03-01");
  const [arrEnd, setArrEnd] = useState("2028-06-01");
  const [step, setStep] = useState("5");
  const [minTof, setMinTof] = useState("100");
  const [maxTof, setMaxTof] = useState("500");
  const [grid, setGrid] = useState<PorkchopResponse | null>(null);
  const [selected, setSelected] = useState<PorkchopCandidate | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function generate(event?: FormEvent) {
    event?.preventDefault();
    setLoading(true);
    setError(null);
    setSelected(null);
    try {
      const body = await postPorkchop({
        departure_start: depStart,
        departure_end: depEnd,
        arrival_start: arrStart,
        arrival_end: arrEnd,
        step_days: Number(step),
        min_tof_days: Number(minTof),
        max_tof_days: Number(maxTof),
      });
      setGrid(body);
    } catch (err) {
      setGrid(null);
      setError(err instanceof Error ? err.message : "ARES physics engine unavailable.");
    } finally {
      setLoading(false);
    }
  }

  function pick(departureUtc: string, arrivalUtc: string) {
    setSelected({
      name: "Selected grid cell",
      key: "selected",
      departure_utc: departureUtc,
      arrival_utc: arrivalUtc,
      tof_days: 0,
      c3_km2_s2: 0,
      earth_vinf_km_s: 0,
      mars_vinf_km_s: 0,
      departure_index: 0,
      arrival_index: 0,
    });
    if (grid) {
      const i = grid.departure_utc.indexOf(departureUtc);
      const j = grid.arrival_utc.indexOf(arrivalUtc);
      if (i >= 0 && j >= 0 && grid.valid[i][j]) {
        setSelected({
          name: "Selected grid cell",
          key: "selected",
          departure_utc: departureUtc,
          arrival_utc: arrivalUtc,
          tof_days: grid.tof_days[i][j] ?? 0,
          c3_km2_s2: grid.c3_km2_s2[i][j] ?? 0,
          earth_vinf_km_s: grid.earth_vinf_km_s[i][j] ?? 0,
          mars_vinf_km_s: grid.mars_vinf_km_s[i][j] ?? 0,
          departure_index: i,
          arrival_index: j,
        });
      }
    }
  }

  function openTrajectory(dep: string, arr: string) {
    onOpenTrajectory(dep, arr);
    void navigate("/");
  }

  return (
    <div className="launch">
      <aside className="side">
        <div className="section-label">Launch window</div>
        <form onSubmit={(e) => void generate(e)}>
          <div className="field">
            <label htmlFor="dep-start">Departure start (UTC)</label>
            <input id="dep-start" type="date" value={depStart} onChange={(e) => setDepStart(e.target.value)} />
          </div>
          <div className="field" style={{ marginTop: 8 }}>
            <label htmlFor="dep-end">Departure end (UTC)</label>
            <input id="dep-end" type="date" value={depEnd} onChange={(e) => setDepEnd(e.target.value)} />
          </div>
          <div className="field" style={{ marginTop: 8 }}>
            <label htmlFor="arr-start">Arrival start (UTC)</label>
            <input id="arr-start" type="date" value={arrStart} onChange={(e) => setArrStart(e.target.value)} />
          </div>
          <div className="field" style={{ marginTop: 8 }}>
            <label htmlFor="arr-end">Arrival end (UTC)</label>
            <input id="arr-end" type="date" value={arrEnd} onChange={(e) => setArrEnd(e.target.value)} />
          </div>
          <div className="field" style={{ marginTop: 8 }}>
            <label htmlFor="step">Step [days]</label>
            <input id="step" value={step} onChange={(e) => setStep(e.target.value)} />
          </div>
          <div className="field" style={{ marginTop: 8 }}>
            <label htmlFor="min-tof">Min TOF [days]</label>
            <input id="min-tof" value={minTof} onChange={(e) => setMinTof(e.target.value)} />
          </div>
          <div className="field" style={{ marginTop: 8 }}>
            <label htmlFor="max-tof">Max TOF [days]</label>
            <input id="max-tof" value={maxTof} onChange={(e) => setMaxTof(e.target.value)} />
          </div>
          <div className="btn-row" style={{ marginTop: 12 }}>
            <button className="btn" type="submit" disabled={loading}>
              {loading ? "Solving…" : "Generate"}
            </button>
          </div>
        </form>
        {loading ? (
          <div className="banner info">
            Serial Lambert grid. The default 5-day 2026/27 window is a few thousand
            cells and typically finishes in a few seconds.
          </div>
        ) : null}
        {error ? <div className="banner error">{error}</div> : null}
        {grid ? (
          <div className="banner info">
            {grid.n_departure} × {grid.n_arrival} = {grid.n_potential} cells ·{" "}
            {grid.n_lambert_success} valid · {grid.n_skipped_tof} skipped ·{" "}
            {grid.runtime_s.toFixed(2)} s
            <br />
            Cap {grid.max_cells} cells (rejected if exceeded, not truncated).
          </div>
        ) : null}
        {grid ? (
          <div className="candidates">
            <div className="section-label">Candidates (grid extrema, not “best mission”)</div>
            {Object.values(grid.candidates)
              .filter((c) => c.key !== "minimum_earth_vinf")
              .map((cand) => (
                <button
                  key={cand.key}
                  className="cand"
                  type="button"
                  onClick={() => pick(cand.departure_utc, cand.arrival_utc)}
                >
                  <div className="name">{cand.name}</div>
                  <div className="mono">
                    {toDateInput(cand.departure_utc)} → {toDateInput(cand.arrival_utc)}
                  </div>
                  <div>
                    C3 {cand.c3_km2_s2.toFixed(3)} km²/s² · Mars v∞{" "}
                    {cand.mars_vinf_km_s.toFixed(3)} km/s · TOF {cand.tof_days.toFixed(0)} d
                  </div>
                </button>
              ))}
          </div>
        ) : null}
        {selected ? (
          <div>
            <div className="section-label">Selected cell</div>
            <div className="mono">
              {toDateInput(selected.departure_utc)} → {toDateInput(selected.arrival_utc)}
            </div>
            <div>
              C3 {selected.c3_km2_s2.toFixed(3)} km²/s² · Earth v∞{" "}
              {selected.earth_vinf_km_s.toFixed(3)} km/s · Mars v∞{" "}
              {selected.mars_vinf_km_s.toFixed(3)} km/s
            </div>
            <button
              className="btn"
              style={{ marginTop: 10 }}
              type="button"
              onClick={() =>
                openTrajectory(selected.departure_utc, selected.arrival_utc)
              }
            >
              Open trajectory
            </button>
          </div>
        ) : (
          <p className="lede" style={{ fontSize: 12 }}>
            Click a valid heatmap cell, then Open trajectory. That recomputes Stage 2
            through the API — it does not interpolate the chart.
          </p>
        )}
      </aside>
      <div className="plot-wrap">
        {grid ? (
          <PorkchopPlot grid={grid} onSelect={pick} />
        ) : (
          <div className="page">
            <p className="lede">
              Generate a C3 porkchop from the validated Stage 3 engine. Axes are arrival
              (x) and departure (y). Color is C3 [km²/s²], not launch ΔV.
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
