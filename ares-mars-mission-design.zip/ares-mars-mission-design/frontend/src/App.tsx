import { useMemo, useState } from "react";
import { NavLink, Navigate, Route, Routes } from "react-router-dom";
import { LaunchWindow } from "./pages/LaunchWindow";
import { MissionDesign } from "./pages/MissionDesign";
import { Validation } from "./pages/Validation";

const DEFAULT_DEP = "2026-10-31";
const DEFAULT_ARR = "2027-08-19";

export default function App() {
  const [departure, setDeparture] = useState(DEFAULT_DEP);
  const [arrival, setArrival] = useState(DEFAULT_ARR);
  const [autoKey, setAutoKey] = useState(0);

  const setMission = useMemo(
    () => (dep: string, arr: string, recalc = false) => {
      setDeparture(dep);
      setArrival(arr);
      if (recalc) {
        setAutoKey((k) => k + 1);
      }
    },
    [],
  );

  return (
    <div className="app">
      <header className="topbar">
        <div className="brand">
          <span className="brand-mark">ARES</span>
          <span className="brand-sub">Mars mission design</span>
        </div>
        <nav className="nav">
          <NavLink to="/" end className={({ isActive }) => (isActive ? "active" : "")}>
            Mission design
          </NavLink>
          <NavLink to="/window" className={({ isActive }) => (isActive ? "active" : "")}>
            Launch window
          </NavLink>
          <NavLink to="/validation" className={({ isActive }) => (isActive ? "active" : "")}>
            Validation
          </NavLink>
        </nav>
      </header>
      <Routes>
        <Route
          path="/"
          element={
            <MissionDesign
              departure={departure}
              arrival={arrival}
              onDates={(d, a) => setMission(d, a)}
              autoKey={autoKey}
            />
          }
        />
        <Route
          path="/window"
          element={
            <LaunchWindow
              onOpenTrajectory={(d, a) => {
                setMission(d, a, true);
              }}
            />
          }
        />
        <Route path="/validation" element={<Validation />} />
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </div>
  );
}
