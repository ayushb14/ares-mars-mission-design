import type {
  ApiErrorBody,
  HealthResponse,
  PorkchopResponse,
  ReferenceCaseResponse,
  TrajectoryResponse,
} from "../types/ares";

const API_BASE = import.meta.env.VITE_API_BASE ?? "";

async function parseError(response: Response): Promise<string> {
  try {
    const body = (await response.json()) as ApiErrorBody;
    if (typeof body.detail === "string" && body.detail.trim()) {
      return body.detail;
    }
    if (Array.isArray(body.detail)) {
      const messages = body.detail
        .map((item) => (typeof item.msg === "string" ? item.msg : ""))
        .filter((msg) => msg.length > 0);
      if (messages.length > 0) {
        return messages.join(" ");
      }
    }
  } catch {
    /* ignore */
  }
  if (response.status >= 500) {
    return "ARES physics engine unavailable.";
  }
  return `Request failed (${response.status}).`;
}

async function request<T>(path: string, init?: RequestInit): Promise<T> {
  let response: Response;
  try {
    response = await fetch(`${API_BASE}${path}`, {
      ...init,
      headers: {
        "Content-Type": "application/json",
        ...(init?.headers ?? {}),
      },
    });
  } catch {
    throw new Error("ARES physics engine unavailable.");
  }
  if (!response.ok) {
    throw new Error(await parseError(response));
  }
  return (await response.json()) as T;
}

export function toEngineUtc(dateYmd: string): string {
  if (dateYmd.includes("T")) {
    return dateYmd;
  }
  return `${dateYmd}T00:00:00`;
}

export function toDateInput(utc: string): string {
  return utc.replace(" UTC", "").slice(0, 10);
}

export function getHealth(): Promise<HealthResponse> {
  return request<HealthResponse>("/api/health");
}

export function postTrajectory(
  departure: string,
  arrival: string,
  nPoints = 201,
): Promise<TrajectoryResponse> {
  return request<TrajectoryResponse>("/api/trajectory", {
    method: "POST",
    body: JSON.stringify({
      departure: toEngineUtc(departure),
      arrival: toEngineUtc(arrival),
      n_points: nPoints,
    }),
  });
}

export function postPorkchop(body: {
  departure_start: string;
  departure_end: string;
  arrival_start: string;
  arrival_end: string;
  step_days: number;
  min_tof_days: number;
  max_tof_days: number;
}): Promise<PorkchopResponse> {
  return request<PorkchopResponse>("/api/porkchop", {
    method: "POST",
    body: JSON.stringify({
      departure_start: toEngineUtc(body.departure_start),
      departure_end: toEngineUtc(body.departure_end),
      arrival_start: toEngineUtc(body.arrival_start),
      arrival_end: toEngineUtc(body.arrival_end),
      step_days: body.step_days,
      min_tof_days: body.min_tof_days,
      max_tof_days: body.max_tof_days,
    }),
  });
}

export function getReferenceCase(): Promise<ReferenceCaseResponse> {
  return request<ReferenceCaseResponse>("/api/reference-case");
}
