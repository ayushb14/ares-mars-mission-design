"""Stage 3 porkchop grid tests. Tiny grids only; production CLI is not run here."""

from __future__ import annotations

from pathlib import Path

import numpy as np
import pytest

from ares.errors import LambertError, TrajectoryError
from ares.porkchop import (
    MAX_PORKCHOP_CELLS,
    STATUS_LAMBERT_FAIL,
    STATUS_SKIP_TOF,
    STATUS_VALID,
    cell_indices,
    compute_porkchop,
    export_csv,
    plot_porkchop_html,
    refine_around,
    select_candidates,
    utc_date_grid,
)
from ares.time import parse_utc
from ares.trajectory import compute_earth_mars_transfer

REFERENCE_DEPARTURE = "2026-10-31T00:00:00"
REFERENCE_ARRIVAL = "2027-09-07T00:00:00"


def test_date_grid_inclusive_and_ordered() -> None:
    dates = utc_date_grid("2026-07-01T00:00:00", "2026-07-16T00:00:00", 5.0)
    canonical = [parse_utc(d)[:10] for d in dates]
    assert canonical[0] == "2026-07-01"
    assert canonical[-1] == "2026-07-16"
    assert canonical == ["2026-07-01", "2026-07-06", "2026-07-11", "2026-07-16"]
    for earlier, later in zip(dates, dates[1:]):
        assert parse_utc(earlier) < parse_utc(later)


def test_date_grid_appends_end_when_not_on_step() -> None:
    dates = utc_date_grid("2026-07-01T00:00:00", "2026-07-10T00:00:00", 5.0)
    canonical = [parse_utc(d)[:10] for d in dates]
    assert canonical == ["2026-07-01", "2026-07-06", "2026-07-10"]


def test_date_grid_rejects_bad_step_and_order() -> None:
    with pytest.raises(TrajectoryError, match="positive"):
        utc_date_grid("2026-07-01T00:00:00", "2026-07-10T00:00:00", 0.0)
    with pytest.raises(TrajectoryError, match="before start"):
        utc_date_grid("2026-07-10T00:00:00", "2026-07-01T00:00:00", 5.0)


def test_grid_dimensions(spice_kernels) -> None:
    del spice_kernels
    grid = compute_porkchop(
        "2026-10-29T00:00:00",
        "2026-11-02T00:00:00",
        "2027-09-05T00:00:00",
        "2027-09-09T00:00:00",
        step_days=2.0,
        min_tof_days=100.0,
        max_tof_days=500.0,
    )
    assert grid.n_departure == 3
    assert grid.n_arrival == 3
    assert grid.n_potential == 9
    assert grid.c3_km2_s2.shape == (3, 3)
    assert grid.valid.shape == (3, 3)
    assert grid.n_lambert_success + grid.n_lambert_failed + grid.n_skipped_tof == 9


def test_grid_safety_cap_rejects_without_truncating() -> None:
    with pytest.raises(TrajectoryError, match="safety cap"):
        compute_porkchop(
            "2026-07-01T00:00:00",
            "2027-03-01T00:00:00",
            "2027-03-01T00:00:00",
            "2028-06-01T00:00:00",
            step_days=0.5,
            min_tof_days=100.0,
            max_tof_days=500.0,
        )
    assert MAX_PORKCHOP_CELLS == 12_000


def test_tof_bounds_rejected() -> None:
    with pytest.raises(TrajectoryError, match="min_tof_days"):
        compute_porkchop(
            "2026-10-31T00:00:00",
            "2026-10-31T00:00:00",
            "2027-09-07T00:00:00",
            "2027-09-07T00:00:00",
            min_tof_days=200.0,
            max_tof_days=100.0,
        )


def test_invalid_tof_is_masked_not_zero(spice_kernels) -> None:
    del spice_kernels
    # 311-day reference pair is outside a 100–200 day gate.
    grid = compute_porkchop(
        REFERENCE_DEPARTURE,
        REFERENCE_DEPARTURE,
        REFERENCE_ARRIVAL,
        REFERENCE_ARRIVAL,
        step_days=1.0,
        min_tof_days=100.0,
        max_tof_days=200.0,
    )
    assert grid.n_departure == 1
    assert grid.n_arrival == 1
    assert grid.n_potential == 1
    assert not grid.valid[0, 0]
    assert int(grid.status[0, 0]) == STATUS_SKIP_TOF
    assert np.isnan(grid.c3_km2_s2[0, 0])
    assert np.isnan(grid.earth_vinf_km_s[0, 0])
    assert np.isnan(grid.mars_vinf_km_s[0, 0])
    assert np.isnan(grid.tof_days[0, 0])
    assert grid.n_skipped_tof == 1
    assert grid.n_lambert_success == 0


def test_arrival_before_departure_is_skipped(spice_kernels) -> None:
    del spice_kernels
    grid = compute_porkchop(
        "2027-09-07T00:00:00",
        "2027-09-07T00:00:00",
        "2026-10-31T00:00:00",
        "2026-10-31T00:00:00",
        step_days=1.0,
        min_tof_days=0.0,
        max_tof_days=500.0,
    )
    assert not grid.valid[0, 0]
    assert int(grid.status[0, 0]) == STATUS_SKIP_TOF
    assert np.isnan(grid.c3_km2_s2[0, 0])


def test_grid_matches_direct_stage2_reference(spice_kernels) -> None:
    del spice_kernels
    grid = compute_porkchop(
        REFERENCE_DEPARTURE,
        REFERENCE_DEPARTURE,
        REFERENCE_ARRIVAL,
        REFERENCE_ARRIVAL,
        step_days=1.0,
        min_tof_days=100.0,
        max_tof_days=500.0,
    )
    assert grid.valid[0, 0]
    assert grid.n_departure == 1 and grid.n_arrival == 1
    assert int(grid.status[0, 0]) == STATUS_VALID
    assert np.isfinite(grid.c3_km2_s2[0, 0])

    direct = compute_earth_mars_transfer(REFERENCE_DEPARTURE, REFERENCE_ARRIVAL)
    assert grid.c3_km2_s2[0, 0] == pytest.approx(direct.c3_km2_s2, rel=1e-12, abs=1e-12)
    assert grid.earth_vinf_km_s[0, 0] == pytest.approx(
        direct.earth_vinf.magnitude_km_s, rel=1e-12, abs=1e-12
    )
    assert grid.mars_vinf_km_s[0, 0] == pytest.approx(
        direct.mars_vinf.magnitude_km_s, rel=1e-12, abs=1e-12
    )
    assert grid.tof_days[0, 0] == pytest.approx(
        direct.time_of_flight_days, rel=1e-12, abs=1e-9
    )
    i, j = cell_indices(grid, REFERENCE_DEPARTURE, REFERENCE_ARRIVAL)
    assert (i, j) == (0, 0)


def test_c3_is_earth_vinf_squared_on_grid(spice_kernels) -> None:
    del spice_kernels
    grid = compute_porkchop(
        "2026-10-29T00:00:00",
        "2026-11-02T00:00:00",
        "2027-09-05T00:00:00",
        "2027-09-09T00:00:00",
        step_days=2.0,
        min_tof_days=100.0,
        max_tof_days=500.0,
    )
    assert grid.n_departure == 3
    assert grid.n_arrival == 3
    assert grid.c3_km2_s2.shape == (3, 3)
    assert np.any(grid.valid)
    for i in range(grid.n_departure):
        for j in range(grid.n_arrival):
            if not grid.valid[i, j]:
                assert np.isnan(grid.c3_km2_s2[i, j])
                continue
            assert np.isfinite(grid.c3_km2_s2[i, j])
            assert grid.c3_km2_s2[i, j] == pytest.approx(
                grid.earth_vinf_km_s[i, j] ** 2, rel=1e-12, abs=1e-12
            )
            assert grid.tof_days[i, j] > 0.0


def test_candidate_selection_and_filter(spice_kernels) -> None:
    del spice_kernels
    grid = compute_porkchop(
        "2026-10-29T00:00:00",
        "2026-11-02T00:00:00",
        "2027-09-05T00:00:00",
        "2027-09-09T00:00:00",
        step_days=2.0,
        min_tof_days=100.0,
        max_tof_days=500.0,
    )
    found = select_candidates(grid)
    assert "minimum_c3" in found
    assert "minimum_earth_vinf" in found
    assert "minimum_mars_vinf" in found
    assert "shortest_tof" in found
    c3 = found["minimum_c3"]
    assert c3.name == "Minimum C3 Candidate"
    # C3 = |v∞,E|², so the two minima occupy the same cell.
    assert found["minimum_earth_vinf"].departure_index == c3.departure_index
    assert found["minimum_earth_vinf"].arrival_index == c3.arrival_index
    assert c3.c3_km2_s2 == pytest.approx(np.nanmin(np.where(grid.valid, grid.c3_km2_s2, np.nan)))
    assert found["shortest_tof"].name == "Shortest TOF Candidate"
    assert found["minimum_mars_vinf"].name == "Minimum Arrival v∞ Candidate"

    empty = select_candidates(grid, max_c3=-1.0)
    assert empty == {}


def test_csv_export_does_not_encode_failure_as_zero(spice_kernels, tmp_path: Path) -> None:
    del spice_kernels
    grid = compute_porkchop(
        REFERENCE_DEPARTURE,
        REFERENCE_DEPARTURE,
        REFERENCE_ARRIVAL,
        REFERENCE_ARRIVAL,
        step_days=1.0,
        min_tof_days=100.0,
        max_tof_days=200.0,
    )
    path = export_csv(grid, tmp_path / "tiny.csv")
    text = path.read_text(encoding="utf-8")
    lines = text.strip().splitlines()
    assert lines[0].startswith("departure_utc,arrival_utc,tof_days,c3_km2_s2")
    row = lines[1].split(",")
    # valid,status are the last two fields; numerics for an invalid cell are empty.
    assert row[-2] == "false"
    assert row[-1] == "skipped_tof"
    assert row[2] == ""
    assert row[3] == ""


def test_csv_export_valid_cell(spice_kernels, tmp_path: Path) -> None:
    del spice_kernels
    grid = compute_porkchop(
        REFERENCE_DEPARTURE,
        REFERENCE_DEPARTURE,
        REFERENCE_ARRIVAL,
        REFERENCE_ARRIVAL,
        step_days=1.0,
    )
    path = export_csv(grid, tmp_path / "ok.csv")
    lines = path.read_text(encoding="utf-8").strip().splitlines()
    row = lines[1].split(",")
    assert row[-2] == "true"
    assert row[-1] == "valid"
    assert float(row[3]) == pytest.approx(grid.c3_km2_s2[0, 0])


def test_lambert_failure_is_nan_not_zero(spice_kernels, monkeypatch) -> None:
    del spice_kernels
    import ares.porkchop as pc

    def boom(*_args, **_kwargs):
        raise LambertError("forced Lambert failure for grid test")

    monkeypatch.setattr(pc, "lambert_energetics", boom)
    grid = pc.compute_porkchop(
        REFERENCE_DEPARTURE,
        REFERENCE_DEPARTURE,
        REFERENCE_ARRIVAL,
        REFERENCE_ARRIVAL,
        step_days=1.0,
    )
    assert grid.n_lambert_failed == 1
    assert grid.n_lambert_success == 0
    assert not grid.valid[0, 0]
    assert int(grid.status[0, 0]) == STATUS_LAMBERT_FAIL
    assert np.isnan(grid.c3_km2_s2[0, 0])
    assert not (grid.c3_km2_s2[0, 0] == 0.0)


def test_planetary_states_are_cached(spice_kernels, monkeypatch) -> None:
    del spice_kernels
    import ares.porkchop as pc

    counts = {"earth": 0, "mars": 0}
    real_earth = pc.earth_heliocentric_state
    real_mars = pc.mars_heliocentric_state

    def earth(utc, **kwargs):
        counts["earth"] += 1
        return real_earth(utc, **kwargs)

    def mars(utc, **kwargs):
        counts["mars"] += 1
        return real_mars(utc, **kwargs)

    monkeypatch.setattr(pc, "earth_heliocentric_state", earth)
    monkeypatch.setattr(pc, "mars_heliocentric_state", mars)
    grid = pc.compute_porkchop(
        "2026-10-29T00:00:00",
        "2026-11-02T00:00:00",
        "2027-09-05T00:00:00",
        "2027-09-09T00:00:00",
        step_days=2.0,
    )
    assert grid.n_departure == 3
    assert grid.n_arrival == 3
    assert counts["earth"] == 3
    assert counts["mars"] == 3
    assert grid.earth_states_cached == 3
    assert grid.mars_states_cached == 3
    # 9 Lambert cells, not 9+9 SPICE lookups.
    assert counts["earth"] * counts["mars"] == grid.n_potential


def test_cli_tiny_grid(spice_kernels, tmp_path: Path, capsys) -> None:
    del spice_kernels
    from ares.porkchop import main

    prefix = tmp_path / "tiny_porkchop"
    rc = main(
        [
            "--departure-start",
            REFERENCE_DEPARTURE,
            "--departure-end",
            REFERENCE_DEPARTURE,
            "--arrival-start",
            REFERENCE_ARRIVAL,
            "--arrival-end",
            REFERENCE_ARRIVAL,
            "--step-days",
            "1",
            "--min-tof",
            "100",
            "--max-tof",
            "500",
            "--output",
            str(prefix),
            "--no-plot",
        ]
    )
    assert rc == 0
    out = capsys.readouterr().out
    assert "Minimum C3 Candidate" in out
    assert "not launch ΔV" in out
    assert "EARTH (NAIF 399)" in out
    assert "MARS BARYCENTER (NAIF 4)" in out
    assert "SUN (NAIF 10)" in out
    assert "body center" in out
    assert "system barycenter" in out
    assert prefix.with_suffix(".csv").is_file()


def test_refine_around_uses_finer_step(spice_kernels) -> None:
    del spice_kernels
    coarse = compute_porkchop(
        REFERENCE_DEPARTURE,
        REFERENCE_DEPARTURE,
        REFERENCE_ARRIVAL,
        REFERENCE_ARRIVAL,
        step_days=1.0,
    )
    cand = select_candidates(coarse)["minimum_c3"]
    refined = refine_around(coarse, cand, half_width_days=1.0, step_days=1.0)
    assert refined.step_days == 1.0
    assert refined.n_departure >= 2
    assert refined.n_arrival >= 2
    i, j = cell_indices(refined, REFERENCE_DEPARTURE, REFERENCE_ARRIVAL)
    assert refined.valid[i, j]
    assert refined.c3_km2_s2[i, j] == pytest.approx(coarse.c3_km2_s2[0, 0], rel=1e-12)


def test_plot_html_contains_c3_label(spice_kernels, tmp_path: Path) -> None:
    del spice_kernels
    grid = compute_porkchop(
        REFERENCE_DEPARTURE,
        REFERENCE_DEPARTURE,
        REFERENCE_ARRIVAL,
        REFERENCE_ARRIVAL,
        step_days=1.0,
    )
    path = plot_porkchop_html(grid, tmp_path / "porkchop.html")
    html = path.read_text(encoding="utf-8")
    assert "C3" in html
    assert "km" in html
