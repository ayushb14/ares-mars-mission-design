"""FastAPI layer tests. Physics must match the Python engine exactly."""

from __future__ import annotations

import pytest
from fastapi.testclient import TestClient

from ares.api.main import create_app
from ares.constants import (
    DEFAULT_FRAME,
    DEFAULT_MISSION_ARRIVAL_UTC,
    DEFAULT_MISSION_DEPARTURE_UTC,
    NAIF_EARTH,
    NAIF_MARS_BARYCENTER,
    NAIF_SUN,
    PHYSICS_MODEL,
)
from ares.porkchop import MAX_PORKCHOP_CELLS, compute_porkchop, select_candidates
from ares.trajectory import compute_earth_mars_transfer

NASA_DEP = DEFAULT_MISSION_DEPARTURE_UTC
NASA_ARR = DEFAULT_MISSION_ARRIVAL_UTC


@pytest.fixture(scope="module")
def client(spice_kernels):
    del spice_kernels
    with TestClient(create_app()) as test_client:
        yield test_client


def test_health_uses_engine_constants(client) -> None:
    response = client.get("/api/health")
    assert response.status_code == 200
    body = response.json()
    assert body["engine"] == "ARES"
    assert body["physics_model"] == PHYSICS_MODEL
    assert body["frame"] == DEFAULT_FRAME
    assert body["earth_target"] == NAIF_EARTH
    assert body["mars_target"] == NAIF_MARS_BARYCENTER
    assert body["observer"] == NAIF_SUN
    assert body["kernels_loaded"] is True
    assert body["max_porkchop_cells"] == MAX_PORKCHOP_CELLS


def test_trajectory_matches_python_engine(client) -> None:
    direct = compute_earth_mars_transfer(NASA_DEP, NASA_ARR)
    response = client.post(
        "/api/trajectory",
        json={"departure": NASA_DEP, "arrival": NASA_ARR, "n_points": 21},
    )
    assert response.status_code == 200
    body = response.json()
    assert body["c3_km2_s2"] == pytest.approx(direct.c3_km2_s2, rel=1e-12, abs=1e-12)
    assert body["earth_vinf_km_s"] == pytest.approx(
        direct.earth_vinf.magnitude_km_s, rel=1e-12, abs=1e-12
    )
    assert body["mars_vinf_km_s"] == pytest.approx(
        direct.mars_vinf.magnitude_km_s, rel=1e-12, abs=1e-12
    )
    # Frozen Stage 3 / reference-body audit regression (not NASA Table 2 9.144).
    assert body["c3_km2_s2"] == pytest.approx(9.184131505524, abs=1e-12)
    assert body["earth_vinf_km_s"] == pytest.approx(3.030533204821, abs=1e-12)
    assert body["mars_vinf_km_s"] == pytest.approx(2.728453965898, abs=1e-12)
    assert body["time_of_flight_days"] == pytest.approx(
        direct.time_of_flight_days, rel=1e-12, abs=1e-9
    )
    assert body["earth_target_id"] == NAIF_EARTH
    assert body["mars_target_id"] == NAIF_MARS_BARYCENTER
    assert body["observer_id"] == NAIF_SUN
    assert len(body["trajectory_points"]) == 21
    p0 = body["trajectory_points"][0]
    assert p0["x_km"] == pytest.approx(direct.earth_position_km[0], abs=1e-6)


def test_trajectory_rejects_invalid_dates(client) -> None:
    bad = client.post(
        "/api/trajectory",
        json={"departure": NASA_ARR, "arrival": NASA_DEP},
    )
    assert bad.status_code == 400
    assert "detail" in bad.json()
    calendar = client.post(
        "/api/trajectory",
        json={"departure": "2026-02-30T00:00:00", "arrival": NASA_ARR},
    )
    assert calendar.status_code == 400


def test_porkchop_matches_python_engine(client) -> None:
    grid = compute_porkchop(
        NASA_DEP,
        NASA_DEP,
        NASA_ARR,
        NASA_ARR,
        step_days=1.0,
    )
    cand = select_candidates(grid)["minimum_c3"]
    response = client.post(
        "/api/porkchop",
        json={
            "departure_start": NASA_DEP,
            "departure_end": NASA_DEP,
            "arrival_start": NASA_ARR,
            "arrival_end": NASA_ARR,
            "step_days": 1.0,
            "min_tof_days": 100.0,
            "max_tof_days": 500.0,
        },
    )
    assert response.status_code == 200
    body = response.json()
    assert body["n_potential"] == 1
    assert body["valid"][0][0] is True
    assert body["c3_km2_s2"][0][0] == pytest.approx(cand.c3_km2_s2, rel=1e-12, abs=1e-12)
    assert body["earth_vinf_km_s"][0][0] == pytest.approx(
        cand.earth_vinf_km_s, rel=1e-12, abs=1e-12
    )
    assert body["candidates"]["minimum_c3"]["c3_km2_s2"] == pytest.approx(
        cand.c3_km2_s2, rel=1e-12, abs=1e-12
    )


def test_porkchop_invalid_bounds(client) -> None:
    response = client.post(
        "/api/porkchop",
        json={
            "departure_start": NASA_DEP,
            "departure_end": NASA_DEP,
            "arrival_start": NASA_ARR,
            "arrival_end": NASA_ARR,
            "step_days": 1.0,
            "min_tof_days": 400.0,
            "max_tof_days": 100.0,
        },
    )
    assert response.status_code == 422


def test_porkchop_grid_size_protection(client) -> None:
    response = client.post(
        "/api/porkchop",
        json={
            "departure_start": "2026-07-01T00:00:00",
            "departure_end": "2027-03-01T00:00:00",
            "arrival_start": "2027-03-01T00:00:00",
            "arrival_end": "2028-06-01T00:00:00",
            "step_days": 0.5,
            "min_tof_days": 100.0,
            "max_tof_days": 500.0,
        },
    )
    assert response.status_code == 400
    detail = response.json()["detail"]
    assert "safety cap" in detail
    assert "not truncated" in detail


def test_reference_case_uses_engine(client) -> None:
    direct = compute_earth_mars_transfer(NASA_DEP, NASA_ARR)
    response = client.get("/api/reference-case")
    assert response.status_code == 200
    body = response.json()
    assert body["nasa_published_c3_km2_s2"] == 9.144
    assert "not NASA-certified" in body["note"]
    assert body["transfer"]["c3_km2_s2"] == pytest.approx(
        direct.c3_km2_s2, rel=1e-12, abs=1e-12
    )
