"""UTC parsing and UTC→ET conversion tests.

The J2000 ET check uses only:
  - TAI − UTC = 32 s on 2000-01-01 (naif0012.tls DELTA_AT entry @1999-JAN-1)
  - TT − TAI  = 32.184 s exactly (IAU / NAIF DELTET/DELTA_T_A)
  - |TDB − TT| ≤ 0.002 s (NAIF LSK periodic term K = 1.657e-3 s)
"""

from __future__ import annotations

import pytest

from ares.constants import TT_MINUS_TAI_S
from ares.errors import TimeScaleError
from ares.time import parse_utc, spice_utc_string, utc_to_et

# Last leap second before J2000 in naif0012.tls is 1999-JAN-1 → DELTA_AT = 32.
_TAI_MINUS_UTC_AT_J2000_S = 32.0


def test_parse_utc_accepts_iso_and_z_suffix() -> None:
    canonical = "2026-10-31T00:00:00.000000 UTC"
    assert parse_utc("2026-10-31T00:00:00") == canonical
    assert parse_utc("2026-10-31T00:00:00Z") == canonical
    assert parse_utc("2026-10-31 00:00:00") == canonical
    assert parse_utc("2026-10-31") == canonical
    assert parse_utc(canonical) == canonical
    assert spice_utc_string("2026-10-31T00:00:00") == "2026-10-31 00:00:00.000000 UTC"


def test_parse_utc_rejects_empty_and_non_utc_offset() -> None:
    with pytest.raises(TimeScaleError, match="Empty UTC"):
        parse_utc("  ")
    with pytest.raises(TimeScaleError, match="Invalid UTC"):
        parse_utc("31 October 2026")
    with pytest.raises(TimeScaleError, match="Invalid UTC"):
        parse_utc("2026-10-31T00:00:00+05:30")


def test_parse_utc_rejects_impossible_calendar_dates() -> None:
    with pytest.raises(TimeScaleError, match="Invalid calendar"):
        parse_utc("2026-02-30T00:00:00")
    with pytest.raises(TimeScaleError, match="Invalid calendar"):
        parse_utc("2026-13-01T00:00:00")


def test_utc_to_et_j2000_noon_utc(spice_kernels) -> None:
    """UTC 2000-01-01 12:00:00 is 64.184 s of TT after J2000.0 TT.

    SPICE ET is TDB seconds past 2000-01-01 12:00:00 TDB. TDB−TT is the
    LSK periodic term, amplitude K = 1.657e-3 s, so the residual from
    64.184 s is bounded by 0.002 s without using a fitted ARES value.
    """
    del spice_kernels
    et = utc_to_et("2000-01-01T12:00:00")
    expected = _TAI_MINUS_UTC_AT_J2000_S + TT_MINUS_TAI_S
    assert abs(et - expected) < 0.002
    assert et == et and abs(et) != float("inf")


def test_utc_to_et_one_utc_day_is_86400_seconds(spice_kernels) -> None:
    """Between leap seconds, consecutive UTC midnights differ by 86400 SI s.

    The LSK periodic TDB−TT term changes by ≪ 1 ms over one day
    (amplitude 1.657e-3 s, period ~1 year), so |ΔET − 86400| < 0.001 s.
    """
    del spice_kernels
    et0 = utc_to_et("2026-10-31T00:00:00")
    et1 = utc_to_et("2026-11-01T00:00:00")
    delta = et1 - et0
    assert abs(delta - 86400.0) < 0.001


def test_utc_to_et_changes_when_epoch_changes(spice_kernels) -> None:
    del spice_kernels
    et_a = utc_to_et("2026-10-31T00:00:00")
    et_b = utc_to_et("2026-10-31T00:00:01")
    assert et_b > et_a
    assert abs((et_b - et_a) - 1.0) < 1e-6
