"""Pytest fixtures for ARES Stage 1.

Kernel-backed tests fail loudly if NAIF kernels are not on disk.
Run ``python scripts/download_kernels.py`` before pytest in a fresh clone.
"""

from __future__ import annotations

import pytest

from ares.ephemeris import KernelConfiguration, load_kernels, unload_kernels
from ares.errors import KernelError

EXAMPLE_UTC = "2026-10-31T00:00:00"


@pytest.fixture(scope="session")
def spice_kernels() -> KernelConfiguration:
    try:
        config = load_kernels()
    except KernelError as exc:
        pytest.fail(str(exc))
    yield config
    unload_kernels()
