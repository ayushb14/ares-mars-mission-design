"""Lambert solver tests: input checks and independent two-body reconstruction.

The Keplerian reconstruction uses the perifocal formulae as in Vallado,
Fundamentals of Astrodynamics and Applications (true anomaly → r, v;
Kepler's equation for TOF). Those velocities are the reference, not
lamberthub's own examples.
"""

from __future__ import annotations

import numpy as np
import pytest

from ares.constants import AU_KM, GM_SUN_KM3_S2
from ares.errors import LambertError
from ares.lambert import solve_lambert, transfer_angle_rad
from ares.trajectory import (
    ENDPOINT_ABS_TOLERANCE_KM,
    check_lambert_endpoint,
)


def _stumpff_kepler_state(a_km: float, e: float, nu_rad: float, mu: float):
    """Perifocal r, v for an ellipse. Vallado perifocal frame, i=0, Ω=0, ω=0.

    r = p / (1 + e cos ν)
    r_vec = r [cos ν, sin ν, 0]
    v_vec = sqrt(μ/p) [−sin ν, e + cos ν, 0]
    p = a (1 − e²)
    """
    if not (0.0 <= e < 1.0):
        raise ValueError("this helper is for ellipses only")
    p = a_km * (1.0 - e * e)
    r_mag = p / (1.0 + e * np.cos(nu_rad))
    r = r_mag * np.array([np.cos(nu_rad), np.sin(nu_rad), 0.0])
    v = np.sqrt(mu / p) * np.array([-np.sin(nu_rad), e + np.cos(nu_rad), 0.0])
    return r, v


def _elliptic_tof_s(a_km: float, e: float, nu1: float, nu2: float, mu: float) -> float:
    """TOF from ν1 to ν2 on an ellipse via Kepler's equation.

    cos E = (e + cos ν) / (1 + e cos ν)
    sin E = √(1−e²) sin ν / (1 + e cos ν)
    M = E − e sin E
    Δt = (M2 − M1) / n ,  n = √(μ/a³)
    """

    def eccentric_anomaly(nu: float) -> float:
        denom = 1.0 + e * np.cos(nu)
        cos_e = (e + np.cos(nu)) / denom
        sin_e = (np.sqrt(1.0 - e * e) * np.sin(nu)) / denom
        return float(np.arctan2(sin_e, cos_e))

    e1 = eccentric_anomaly(nu1)
    e2 = eccentric_anomaly(nu2)
    m1 = e1 - e * np.sin(e1)
    m2 = e2 - e * np.sin(e2)
    n = np.sqrt(mu / a_km**3)
    return float((m2 - m1) / n)


def test_reject_nonpositive_tof() -> None:
    r1 = np.array([AU_KM, 0.0, 0.0])
    r2 = np.array([0.0, 1.5 * AU_KM, 0.0])
    with pytest.raises(LambertError, match="positive"):
        solve_lambert(r1, r2, 0.0)
    with pytest.raises(LambertError, match="positive"):
        solve_lambert(r1, r2, -100.0)


def test_reject_nan_position() -> None:
    r1 = np.array([np.nan, 0.0, 0.0])
    r2 = np.array([0.0, AU_KM, 0.0])
    with pytest.raises(LambertError, match="NaN"):
        solve_lambert(r1, r2, 1e7)


def test_reject_zero_vector() -> None:
    r1 = np.zeros(3)
    r2 = np.array([AU_KM, 0.0, 0.0])
    with pytest.raises(LambertError, match="zero vector"):
        solve_lambert(r1, r2, 1e7)


def test_reject_non_zero_revolutions() -> None:
    r1 = np.array([AU_KM, 0.0, 0.0])
    r2 = np.array([0.0, 1.5 * AU_KM, 0.0])
    with pytest.raises(LambertError, match="zero-revolution"):
        solve_lambert(r1, r2, 1e7, revolutions=1)


def test_keplerian_reconstruction_matches_lambert() -> None:
    """Independent two-body truth: Lambert must recover perifocal v1, v2."""
    mu = GM_SUN_KM3_S2
    a = 1.3 * AU_KM
    e = 0.15
    nu1 = 0.20
    nu2 = 1.80  # well away from 0 and π
    r1, v1_true = _stumpff_kepler_state(a, e, nu1, mu)
    r2, v2_true = _stumpff_kepler_state(a, e, nu2, mu)
    tof = _elliptic_tof_s(a, e, nu1, nu2, mu)
    assert tof > 0.0

    sol = solve_lambert(r1, r2, tof, mu, prograde=True, revolutions=0)
    assert np.all(np.isfinite(sol.v_departure_km_s))
    assert np.all(np.isfinite(sol.v_arrival_km_s))
    assert np.linalg.norm(sol.v_departure_km_s - v1_true) < 1e-6
    assert np.linalg.norm(sol.v_arrival_km_s - v2_true) < 1e-6

    # Specific energy and h must match at both ends.
    eps1 = 0.5 * np.dot(sol.v_departure_km_s, sol.v_departure_km_s) - mu / np.linalg.norm(r1)
    eps2 = 0.5 * np.dot(sol.v_arrival_km_s, sol.v_arrival_km_s) - mu / np.linalg.norm(r2)
    assert abs(eps1 - eps2) / abs(eps1) < 1e-9
    h1 = np.cross(r1, sol.v_departure_km_s)
    h2 = np.cross(r2, sol.v_arrival_km_s)
    assert np.linalg.norm(h1 - h2) / np.linalg.norm(h1) < 1e-9
    assert h1[2] > 0.0  # prograde in this equatorial setup


def test_lambert_propagation_hits_target() -> None:
    mu = GM_SUN_KM3_S2
    a = 1.3 * AU_KM
    e = 0.15
    nu1, nu2 = 0.20, 1.80
    r1, _ = _stumpff_kepler_state(a, e, nu1, mu)
    r2, _ = _stumpff_kepler_state(a, e, nu2, mu)
    tof = _elliptic_tof_s(a, e, nu1, nu2, mu)
    sol = solve_lambert(r1, r2, tof, mu)
    check = check_lambert_endpoint(sol, r2)
    assert check.within_tolerance
    assert check.position_error_magnitude_km < ENDPOINT_ABS_TOLERANCE_KM


def test_prograde_flag_changes_angular_momentum_sign() -> None:
    r1 = np.array([AU_KM, 0.0, 0.0])
    r2 = np.array([0.0, 1.5 * AU_KM, 0.0])
    tof = 150.0 * 86400.0
    pro = solve_lambert(r1, r2, tof, prograde=True)
    ret = solve_lambert(r1, r2, tof, prograde=False)
    h_pro = np.cross(r1, pro.v_departure_km_s)[2]
    h_ret = np.cross(r1, ret.v_departure_km_s)[2]
    assert h_pro > 0.0
    assert h_ret < 0.0


def test_transfer_angle_short_way_under_prograde() -> None:
    r1 = np.array([AU_KM, 0.0, 0.0])
    r2 = np.array([0.0, AU_KM, 0.0])  # +90 deg, hz > 0
    angle = transfer_angle_rad(r1, r2, prograde=True)
    assert abs(angle - 0.5 * np.pi) < 1e-12
    r3 = np.array([0.0, -AU_KM, 0.0])  # hz < 0 → long way for prograde
    angle_long = transfer_angle_rad(r1, r3, prograde=True)
    assert abs(angle_long - 1.5 * np.pi) < 1e-12
