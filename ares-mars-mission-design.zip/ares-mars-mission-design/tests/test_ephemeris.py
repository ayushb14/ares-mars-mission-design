"""Heliocentric Earth/Mars state-vector tests against SPICE + physical sanity."""

from __future__ import annotations

import numpy as np
import pytest

from ares.constants import (
    AU_KM,
    NAIF_EARTH,
    NAIF_EARTH_BARYCENTER,
    NAIF_MARS,
    NAIF_MARS_BARYCENTER,
    NAIF_SUN,
    NSSDCA_EARTH_APHELION_KM,
    NSSDCA_EARTH_MAX_ORBITAL_VELOCITY_KM_S,
    NSSDCA_EARTH_MIN_ORBITAL_VELOCITY_KM_S,
    NSSDCA_EARTH_PERIHELION_KM,
    NSSDCA_MARS_APHELION_KM,
    NSSDCA_MARS_MAX_ORBITAL_VELOCITY_KM_S,
    NSSDCA_MARS_MIN_ORBITAL_VELOCITY_KM_S,
    NSSDCA_MARS_PERIHELION_KM,
    SANITY_ENVELOPE_FRACTION,
    SPEED_OF_LIGHT_KM_S,
)
from ares.ephemeris import (
    earth_heliocentric_state,
    main,
    mars_heliocentric_state,
    state,
    unload_kernels,
)
from ares.errors import EphemerisError, KernelError

EXAMPLE_UTC = "2026-10-31T00:00:00"


def _envelope(low: float, high: float) -> tuple[float, float]:
    width = SANITY_ENVELOPE_FRACTION * (high - low)
    return low - width, high + width


def test_au_is_iau_2012_defining_value() -> None:
    # IAU 2012 Resolution B2: 149 597 870 700 m exactly.
    assert AU_KM * 1000.0 == 149_597_870_700.0


def test_earth_state_is_finite_heliocentric_and_labelled(spice_kernels) -> None:
    del spice_kernels
    earth = earth_heliocentric_state(EXAMPLE_UTC)
    assert earth.target_id == NAIF_EARTH
    assert earth.observer_id == NAIF_SUN
    assert earth.frame == "J2000"
    assert earth.aberration_correction == "NONE"
    assert earth.position_km.shape == (3,)
    assert earth.velocity_km_s.shape == (3,)
    assert np.all(np.isfinite(earth.position_km))
    assert np.all(np.isfinite(earth.velocity_km_s))
    assert np.isfinite(earth.et_seconds)
    assert earth.spk_kernel == "de440s.bsp"


def test_earth_is_body_center_399_not_emb_3(spice_kernels) -> None:
    """Earth Lambert endpoint is NAIF 399, not Earth-Moon barycenter 3."""
    del spice_kernels
    earth = earth_heliocentric_state(EXAMPLE_UTC)
    emb = state("EARTH BARYCENTER", EXAMPLE_UTC)
    assert earth.target_id == NAIF_EARTH
    assert earth.target_id != NAIF_EARTH_BARYCENTER
    assert emb.target_id == NAIF_EARTH_BARYCENTER
    offset_km = float(np.linalg.norm(earth.position_km - emb.position_km))
    # Moon–EMB geometry is thousands of km; a 399/3 swap would be this large.
    assert offset_km > 1000.0


def test_mars_state_uses_barycenter_not_body_499(spice_kernels) -> None:
    del spice_kernels
    mars = mars_heliocentric_state(EXAMPLE_UTC)
    assert mars.target_id == NAIF_MARS_BARYCENTER
    assert mars.target_id != NAIF_MARS
    assert mars.observer_id == NAIF_SUN
    assert mars.frame == "J2000"
    assert mars.aberration_correction == "NONE"
    assert np.all(np.isfinite(mars.position_km))
    assert np.all(np.isfinite(mars.velocity_km_s))


def test_earth_sun_distance_matches_nssdca_envelope(spice_kernels) -> None:
    del spice_kernels
    earth = earth_heliocentric_state(EXAMPLE_UTC)
    low, high = _envelope(NSSDCA_EARTH_PERIHELION_KM, NSSDCA_EARTH_APHELION_KM)
    assert low < earth.radius_km < high


def test_mars_sun_distance_matches_nssdca_envelope(spice_kernels) -> None:
    del spice_kernels
    mars = mars_heliocentric_state(EXAMPLE_UTC)
    low, high = _envelope(NSSDCA_MARS_PERIHELION_KM, NSSDCA_MARS_APHELION_KM)
    assert low < mars.radius_km < high


def test_earth_heliocentric_speed_matches_nssdca_envelope(spice_kernels) -> None:
    del spice_kernels
    earth = earth_heliocentric_state(EXAMPLE_UTC)
    low, high = _envelope(
        NSSDCA_EARTH_MIN_ORBITAL_VELOCITY_KM_S,
        NSSDCA_EARTH_MAX_ORBITAL_VELOCITY_KM_S,
    )
    assert low < earth.speed_km_s < high


def test_mars_heliocentric_speed_matches_nssdca_envelope(spice_kernels) -> None:
    del spice_kernels
    mars = mars_heliocentric_state(EXAMPLE_UTC)
    low, high = _envelope(
        NSSDCA_MARS_MIN_ORBITAL_VELOCITY_KM_S,
        NSSDCA_MARS_MAX_ORBITAL_VELOCITY_KM_S,
    )
    assert low < mars.speed_km_s < high


def test_geometric_light_time_is_range_over_c(spice_kernels) -> None:
    """SPKEZR with abcorr=NONE returns geometric range / c.

    c is the SI defining value 299792.458 km/s, stored in constants.py.
    """
    del spice_kernels
    earth = earth_heliocentric_state(EXAMPLE_UTC)
    predicted = earth.radius_km / SPEED_OF_LIGHT_KM_S
    relative = abs(earth.light_time_s - predicted) / predicted
    assert relative < 1e-12


def test_changing_epoch_changes_earth_and_mars_state(spice_kernels) -> None:
    del spice_kernels
    t0 = "2026-10-31T00:00:00"
    t1 = "2026-11-01T00:00:00"
    earth0 = earth_heliocentric_state(t0)
    earth1 = earth_heliocentric_state(t1)
    mars0 = mars_heliocentric_state(t0)
    mars1 = mars_heliocentric_state(t1)

    earth_shift = float(np.linalg.norm(earth1.position_km - earth0.position_km))
    mars_shift = float(np.linalg.norm(mars1.position_km - mars0.position_km))

    # Chord length over one day ≈ orbital speed × 86400 s.
    # Bounds from NSSDCA min/max orbital velocity × 86400 s, ±2% envelope.
    earth_low = NSSDCA_EARTH_MIN_ORBITAL_VELOCITY_KM_S * 86400.0 * 0.98
    earth_high = NSSDCA_EARTH_MAX_ORBITAL_VELOCITY_KM_S * 86400.0 * 1.02
    mars_low = NSSDCA_MARS_MIN_ORBITAL_VELOCITY_KM_S * 86400.0 * 0.98
    mars_high = NSSDCA_MARS_MAX_ORBITAL_VELOCITY_KM_S * 86400.0 * 1.02
    assert earth_low < earth_shift < earth_high
    assert mars_low < mars_shift < mars_high
    assert earth0.et_seconds != earth1.et_seconds


def test_units_are_km_not_metres(spice_kernels) -> None:
    """A metre/km mix-up would put |r_earth| near 1.5e11 instead of 1.5e8."""
    del spice_kernels
    earth = earth_heliocentric_state(EXAMPLE_UTC)
    assert 1.0e8 < earth.radius_km < 2.0e8
    assert earth.radius_km < 1.0e10


def test_unsupported_frame_fails_loudly(spice_kernels) -> None:
    del spice_kernels
    with pytest.raises(EphemerisError, match="Unsupported reference frame"):
        earth_heliocentric_state(EXAMPLE_UTC, frame="IAU_EARTH")


def test_unsupported_abcorr_fails_loudly(spice_kernels) -> None:
    del spice_kernels
    with pytest.raises(EphemerisError, match="Unsupported aberration"):
        earth_heliocentric_state(EXAMPLE_UTC, aberration_correction="MADEUP")


def test_mars_body_499_fails_loudly_rather_than_substituting(spice_kernels) -> None:
    del spice_kernels
    with pytest.raises(EphemerisError, match="MARS BARYCENTER"):
        state("MARS", EXAMPLE_UTC)


def test_eclipj2000_is_allowed_and_differs_from_j2000(spice_kernels) -> None:
    del spice_kernels
    eq = earth_heliocentric_state(EXAMPLE_UTC, frame="J2000")
    ec = earth_heliocentric_state(EXAMPLE_UTC, frame="ECLIPJ2000")
    assert ec.frame == "ECLIPJ2000"
    # Same geometric vector, rotated: radii match; components do not.
    assert abs(eq.radius_km - ec.radius_km) / eq.radius_km < 1e-12
    assert not np.allclose(eq.position_km, ec.position_km)


def test_cli_prints_labelled_heliocentric_states(spice_kernels, capsys) -> None:
    del spice_kernels
    rc = main(["--date", EXAMPLE_UTC])
    assert rc == 0
    out = capsys.readouterr().out
    assert "EARTH (NAIF 399)" in out
    assert "MARS BARYCENTER (NAIF 4)" in out
    assert "Frame: J2000" in out
    assert "Aberration correction: NONE" in out
    assert "Observer: SUN (NAIF 10)" in out
    assert "position_km" in out
    assert "velocity_km_s" in out


def test_missing_kernels_fail_loudly(tmp_path, spice_kernels) -> None:
    del spice_kernels
    from ares.ephemeris import load_kernels

    unload_kernels()
    with pytest.raises(KernelError, match="download_kernels"):
        load_kernels(tmp_path)
    load_kernels()
