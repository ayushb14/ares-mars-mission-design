"""v∞ and C3 unit tests. v∞ is not ΔV."""

from __future__ import annotations

import numpy as np
import pytest

from ares.energetics import (
    characteristic_energy_km2_s2,
    excess_velocity,
    hyperbolic_excess_velocity_km_s,
    speed_km_s,
)
from ares.errors import TrajectoryError


def test_c3_is_vinf_squared() -> None:
    vinf = np.array([3.0, 4.0, 0.0])
    assert characteristic_energy_km2_s2(vinf) == pytest.approx(25.0)
    bundled = excess_velocity(np.array([5.0, 4.0, 0.0]), np.array([2.0, 0.0, 0.0]))
    assert bundled.magnitude_km_s == pytest.approx(5.0)
    assert bundled.c3_km2_s2 == pytest.approx(bundled.magnitude_km_s**2)


def test_vinf_is_relative_velocity_not_delta_v_label() -> None:
    v_sc = np.array([32.0, 1.0, 0.0])
    v_pl = np.array([29.8, 0.0, 0.0])
    vinf = hyperbolic_excess_velocity_km_s(v_sc, v_pl)
    assert np.allclose(vinf, np.array([2.2, 1.0, 0.0]))
    assert speed_km_s(vinf) >= 0.0


def test_c3_and_magnitude_nonnegative() -> None:
    vinf = np.array([-1.5, 2.0, 0.5])
    mag = speed_km_s(vinf)
    c3 = characteristic_energy_km2_s2(vinf)
    assert mag >= 0.0
    assert c3 >= 0.0
    assert c3 == pytest.approx(mag * mag)


def test_reject_nan_velocity() -> None:
    with pytest.raises(TrajectoryError, match="NaN"):
        hyperbolic_excess_velocity_km_s(
            np.array([np.nan, 0.0, 0.0]), np.array([1.0, 0.0, 0.0])
        )
