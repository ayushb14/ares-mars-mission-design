"""Earth→Mars transfer tests. Reference dates are an ARES computed case, not an optimum."""

from __future__ import annotations

import numpy as np
import pytest

from ares.constants import NAIF_EARTH, NAIF_MARS_BARYCENTER, NAIF_SUN
from ares.errors import TimeScaleError, TrajectoryError
from ares.trajectory import (
    ENDPOINT_ABS_TOLERANCE_KM,
    compute_earth_mars_transfer,
    format_transfer_report,
    main,
    sample_transfer_points,
)

DEPARTURE = "2026-10-31T00:00:00"
ARRIVAL = "2027-09-07T00:00:00"


def test_departure_must_precede_arrival(spice_kernels) -> None:
    del spice_kernels
    with pytest.raises(TrajectoryError, match="strictly after"):
        compute_earth_mars_transfer(ARRIVAL, DEPARTURE)
    with pytest.raises(TrajectoryError, match="strictly after"):
        compute_earth_mars_transfer(DEPARTURE, DEPARTURE)


def test_invalid_calendar_fails(spice_kernels) -> None:
    del spice_kernels
    with pytest.raises(TimeScaleError):
        compute_earth_mars_transfer("2026-02-30T00:00:00", ARRIVAL)


def test_reference_case_finite_and_verified(spice_kernels) -> None:
    del spice_kernels
    result = compute_earth_mars_transfer(DEPARTURE, ARRIVAL)

    assert result.time_of_flight_s > 0.0
    assert result.time_of_flight_days == pytest.approx(
        result.time_of_flight_s / 86400.0
    )
    for vec in (
        result.earth_position_km,
        result.earth_velocity_km_s,
        result.mars_position_km,
        result.mars_velocity_km_s,
        result.transfer_departure_velocity_km_s,
        result.transfer_arrival_velocity_km_s,
        result.earth_vinf.vector_km_s,
        result.mars_vinf.vector_km_s,
    ):
        assert vec.shape == (3,)
        assert np.all(np.isfinite(vec))

    assert result.earth_vinf.magnitude_km_s >= 0.0
    assert result.mars_vinf.magnitude_km_s >= 0.0
    assert result.c3_km2_s2 >= 0.0
    assert result.c3_km2_s2 == pytest.approx(
        result.earth_vinf.magnitude_km_s**2, rel=1e-12
    )
    assert result.c3_km2_s2 == pytest.approx(result.earth_vinf.c3_km2_s2, rel=1e-15)

    # km not metres: Earth-Mars C3 of a sane Lambert is O(1–100) km^2/s^2,
    # not O(1e7). This is a unit check, not an optimality claim.
    assert result.c3_km2_s2 < 1.0e4

    assert result.frame == "J2000"
    assert result.aberration_correction == "NONE"
    assert result.observer_id == NAIF_SUN
    assert result.earth_target_id == NAIF_EARTH
    assert result.mars_target_id == NAIF_MARS_BARYCENTER
    assert result.lambert.prograde is True
    assert result.lambert.revolutions == 0

    assert result.verification.within_tolerance
    assert result.verification.position_error_magnitude_km < ENDPOINT_ABS_TOLERANCE_KM
    assert result.verification.method == "DOP853"


def test_cli_reference_case(spice_kernels, capsys) -> None:
    del spice_kernels
    rc = main(["--departure", DEPARTURE, "--arrival", ARRIVAL])
    assert rc == 0
    out = capsys.readouterr().out
    assert "ARES Earth → Mars Transfer" in out
    assert "Earth departure v∞" in out
    assert "Mars arrival v∞" in out
    assert "C3:" in out
    assert "Lambert target error" in out
    assert "Heliocentric two-body Lambert transfer" in out
    assert "not ΔV" in out
    assert "EARTH (NAIF 399)" in out
    assert "body center" in out
    assert "MARS BARYCENTER (NAIF 4)" in out
    assert "system barycenter" in out
    assert "SUN (NAIF 10)" in out
    assert "not Earth-Moon barycenter (3)" in out
    assert "not Mars body center (499)" in out


def test_sample_transfer_points_are_two_body_not_bezier(spice_kernels) -> None:
    del spice_kernels
    result = compute_earth_mars_transfer(DEPARTURE, ARRIVAL)
    samples = sample_transfer_points(result, n_points=21)
    assert len(samples) == 21
    start = np.array([samples[0].x_km, samples[0].y_km, samples[0].z_km])
    end = np.array([samples[-1].x_km, samples[-1].y_km, samples[-1].z_km])
    assert np.linalg.norm(start - result.earth_position_km) < 1.0e-6
    assert np.linalg.norm(end - result.mars_position_km) < ENDPOINT_ABS_TOLERANCE_KM
    assert samples[0].t_s == pytest.approx(0.0)
    assert samples[-1].t_s == pytest.approx(result.time_of_flight_s)


def test_stage2_reference_c3_regression(spice_kernels) -> None:
    """Frozen Stage 2 result for Earth 399 / Mars barycenter 4 / Sun 10.

    Do not edit these numbers to match NASA/TM-2010-216764. A failure means
    the geometry, target IDs, μ, or Lambert branch changed.
    """
    del spice_kernels
    result = compute_earth_mars_transfer(DEPARTURE, ARRIVAL)
    assert result.earth_target_id == NAIF_EARTH
    assert result.mars_target_id == NAIF_MARS_BARYCENTER
    assert result.observer_id == NAIF_SUN
    assert result.c3_km2_s2 == pytest.approx(9.264656967849, rel=1e-12, abs=1e-12)
    assert result.earth_vinf.magnitude_km_s == pytest.approx(
        3.043789902055, rel=1e-12, abs=1e-12
    )
    assert result.mars_vinf.magnitude_km_s == pytest.approx(
        2.570159533603, rel=1e-12, abs=1e-12
    )


def test_report_does_not_hardcode_example_numbers(spice_kernels) -> None:
    del spice_kernels
    result = compute_earth_mars_transfer(DEPARTURE, ARRIVAL)
    text = format_transfer_report(result)
    assert f"{result.c3_km2_s2:.9f}" in text
    assert f"{result.earth_vinf.magnitude_km_s:.9f}" in text
