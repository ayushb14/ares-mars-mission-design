# Start the ARES Vite frontend on 127.0.0.1:4177 (proxies /api to the backend).
$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $PSScriptRoot
Set-Location (Join-Path $root "frontend")
if (-not (Test-Path "node_modules")) {
    npm install
}
npm run dev
