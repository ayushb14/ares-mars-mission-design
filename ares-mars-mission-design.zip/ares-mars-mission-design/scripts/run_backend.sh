#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
if [[ -f .venv/bin/activate ]]; then
  # shellcheck disable=SC1091
  source .venv/bin/activate
fi
HOST="${ARES_API_HOST:-127.0.0.1}"
PORT="${ARES_API_PORT:-8765}"
python -m ares.api --host "$HOST" --port "$PORT"
