# Start the ARES FastAPI physics facade on 127.0.0.1:8765.
# Run from anywhere; resolves the repository root from this script's location.
$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $PSScriptRoot
Set-Location $root
if (Test-Path ".venv\Scripts\Activate.ps1") {
    . ".venv\Scripts\Activate.ps1"
}
$hostName = if ($env:ARES_API_HOST) { $env:ARES_API_HOST } else { "127.0.0.1" }
$port = if ($env:ARES_API_PORT) { $env:ARES_API_PORT } else { "8765" }
python -m ares.api --host $hostName --port $port
