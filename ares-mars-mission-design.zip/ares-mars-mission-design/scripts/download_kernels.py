#!/usr/bin/env python3
"""Download the official NASA/JPL NAIF kernels required for ARES Stage 1.

Kernels (HTTPS, NAIF generic kernel archive):

  naif0012.tls      Leapseconds (unix/LF). Required for UTC→ET.
  naif0012.tls.pc   Leapseconds (Windows/CRLF). Preferred on Windows.
  de440s.bsp        DE440 short planetary SPK, 1849–2150.

de440s.bsp MD5 is the value published by NAIF in
https://naif.jpl.nasa.gov/pub/naif/generic_kernels/spk/planets/aa_checksums.txt

This script uses only the Python standard library so it can run after a
plain ``pip install -e .`` (no extra HTTP client).
"""

from __future__ import annotations

import argparse
import hashlib
import sys
import urllib.error
import urllib.request
from pathlib import Path

NAIF_BASE = "https://naif.jpl.nasa.gov/pub/naif/generic_kernels"

# Official NAIF MD5 for de440s.bsp from aa_checksums.txt (retrieved 2026-10-26).
DE440S_MD5 = "3917ee56769db332790c751e2168843d"

KERNELS = (
    {
        "filename": "naif0012.tls",
        "url": f"{NAIF_BASE}/lsk/naif0012.tls",
        "md5": None,
        "required": True,
    },
    {
        "filename": "naif0012.tls.pc",
        "url": f"{NAIF_BASE}/lsk/naif0012.tls.pc",
        "md5": None,
        "required": True,
    },
    {
        "filename": "de440s.bsp",
        "url": f"{NAIF_BASE}/spk/planets/de440s.bsp",
        "md5": DE440S_MD5,
        "required": True,
    },
)


def repository_root() -> Path:
    env = __import__("os").environ.get("ARES_ROOT")
    if env:
        return Path(env).expanduser().resolve()
    here = Path(__file__).resolve()
    for parent in here.parents:
        if (parent / "pyproject.toml").is_file():
            return parent
    return Path.cwd().resolve()


def default_kernel_dir() -> Path:
    env = __import__("os").environ.get("ARES_KERNEL_DIR")
    if env:
        return Path(env).expanduser().resolve()
    return repository_root() / "data" / "kernels"


def _md5_file(path: Path) -> str:
    digest = hashlib.md5()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def download(url: str, destination: Path) -> None:
    """Download ``url`` to ``destination`` using HTTPS."""
    destination.parent.mkdir(parents=True, exist_ok=True)
    tmp = destination.with_suffix(destination.suffix + ".partial")
    print(f"Downloading {url}")
    print(f"         -> {destination}")
    try:
        request = urllib.request.Request(
            url,
            headers={"User-Agent": "ARES-Stage1-kernel-downloader"},
        )
        with urllib.request.urlopen(request, timeout=120) as response:
            total = response.headers.get("Content-Length")
            total_bytes = int(total) if total else None
            bytes_read = 0
            with tmp.open("wb") as handle:
                while True:
                    chunk = response.read(1024 * 1024)
                    if not chunk:
                        break
                    handle.write(chunk)
                    bytes_read += len(chunk)
                    if total_bytes:
                        pct = 100.0 * bytes_read / total_bytes
                        print(
                            f"\r  {bytes_read / 1e6:.1f} / {total_bytes / 1e6:.1f} MB "
                            f"({pct:.0f}%)",
                            end="",
                            file=sys.stderr,
                            flush=True,
                        )
        if total_bytes:
            print(file=sys.stderr)
        tmp.replace(destination)
    except urllib.error.URLError as exc:
        if tmp.exists():
            tmp.unlink()
        raise SystemExit(
            f"Failed to download {url}\n"
            f"  reason: {exc}\n"
            "Confirm HTTPS access to naif.jpl.nasa.gov, then retry."
        ) from exc
    except Exception:
        if tmp.exists():
            tmp.unlink()
        raise


def ensure_kernel(spec: dict, kernel_dir: Path, force: bool) -> Path:
    path = kernel_dir / spec["filename"]
    expected_md5 = spec["md5"]
    if path.is_file() and not force:
        if expected_md5:
            actual = _md5_file(path)
            if actual != expected_md5:
                raise SystemExit(
                    f"Existing file {path} has MD5 {actual}, expected "
                    f"{expected_md5} (NAIF aa_checksums.txt). Re-run with "
                    "--force to replace it."
                )
            print(f"Already present (MD5 OK): {path}")
        else:
            print(f"Already present: {path}")
        return path

    download(spec["url"], path)
    if expected_md5:
        actual = _md5_file(path)
        if actual != expected_md5:
            path.unlink(missing_ok=True)
            raise SystemExit(
                f"Checksum mismatch for {path.name}.\n"
                f"  expected MD5 (NAIF aa_checksums.txt): {expected_md5}\n"
                f"  actual MD5                          : {actual}\n"
                "The file was deleted. Check the NAIF URL and retry."
            )
        print(f"  MD5 OK: {actual}")
    print(f"  SHA256: {_sha256_file(path)}")
    print(f"  size  : {path.stat().st_size} bytes")
    return path


def write_meta_kernel(kernel_dir: Path) -> Path:
    """Write a SPICE meta-kernel listing the Stage 1 files.

    PATH_VALUES uses forward slashes, which SPICE accepts on Windows.
    """
    path_value = kernel_dir.resolve().as_posix()
    text = f"""KPL/MK

    ARES Stage 1 meta-kernel.

    Generated by scripts/download_kernels.py. Do not edit by hand if you
    intend to regenerate it. Kernels themselves are official NAIF files.

    LSK : naif0012.tls (unix) / naif0012.tls.pc (Windows)
    SPK : de440s.bsp   (DE440 short planetary ephemeris)

\\begindata

    PATH_VALUES  = ( '{path_value}' )
    PATH_SYMBOLS = ( 'ARESKER' )

    KERNELS_TO_LOAD = (
        '$ARESKER/naif0012.tls'
        '$ARESKER/de440s.bsp'
    )

\\begintext
"""
    mk_path = kernel_dir / "ares_stage1.tm"
    mk_path.write_text(text, encoding="ascii")
    print(f"Wrote meta-kernel: {mk_path}")
    return mk_path


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        description="Download official NAIF kernels for ARES Stage 1."
    )
    parser.add_argument(
        "--kernel-dir",
        default=None,
        help="Destination directory (default: <repo>/data/kernels)",
    )
    parser.add_argument(
        "--force",
        action="store_true",
        help="Re-download even if the file already exists",
    )
    args = parser.parse_args(argv)
    kernel_dir = (
        Path(args.kernel_dir).expanduser().resolve()
        if args.kernel_dir
        else default_kernel_dir()
    )
    kernel_dir.mkdir(parents=True, exist_ok=True)
    print(f"Kernel directory: {kernel_dir}")
    for spec in KERNELS:
        ensure_kernel(spec, kernel_dir, force=args.force)
    write_meta_kernel(kernel_dir)
    print("Stage 1 kernels ready.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
