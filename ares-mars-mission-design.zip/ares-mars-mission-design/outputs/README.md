# outputs/

Generated products (CLI transcripts, Lambert plots, porkchop CSV/HTML) belong
here. Kernel files do not.

This directory is gitignored except for this README and `.gitkeep`.
Do not commit `earth_mars_2026_porkchop.csv` / `.html`; regenerate with
`python -m ares.porkchop`.
