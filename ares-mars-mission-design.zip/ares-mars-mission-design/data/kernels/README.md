# SPICE kernels

This directory is the default location for official NASA/JPL NAIF kernels
used by ARES Stage 1.

Do **not** commit the binary/text kernel files. Download them:

```text
python scripts/download_kernels.py
```

## Required files

| File | NAIF path | Why ARES needs it |
| --- | --- | --- |
| `naif0012.tls` | `generic_kernels/lsk/naif0012.tls` | Leapseconds. Required for UTC → ET (TDB) via SPICE `str2et`. |
| `naif0012.tls.pc` | `generic_kernels/lsk/naif0012.tls.pc` | Same LSK with CRLF line endings; NAIF-recommended copy for Windows. |
| `de440s.bsp` | `generic_kernels/spk/planets/de440s.bsp` | DE440 short planetary ephemeris. Earth (399), Mars barycenter (4), Sun (10), 1849-12-26 to 2150-01-22 ET. |

Source root: <https://naif.jpl.nasa.gov/pub/naif/generic_kernels/>

`de440s.bsp` is about 31 MB. Full DE440 (`de440.bsp`, ~114 MB) and DE441
(multi-GB) are **not** downloaded by Stage 1.

The downloader writes `ares_stage1.tm`, a SPICE meta-kernel. ARES loads the
LSK and SPK by explicit path; the meta-kernel is provided for inspection and
for tools that prefer `furnsh` of a single file.
