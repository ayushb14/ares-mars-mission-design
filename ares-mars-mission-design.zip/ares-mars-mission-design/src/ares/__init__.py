"""ARES — Advanced/Automated Mars Mission Design & Systems Simulator.

Stage 1: SPICE UTC→ET and heliocentric Earth/Mars states
(``ares.time``, ``ares.ephemeris``).
Stage 2: Lambert Earth→Mars transfer (``ares.lambert``, ``ares.trajectory``).
Stage 3: Earth→Mars porkchop grid (``ares.porkchop``).
Stage 4: local FastAPI + React mission-design application (``ares.api``).
This package ``__init__`` does not import those CLI modules, so
``python -m ares.ephemeris`` / ``python -m ares.trajectory`` /
``python -m ares.porkchop`` do not double-load.
"""

from ares.errors import (
    AresError,
    EphemerisError,
    KernelError,
    LambertError,
    TimeScaleError,
    TrajectoryError,
)

__version__ = "0.4.0"

__all__ = [
    "AresError",
    "EphemerisError",
    "KernelError",
    "LambertError",
    "TimeScaleError",
    "TrajectoryError",
    "__version__",
]
