"""UTC → SPICE ephemeris time (TDB seconds past J2000).

Input
    utc : civil time string interpreted as UTC (not local time, not TDB)
Output
    et  : TDB seconds past the J2000 epoch (JD 2451545.0 TDB)

Time scale
    Conversion is performed by NAIF SPICE (SpiceyPy ``str2et``) using a
    loaded leapseconds kernel. ARES does not approximate UTC/TAI/TT/TDB.

Requires
    A leapseconds kernel (naif0012.tls or naif0012.tls.pc) must already
    be loaded via ``ares.ephemeris.load_kernels``.
"""

from __future__ import annotations

import re
from datetime import datetime, timezone

import spiceypy
from spiceypy.utils.exceptions import SpiceyError

from ares.errors import TimeScaleError

# ISO-8601 calendar date with optional time and optional fractional seconds.
# Timezone designator, if present, must be Z or +00:00 / -00:00 (UTC only).
_UTC_PATTERN = re.compile(
    r"""
    ^
    (?P<date>\d{4}-\d{2}-\d{2})
    (?:[T ](?P<time>\d{2}:\d{2}:\d{2}(?:\.\d+)?))?
    (?P<tz>Z|[+-]00:00)?
    (?:\s+UTC)?
    $
    """,
    re.VERBOSE,
)


def parse_utc(utc: str) -> str:
    """Validate a UTC civil-time string and return a canonical SPICE form.

    Input units / scale
        ``utc`` is a calendar timestamp on the UTC time scale.
        Accepted forms:
            ``YYYY-MM-DD``
            ``YYYY-MM-DDTHH:MM:SS``
            ``YYYY-MM-DD HH:MM:SS``
            optional fractional seconds
            optional ``Z`` or ``+00:00`` suffix
        Dates without a time default to 00:00:00.000000 UTC.

    Output
        Canonical string ``YYYY-MM-DDTHH:MM:SS.ffffff UTC`` for ``str2et``.

    Raises
        TimeScaleError if the string is empty, not UTC, not a real calendar
        date (e.g. 31 February), or uses a non-UTC offset.
    """
    if utc is None or not str(utc).strip():
        raise TimeScaleError(
            "Empty UTC timestamp. Provide an ISO-8601 UTC value such as "
            "'2026-10-31T00:00:00'."
        )

    raw = str(utc).strip()
    match = _UTC_PATTERN.match(raw)
    if match is None:
        raise TimeScaleError(
            f"Invalid UTC timestamp {utc!r}. ARES accepts ISO-8601 UTC only "
            "(for example '2026-10-31T00:00:00' or '2026-10-31T00:00:00Z'). "
            "Non-UTC offsets are rejected; do not pass local time."
        )

    date = match.group("date")
    time = match.group("time") or "00:00:00"
    if "." not in time:
        time = f"{time}.000000"
    else:
        whole, frac = time.split(".", 1)
        time = f"{whole}.{frac[:6].ljust(6, '0')}"

    iso = f"{date}T{time}"
    try:
        parsed = datetime.fromisoformat(iso).replace(tzinfo=timezone.utc)
    except ValueError as exc:
        raise TimeScaleError(
            f"Invalid calendar date in {utc!r}: {exc}. "
            "Check year-month-day and that the time is a real clock reading."
        ) from exc

    # Public canonical form (ISO-8601). SPICE str2et is given a space
    # separator — CSPICE rejects ISO "T" combined with a trailing "UTC"
    # time-system token (SPICE(UNPARSEDTIME)).
    return parsed.strftime("%Y-%m-%dT%H:%M:%S.%f") + " UTC"


def spice_utc_string(utc: str) -> str:
    """Return a calendar string accepted by SPICE ``str2et``.

    Input: any string accepted by ``parse_utc``.
    Output: ``YYYY-MM-DD HH:MM:SS.ffffff UTC`` (space, not ``T``).
    """
    canonical = parse_utc(utc)
    date, rest = canonical.split("T", 1)
    clock = rest.removesuffix(" UTC")
    return f"{date} {clock} UTC"


def utc_to_et(utc: str) -> float:
    """Convert a UTC timestamp to SPICE ephemeris time.

    Input
        utc : UTC civil-time string (see ``parse_utc``)
    Output
        et  : float, TDB seconds past J2000
    Frame / scale
        Time scale is TDB (SPICE 'ET'). No reference-frame conversion.
    Assumptions
        A NAIF leapseconds kernel is loaded. Leap seconds after the LSK
        epoch encoded in naif0012.tls are not applied (none have been
        announced through at least 2026-12-31 per IERS Bulletin C 72 /
        NAIF announcement 2026-07-18).

    Raises
        TimeScaleError on invalid input or if SPICE cannot convert the
        string (typically a missing LSK).
    """
    spice_utc = spice_utc_string(utc)
    try:
        et = float(spiceypy.str2et(spice_utc))
    except SpiceyError as exc:
        raise TimeScaleError(
            "SPICE could not convert UTC to ET. A leapseconds kernel must be "
            "loaded first (run `python scripts/download_kernels.py` then "
            "`ares.ephemeris.load_kernels()`). Original SPICE message: "
            f"{exc}"
        ) from exc

    if et != et or abs(et) == float("inf"):
        raise TimeScaleError(
            f"SPICE returned a non-finite ET for {spice_utc!r}: {et!r}."
        )
    return et
