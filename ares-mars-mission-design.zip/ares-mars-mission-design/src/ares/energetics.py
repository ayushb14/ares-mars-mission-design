"""Patched-conic energetics for a heliocentric Lambert transfer.

v∞ is a hyperbolic excess velocity relative to a planet, not a ΔV.

    v∞,Earth = v_transfer(t0) − v_Earth(t0)
    v∞,Mars  = v_transfer(t1) − v_Mars(t1)
    C3       = |v∞,Earth|²

Units
    velocities : km/s
    C3         : km^2/s^2

Frame
    All vectors must share the same inertial frame (Stage 2: J2000).
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from ares.errors import TrajectoryError


def _as_velocity(name: str, value: np.ndarray) -> np.ndarray:
    arr = np.asarray(value, dtype=float)
    if arr.shape != (3,):
        raise TrajectoryError(f"{name} must be a 3-vector in km/s; got {arr.shape}.")
    if not np.all(np.isfinite(arr)):
        raise TrajectoryError(f"{name} contains NaN or Inf: {arr!r}.")
    return np.array(arr, dtype=float, copy=True)


def hyperbolic_excess_velocity_km_s(
    v_spacecraft_km_s: np.ndarray,
    v_planet_km_s: np.ndarray,
) -> np.ndarray:
    """v∞ = v_spacecraft − v_planet, km/s, same inertial frame.

    This is not launch-vehicle ΔV and not Mars orbit-insertion ΔV.
    """
    v_sc = _as_velocity("v_spacecraft_km_s", v_spacecraft_km_s)
    v_pl = _as_velocity("v_planet_km_s", v_planet_km_s)
    return v_sc - v_pl


def speed_km_s(vector_km_s: np.ndarray) -> float:
    """Euclidean magnitude, km/s. Always ≥ 0 for a finite vector."""
    vec = _as_velocity("vector_km_s", vector_km_s)
    return float(np.linalg.norm(vec))


def characteristic_energy_km2_s2(v_infinity_km_s: np.ndarray) -> float:
    """C3 = |v∞|² in km^2/s^2.

    Not a ΔV. No launch vehicle is assumed.
    """
    vinf = _as_velocity("v_infinity_km_s", v_infinity_km_s)
    c3 = float(np.dot(vinf, vinf))
    if c3 < 0.0:
        # Possible only from overflow/NaN; fail loudly.
        raise TrajectoryError(f"Computed C3 is negative: {c3!r}.")
    return c3


@dataclass(frozen=True)
class ExcessVelocity:
    """Planet-relative hyperbolic excess.

    vector_km_s : km/s
    magnitude_km_s : km/s, = |vector|
    c3_km2_s2 : km^2/s^2, = |vector|^2  (only meaningful for Earth departure)
    """

    vector_km_s: np.ndarray
    magnitude_km_s: float
    c3_km2_s2: float


def excess_velocity(
    v_spacecraft_km_s: np.ndarray,
    v_planet_km_s: np.ndarray,
) -> ExcessVelocity:
    """Build v∞ vector, magnitude, and |v∞|²."""
    vector = hyperbolic_excess_velocity_km_s(v_spacecraft_km_s, v_planet_km_s)
    mag = speed_km_s(vector)
    return ExcessVelocity(
        vector_km_s=vector,
        magnitude_km_s=mag,
        c3_km2_s2=characteristic_energy_km2_s2(vector),
    )
