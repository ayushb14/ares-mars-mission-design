"""Lambert's problem wrapper around ``lamberthub.izzo2015``.

ARES does not implement a Lambert algorithm. This module validates inputs,
selects the Stage 2 branch explicitly, and calls Izzo (2015) as provided by
lamberthub 1.x.

Input
    r_departure, r_arrival : km, same inertial frame
    time_of_flight         : seconds
    mu                     : km^3/s^2 (default: DE440 GM_sun)
Output
    departure/arrival transfer velocities : km/s, same frame

Default branch (Earth→Mars, Stage 2)
    M = 0            zero extra revolutions (direct transfer)
    prograde = True  orbital angular momentum has positive frame-Z
    low_path = True  unused for M=0 (lamberthub documentation)

Frame
    Callers must pass r1 and r2 in the same inertial frame used for the
    velocities. Stage 2 uses SPICE ``J2000``. ``prograde`` is defined with
    respect to that frame's +Z axis (see Izzo implementation: ``i_h[2]``).
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np
from lamberthub import izzo2015

from ares.constants import GM_SUN_KM3_S2
from ares.errors import LambertError

SOLVER_NAME = "lamberthub.izzo2015"
SOLVER_REFERENCE = (
    "Izzo, D. (2015). Revisiting Lambert's problem. "
    "Celestial Mechanics and Dynamical Astronomy, 121(1), 1-15."
)

# Tighter than lamberthub defaults (atol=1e-5, rtol=1e-7). Those defaults are
# on the universal-x iterate, not kilometres. ARES uses tighter values so the
# reconstructed trajectory can be checked at the kilometre level.
DEFAULT_MAXITER = 50
DEFAULT_ATOL = 1e-12
DEFAULT_RTOL = 1e-10

# Geometry with |sin transfer angle| this small has an undefined transfer plane.
_COLLINEAR_SINE_LIMIT = 1e-12


@dataclass(frozen=True)
class LambertSolution:
    """Two-body transfer velocities connecting r1 to r2 in time Δt.

    Units: positions km, velocities km/s, mu km^3/s^2, time s, angle rad.
    """

    r_departure_km: np.ndarray
    r_arrival_km: np.ndarray
    v_departure_km_s: np.ndarray
    v_arrival_km_s: np.ndarray
    time_of_flight_s: float
    mu_km3_s2: float
    transfer_angle_rad: float
    revolutions: int
    prograde: bool
    low_path: bool
    solver: str
    solver_reference: str


def _as_vector(name: str, value: np.ndarray) -> np.ndarray:
    arr = np.asarray(value, dtype=float)
    if arr.shape != (3,):
        raise LambertError(
            f"{name} must be a 3-vector in km; got shape {arr.shape}."
        )
    if not np.all(np.isfinite(arr)):
        raise LambertError(f"{name} contains NaN or Inf: {arr!r}.")
    if float(np.linalg.norm(arr)) == 0.0:
        raise LambertError(f"{name} is the zero vector.")
    return np.array(arr, dtype=float, copy=True)


def transfer_angle_rad(
    r_departure_km: np.ndarray,
    r_arrival_km: np.ndarray,
    *,
    prograde: bool = True,
) -> float:
    """Signed-sense transfer angle in [0, 2π).

    The 0…π value is arccos(r1·r2 / |r1||r2|). If the z-component of r1×r2
    disagrees with the requested prograde sense (positive frame-Z angular
    momentum), the long-way angle 2π − θ is returned.

    This matches the ``i_h[2]`` branch in ``lamberthub.izzo2015``.
    """
    r1 = _as_vector("r_departure_km", r_departure_km)
    r2 = _as_vector("r_arrival_km", r_arrival_km)
    n1 = float(np.linalg.norm(r1))
    n2 = float(np.linalg.norm(r2))
    cos_a = float(np.clip(np.dot(r1, r2) / (n1 * n2), -1.0, 1.0))
    angle = float(np.arccos(cos_a))
    hz = float(np.cross(r1, r2)[2])
    if prograde and hz < 0.0:
        angle = 2.0 * np.pi - angle
    elif (not prograde) and hz > 0.0:
        angle = 2.0 * np.pi - angle
    return angle


def solve_lambert(
    r_departure_km: np.ndarray,
    r_arrival_km: np.ndarray,
    time_of_flight_s: float,
    mu_km3_s2: float = GM_SUN_KM3_S2,
    *,
    revolutions: int = 0,
    prograde: bool = True,
    low_path: bool = True,
) -> LambertSolution:
    """Solve Lambert's problem for one transfer.

    Default Stage 2 branch: M=0, prograde=True, low_path=True.
    ``low_path`` has no effect at M=0 (lamberthub user guide).
    """
    r1 = _as_vector("r_departure_km", r_departure_km)
    r2 = _as_vector("r_arrival_km", r_arrival_km)

    try:
        tof = float(time_of_flight_s)
        mu = float(mu_km3_s2)
    except (TypeError, ValueError) as exc:
        raise LambertError(
            f"time_of_flight_s and mu_km3_s2 must be real numbers: {exc}"
        ) from exc

    if not np.isfinite(tof) or tof <= 0.0:
        raise LambertError(
            f"Time of flight must be a positive finite number of seconds; got {time_of_flight_s!r}."
        )
    if not np.isfinite(mu) or mu <= 0.0:
        raise LambertError(
            f"mu_km3_s2 must be a positive finite gravitational parameter; got {mu_km3_s2!r}."
        )
    if revolutions != 0:
        raise LambertError(
            "Stage 2 only supports zero-revolution (M=0) transfers. "
            f"Received revolutions={revolutions}."
        )

    angle = transfer_angle_rad(r1, r2, prograde=prograde)
    sine = abs(np.sin(angle))
    if sine < _COLLINEAR_SINE_LIMIT:
        raise LambertError(
            "Lambert geometry is undefined: departure and arrival position "
            f"vectors are collinear (transfer angle {angle:.6f} rad). "
            "A 0° or 180° transfer has no unique orbital plane."
        )

    try:
        v1, v2 = izzo2015(
            mu,
            r1,
            r2,
            tof,
            M=0,
            prograde=bool(prograde),
            low_path=bool(low_path),
            maxiter=DEFAULT_MAXITER,
            atol=DEFAULT_ATOL,
            rtol=DEFAULT_RTOL,
        )
    except Exception as exc:  # lamberthub raises ValueError/RuntimeError
        raise LambertError(
            "Izzo (2015) Lambert solver failed. Check that the time of flight "
            "is physically feasible for a zero-revolution two-body transfer "
            "between these positions.\n"
            f"  |r1| km = {np.linalg.norm(r1):.6e}\n"
            f"  |r2| km = {np.linalg.norm(r2):.6e}\n"
            f"  Δt s    = {tof:.6e}\n"
            f"  μ km3/s2= {mu:.6e}\n"
            f"  angle   = {angle:.6f} rad\n"
            f"Original error ({type(exc).__name__}): {exc}"
        ) from exc

    v1 = np.asarray(v1, dtype=float)
    v2 = np.asarray(v2, dtype=float)
    if v1.shape != (3,) or v2.shape != (3,):
        raise LambertError(
            f"Solver returned unexpected velocity shapes {v1.shape}, {v2.shape}."
        )
    if not (np.all(np.isfinite(v1)) and np.all(np.isfinite(v2))):
        raise LambertError(
            f"Solver returned non-finite velocities: v1={v1!r}, v2={v2!r}."
        )

    return LambertSolution(
        r_departure_km=r1,
        r_arrival_km=r2,
        v_departure_km_s=np.array(v1, dtype=float, copy=True),
        v_arrival_km_s=np.array(v2, dtype=float, copy=True),
        time_of_flight_s=tof,
        mu_km3_s2=mu,
        transfer_angle_rad=angle,
        revolutions=0,
        prograde=bool(prograde),
        low_path=bool(low_path),
        solver=SOLVER_NAME,
        solver_reference=SOLVER_REFERENCE,
    )
