"""ARES exception types. Fail loudly; do not substitute fabricated values."""


class AresError(Exception):
    """Base class for all ARES errors."""


class KernelError(AresError):
    """Missing, corrupt, or unloaded SPICE kernels."""


class TimeScaleError(AresError):
    """Invalid civil time string or failed UTC→ET conversion."""


class EphemerisError(AresError):
    """SPICE could not compute a requested geometric state."""


class LambertError(AresError):
    """Lambert problem failed (invalid inputs, non-convergence, or undefined geometry)."""


class TrajectoryError(AresError):
    """Earth–Mars transfer request or two-body propagation failed."""
