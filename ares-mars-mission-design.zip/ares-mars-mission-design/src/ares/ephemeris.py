"""Heliocentric geometric state vectors from NASA/JPL NAIF SPICE.

Default query (Stage 1)
    Target     : EARTH (399) or MARS BARYCENTER (4)
    Observer   : SUN (10)
    Frame      : J2000 (SPICE inertial frame; DE440 is ICRF-aligned)
    Aberration : NONE (geometric state)
    Time scale : TDB at the observer, converted from UTC via SPICE
    Units      : position km, velocity km/s, light time seconds

de440s.bsp contains Earth (399) but does not contain Mars (499).
ARES therefore returns the Mars system barycenter (4) for Mars.
That is an explicit kernel limitation, not a silent body substitution
at query time: the public function names and StateVector.target_id
record the body that was actually requested.

Requires official kernels loaded by ``load_kernels``.
"""

from __future__ import annotations

import argparse
import os
import sys
from dataclasses import dataclass
from pathlib import Path

import numpy as np
import spiceypy
from spiceypy.utils.exceptions import SpiceyError

from ares.constants import (
    AU_KM,
    BODY_EARTH,
    BODY_MARS_BARYCENTER,
    BODY_SUN,
    DEFAULT_ABERRATION_CORRECTION,
    DEFAULT_FRAME,
    DEFAULT_OBSERVER,
    LSK_FILENAME,
    LSK_WINDOWS_FILENAME,
    NAIF_EARTH,
    NAIF_MARS_BARYCENTER,
    NAIF_SUN,
    SPK_FILENAME,
    SUPPORTED_ABERRATION_CORRECTIONS,
    SUPPORTED_INERTIAL_FRAMES,
)
from ares.errors import EphemerisError, KernelError, TimeScaleError
from ares.time import parse_utc, utc_to_et

_KERNELS_LOADED: bool = False
_LOADED_PATHS: tuple[Path, ...] = ()


def repository_root() -> Path:
    """Return the directory that contains ``pyproject.toml``.

    Resolution order:
        1. ``ARES_ROOT`` environment variable, if set
        2. Walk up from this file until ``pyproject.toml`` is found
        3. Current working directory (last resort)
    """
    env = os.environ.get("ARES_ROOT")
    if env:
        return Path(env).expanduser().resolve()

    here = Path(__file__).resolve()
    for parent in here.parents:
        if (parent / "pyproject.toml").is_file():
            return parent
    return Path.cwd().resolve()


def default_kernel_directory() -> Path:
    """Directory that holds downloaded NAIF kernels.

    Override with environment variable ``ARES_KERNEL_DIR``.
    Default: ``<repo>/data/kernels``.
    """
    env = os.environ.get("ARES_KERNEL_DIR")
    if env:
        return Path(env).expanduser().resolve()
    return repository_root() / "data" / "kernels"


def _platform_lsk_name() -> str:
    """NAIF ships a CRLF leapseconds kernel for native Windows CSPICE."""
    if sys.platform.startswith("win"):
        return LSK_WINDOWS_FILENAME
    return LSK_FILENAME


def required_kernel_paths(kernel_dir: Path | None = None) -> tuple[Path, Path]:
    """Return ``(lsk_path, spk_path)`` for Stage 1.

    On Windows the ``.tls.pc`` leapseconds kernel is preferred when present;
    otherwise the unix ``.tls`` file is used if it exists. Missing files are
    still returned so callers can emit a complete error message.
    """
    directory = kernel_dir or default_kernel_directory()
    preferred_lsk = directory / _platform_lsk_name()
    fallback_lsk = directory / LSK_FILENAME
    lsk = preferred_lsk if preferred_lsk.is_file() else fallback_lsk
    spk = directory / SPK_FILENAME
    return lsk, spk


def missing_kernels(kernel_dir: Path | None = None) -> list[Path]:
    """Return kernel paths that are not present on disk."""
    lsk, spk = required_kernel_paths(kernel_dir)
    missing = [path for path in (lsk, spk) if not path.is_file()]
    # If the platform LSK is missing, required_kernel_paths already fell back
    # to naif0012.tls; report that path. Also mention the Windows file when
    # that was the preferred name and neither file exists.
    return missing


@dataclass(frozen=True)
class KernelConfiguration:
    """Loaded Stage 1 kernel set.

    Attributes
        lsk_path, spk_path : filesystem paths actually furnished to SPICE
        lsk_filename, spk_filename : basenames for reports
    """

    lsk_path: Path
    spk_path: Path

    @property
    def paths(self) -> tuple[Path, Path]:
        return self.lsk_path, self.spk_path


def load_kernels(
    kernel_dir: Path | None = None,
    *,
    reload: bool = False,
) -> KernelConfiguration:
    """Load the Stage 1 LSK and planetary SPK into the SPICE kernel pool.

    Fails loudly if files are missing or SPICE rejects them. Does not
    download kernels; run ``python scripts/download_kernels.py`` first.
    """
    global _KERNELS_LOADED, _LOADED_PATHS

    if _KERNELS_LOADED and not reload:
        lsk, spk = required_kernel_paths(kernel_dir)
        return KernelConfiguration(lsk_path=lsk, spk_path=spk)

    missing = missing_kernels(kernel_dir)
    if missing:
        directory = kernel_dir or default_kernel_directory()
        listed = "\n".join(f"  - {path}" for path in missing)
        raise KernelError(
            "Required NAIF kernels are not on disk.\n"
            f"{listed}\n"
            "Fix: from the repository root run\n"
            "  python scripts/download_kernels.py\n"
            f"Kernels are expected in: {directory}\n"
            "Override the directory with ARES_KERNEL_DIR if needed."
        )

    lsk, spk = required_kernel_paths(kernel_dir)
    spiceypy.kclear()
    try:
        spiceypy.furnsh(str(lsk))
        spiceypy.furnsh(str(spk))
    except SpiceyError as exc:
        spiceypy.kclear()
        _KERNELS_LOADED = False
        _LOADED_PATHS = ()
        raise KernelError(
            "SPICE rejected a kernel file while loading.\n"
            f"  LSK: {lsk}\n"
            f"  SPK: {spk}\n"
            "Re-download with `python scripts/download_kernels.py --force`.\n"
            f"Original SPICE message: {exc}"
        ) from exc

    _KERNELS_LOADED = True
    _LOADED_PATHS = (lsk, spk)
    return KernelConfiguration(lsk_path=lsk, spk_path=spk)


def unload_kernels() -> None:
    """Clear the SPICE kernel pool. Intended for tests."""
    global _KERNELS_LOADED, _LOADED_PATHS
    spiceypy.kclear()
    _KERNELS_LOADED = False
    _LOADED_PATHS = ()


def _require_kernels() -> None:
    if not _KERNELS_LOADED:
        load_kernels()


def _normalize_frame(frame: str) -> str:
    name = frame.strip().upper()
    if name not in SUPPORTED_INERTIAL_FRAMES:
        supported = ", ".join(sorted(SUPPORTED_INERTIAL_FRAMES))
        raise EphemerisError(
            f"Unsupported reference frame {frame!r}. Stage 1 allows only the "
            f"inertial frames: {supported}. Body-fixed frames are not "
            "supported because Stage 1 does not load a PCK."
        )
    return name


def _normalize_abcorr(abcorr: str) -> str:
    name = abcorr.strip().upper().replace(" ", "")
    if name not in SUPPORTED_ABERRATION_CORRECTIONS:
        supported = ", ".join(sorted(SUPPORTED_ABERRATION_CORRECTIONS))
        raise EphemerisError(
            f"Unsupported aberration correction {abcorr!r}. "
            f"Allowed SPICE flags: {supported}. "
            "Mission-design geometric states use 'NONE'."
        )
    return name


@dataclass(frozen=True)
class StateVector:
    """Geometric or aberration-corrected Cartesian state.

    Units
        position_km          : km
        velocity_km_s        : km/s
        light_time_s         : seconds
        et_seconds           : TDB seconds past J2000
    Frame
        ``frame`` is the SPICE frame of position and velocity.
    Observer / target
        Position points from observer to target (SPICE SPKEZR convention).
        ``target_id`` / ``observer_id`` are NAIF integer IDs actually used.
    Time
        ``utc`` is the requested UTC epoch; ``et_seconds`` is SPICE ET/TDB
        at the observer.
    """

    utc: str
    et_seconds: float
    target: str
    target_id: int
    observer: str
    observer_id: int
    frame: str
    aberration_correction: str
    position_km: np.ndarray
    velocity_km_s: np.ndarray
    light_time_s: float
    spk_kernel: str
    lsk_kernel: str

    @property
    def radius_km(self) -> float:
        """Heliocentric (or observer-relative) distance, km."""
        return float(np.linalg.norm(self.position_km))

    @property
    def speed_km_s(self) -> float:
        """Speed relative to the observer, km/s."""
        return float(np.linalg.norm(self.velocity_km_s))

    def as_dict(self) -> dict[str, object]:
        return {
            "utc": self.utc,
            "et_seconds_tdb_past_j2000": self.et_seconds,
            "target": self.target,
            "target_naif_id": self.target_id,
            "observer": self.observer,
            "observer_naif_id": self.observer_id,
            "frame": self.frame,
            "aberration_correction": self.aberration_correction,
            "position_km": self.position_km.tolist(),
            "velocity_km_s": self.velocity_km_s.tolist(),
            "radius_km": self.radius_km,
            "speed_km_s": self.speed_km_s,
            "light_time_s": self.light_time_s,
            "spk_kernel": self.spk_kernel,
            "lsk_kernel": self.lsk_kernel,
            "units": {
                "position": "km",
                "velocity": "km/s",
                "light_time": "s",
                "et": "s, TDB past J2000",
            },
        }


def _naif_id(name: str) -> int:
    """Translate a NAIF body name to its integer ID.

    SpiceyPy ``bodn2c`` returns the integer ID and raises ``NotFoundError``
    (a ``SpiceyError``) if the name is unknown. It does not return a found flag.
    """
    try:
        return int(spiceypy.bodn2c(name))
    except SpiceyError as exc:
        raise EphemerisError(
            f"SPICE does not recognize body name {name!r}. "
            "Use a NAIF name or integer ID string (for example 'EARTH', "
            "'MARS BARYCENTER', 'SUN', '399', '4', '10'). "
            f"Original SPICE message: {exc}"
        ) from exc


def state(
    target: str,
    utc: str,
    *,
    observer: str = DEFAULT_OBSERVER,
    frame: str = DEFAULT_FRAME,
    aberration_correction: str = DEFAULT_ABERRATION_CORRECTION,
) -> StateVector:
    """Return the SPICE state of ``target`` relative to ``observer``.

    Input
        target, observer : NAIF body names or ID strings
        utc              : UTC civil time (see ``ares.time.parse_utc``)
        frame            : SPICE inertial frame (default ``J2000``)
        aberration_correction : SPICE abcorr flag (default ``NONE``)
    Output
        StateVector with position in km and velocity in km/s in ``frame``.
    Assumptions
        Geometric states (abcorr=NONE) are the default for trajectory design.
        Light-time returned for NONE is the geometric range over c (SPICE).
    """
    _require_kernels()
    canonical_utc = parse_utc(utc)
    et = utc_to_et(canonical_utc)
    frame_name = _normalize_frame(frame)
    abcorr = _normalize_abcorr(aberration_correction)
    target_name = target.strip()
    observer_name = observer.strip()

    try:
        starg, light_time = spiceypy.spkezr(
            target_name, et, frame_name, abcorr, observer_name
        )
    except SpiceyError as exc:
        hint = ""
        upper = target_name.upper()
        if upper in {"MARS", "499"}:
            hint = (
                " de440s.bsp does not contain Mars body 499; request "
                "'MARS BARYCENTER' (NAIF ID 4). "
                "earth_heliocentric_state / mars_heliocentric_state already "
                "do this."
            )
        raise EphemerisError(
            "SPICE could not compute the requested state.\n"
            f"  target    : {target_name}\n"
            f"  observer  : {observer_name}\n"
            f"  frame     : {frame_name}\n"
            f"  abcorr    : {abcorr}\n"
            f"  utc       : {canonical_utc}\n"
            f"  et (TDB s): {et!r}\n"
            f"Fix: confirm kernels are loaded and the body is in de440s.bsp."
            f"{hint}\n"
            f"Original SPICE message: {exc}"
        ) from exc

    starg_arr = np.asarray(starg, dtype=float)
    if starg_arr.shape != (6,):
        raise EphemerisError(
            f"SPICE returned a state of unexpected shape {starg_arr.shape}; "
            "expected (6,) [rx, ry, rz, vx, vy, vz]."
        )
    if not np.all(np.isfinite(starg_arr)) or not np.isfinite(light_time):
        raise EphemerisError(
            f"SPICE returned a non-finite state or light time for "
            f"{target_name} at {canonical_utc}: state={starg_arr!r}, "
            f"lt={light_time!r}."
        )

    position = np.array(starg_arr[:3], dtype=float, copy=True)
    velocity = np.array(starg_arr[3:], dtype=float, copy=True)
    lsk_path, spk_path = (
        _LOADED_PATHS if _LOADED_PATHS else required_kernel_paths()
    )
    return StateVector(
        utc=canonical_utc,
        et_seconds=et,
        target=target_name,
        target_id=_naif_id(target_name),
        observer=observer_name,
        observer_id=_naif_id(observer_name),
        frame=frame_name,
        aberration_correction=abcorr,
        position_km=position,
        velocity_km_s=velocity,
        light_time_s=float(light_time),
        spk_kernel=spk_path.name,
        lsk_kernel=lsk_path.name,
    )


def earth_heliocentric_state(
    utc: str,
    *,
    frame: str = DEFAULT_FRAME,
    aberration_correction: str = DEFAULT_ABERRATION_CORRECTION,
) -> StateVector:
    """Heliocentric geometric state of Earth body center (NAIF 399).

    Observer is the Sun (10), not the solar-system barycenter.
    """
    vector = state(
        BODY_EARTH,
        utc,
        observer=BODY_SUN,
        frame=frame,
        aberration_correction=aberration_correction,
    )
    if vector.target_id != NAIF_EARTH or vector.observer_id != NAIF_SUN:
        raise EphemerisError(
            "Earth heliocentric query did not resolve to NAIF 399 relative "
            f"to 10 (got target_id={vector.target_id}, "
            f"observer_id={vector.observer_id})."
        )
    return vector


def mars_heliocentric_state(
    utc: str,
    *,
    frame: str = DEFAULT_FRAME,
    aberration_correction: str = DEFAULT_ABERRATION_CORRECTION,
) -> StateVector:
    """Heliocentric geometric state of the Mars *system barycenter* (NAIF 4).

    This is not Mars body center (NAIF 499). de440s.bsp has no 499 segment.
    The 4 vs 499 offset is ~0.2 m (docs/PHYSICS.md §1.2). ARES does not
    invent 499 or silently substitute it.
    """
    vector = state(
        BODY_MARS_BARYCENTER,
        utc,
        observer=BODY_SUN,
        frame=frame,
        aberration_correction=aberration_correction,
    )
    if vector.target_id != NAIF_MARS_BARYCENTER or vector.observer_id != NAIF_SUN:
        raise EphemerisError(
            "Mars heliocentric query did not resolve to NAIF 4 relative "
            f"to 10 (got target_id={vector.target_id}, "
            f"observer_id={vector.observer_id})."
        )
    return vector


def format_state_report(
    earth: StateVector,
    mars: StateVector,
) -> str:
    """Human-readable, fully labelled report for two heliocentric states."""
    lines = [
        "ARES Stage 1 — heliocentric geometric states",
        "Source: NASA/JPL NAIF SPICE via SpiceyPy (spkezr)",
        f"SPK: {earth.spk_kernel}",
        f"LSK: {earth.lsk_kernel}",
        f"Frame: {earth.frame} (SPICE inertial; DE440 aligned to ICRF)",
        f"Observer: {earth.observer} (NAIF {earth.observer_id}) — heliocentric, not barycentric",
        f"Aberration correction: {earth.aberration_correction}",
        f"UTC: {earth.utc}",
        f"ET  : {earth.et_seconds:.9f} seconds TDB past J2000",
        "Units: position km, velocity km/s, light time s",
        "",
        _format_one(earth, "Earth body center"),
        "",
        _format_one(mars, "Mars system barycenter"),
        "",
        "These are ARES/SPICE results, not a Horizons comparison.",
        "Independent Horizons validation is documented in docs/VALIDATION.md.",
    ]
    return "\n".join(lines)


def _format_one(vector: StateVector, title: str) -> str:
    x, y, z = vector.position_km
    vx, vy, vz = vector.velocity_km_s
    return "\n".join(
        [
            f"{title}",
            f"  target           : {vector.target} (NAIF {vector.target_id})",
            f"  position_km      : [{x:.16e}, {y:.16e}, {z:.16e}]",
            f"  velocity_km_s    : [{vx:.16e}, {vy:.16e}, {vz:.16e}]",
            f"  radius_km        : {vector.radius_km:.16e}",
            f"  speed_km_s       : {vector.speed_km_s:.16e}",
            f"  light_time_s     : {vector.light_time_s:.16e}",
            f"  radius_au        : {vector.radius_km / AU_KM:.16e}  (IAU 2012 au)",
        ]
    )


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        prog="python -m ares.ephemeris",
        description=(
            "Print Earth and Mars heliocentric geometric state vectors "
            "from NASA/JPL NAIF SPICE (DE440s)."
        ),
    )
    parser.add_argument(
        "--date",
        required=True,
        help='UTC epoch, ISO-8601, e.g. "2026-10-31T00:00:00"',
    )
    parser.add_argument(
        "--frame",
        default=DEFAULT_FRAME,
        help=f"SPICE inertial frame (default {DEFAULT_FRAME})",
    )
    parser.add_argument(
        "--abcorr",
        default=DEFAULT_ABERRATION_CORRECTION,
        help="SPICE aberration flag (default NONE = geometric)",
    )
    parser.add_argument(
        "--kernel-dir",
        default=None,
        help="Directory containing naif0012.tls and de440s.bsp",
    )
    args = parser.parse_args(argv)

    kernel_dir = Path(args.kernel_dir) if args.kernel_dir else None
    try:
        load_kernels(kernel_dir)
        earth = earth_heliocentric_state(
            args.date, frame=args.frame, aberration_correction=args.abcorr
        )
        mars = mars_heliocentric_state(
            args.date, frame=args.frame, aberration_correction=args.abcorr
        )
    except (KernelError, EphemerisError, TimeScaleError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1

    print(format_state_report(earth, mars))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
