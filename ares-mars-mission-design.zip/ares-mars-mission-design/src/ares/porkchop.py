"""Earth→Mars launch-window grid (porkchop dataset).

Orchestrates validated Stage 1/2 physics. Does not re-implement Lambert, C3,
or SPICE. Planetary states are precomputed once per epoch and reused.

Invalid cells use NaN + an explicit status code. Zero is never used as a
failure flag (C3 = 0 would be physically meaningful).

Default search bounds are exploratory, not an asserted optimum.
"""

from __future__ import annotations

import argparse
import csv
import sys
import time
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from pathlib import Path

import numpy as np

from ares.constants import (
    DEFAULT_ABERRATION_CORRECTION,
    DEFAULT_FRAME,
    GM_SUN_KM3_S2,
    NAIF_EARTH,
    NAIF_MARS_BARYCENTER,
    NAIF_SUN,
    SECONDS_PER_DAY,
)
from ares.ephemeris import (
    earth_heliocentric_state,
    load_kernels,
    mars_heliocentric_state,
)
from ares.errors import (
    EphemerisError,
    KernelError,
    LambertError,
    TimeScaleError,
    TrajectoryError,
)
from ares.time import parse_utc
from ares.trajectory import lambert_energetics

# ---------------------------------------------------------------------------
# Defaults (documented in docs/PHYSICS.md)
# Hohmann Earth–Mars TOF ≈ 259 days (π√(a³/μ) with NSSDCA SMAs and DE440 μ).
# NASA/TM-2010-216764 2026 Type I/II ballistic TOFs are ~190–400 days.
# 100–500 days is a broad envelope that keeps M=0 Type I and Type II without
# clipping either branch, and without admitting multi-rev transfers.
# ---------------------------------------------------------------------------

DEFAULT_DEPARTURE_START = "2026-07-01T00:00:00"
DEFAULT_DEPARTURE_END = "2027-03-01T00:00:00"
DEFAULT_ARRIVAL_START = "2027-03-01T00:00:00"
DEFAULT_ARRIVAL_END = "2028-06-01T00:00:00"
DEFAULT_STEP_DAYS = 5.0
DEFAULT_MIN_TOF_DAYS = 100.0
DEFAULT_MAX_TOF_DAYS = 500.0

STATUS_VALID = 0
STATUS_SKIP_TOF = 1
STATUS_LAMBERT_FAIL = 2
STATUS_EPHEMERIS_FAIL = 3

STATUS_LABEL = {
    STATUS_VALID: "valid",
    STATUS_SKIP_TOF: "skipped_tof",
    STATUS_LAMBERT_FAIL: "lambert_failed",
    STATUS_EPHEMERIS_FAIL: "ephemeris_failed",
}

# Plot color ceiling only. NASA/TM-2010-216764 treated C3 > 50 km²/s² as
# generally not of interest. The CSV and candidate search are unclipped.
C3_PLOT_ZMAX_KM2_S2 = 50.0

# API/CLI safety cap. Not a physics limit. Default 5-day 2026/27 grid is 4650.
# Documented in README. Requests above this are rejected, not truncated.
MAX_PORKCHOP_CELLS = 12_000


def _to_datetime(utc: str) -> datetime:
    canonical = parse_utc(utc)
    iso = canonical.replace(" UTC", "")
    return datetime.fromisoformat(iso).replace(tzinfo=timezone.utc)


def _from_datetime(moment: datetime) -> str:
    if moment.tzinfo is None:
        raise TrajectoryError("Internal date grid produced a naive datetime.")
    utc = moment.astimezone(timezone.utc)
    return utc.strftime("%Y-%m-%dT%H:%M:%S.%f") + " UTC"


def utc_date_grid(start_utc: str, end_utc: str, step_days: float) -> list[str]:
    """UTC epochs from start through end inclusive, stepping ``step_days``.

    The last point is the last step ≤ end. If end is not on a step, it is
    appended so both bounds appear. Step must be positive.
    """
    if not np.isfinite(step_days) or step_days <= 0.0:
        raise TrajectoryError(
            f"step_days must be a positive finite number; got {step_days!r}."
        )
    start = _to_datetime(start_utc)
    end = _to_datetime(end_utc)
    if end < start:
        raise TrajectoryError(
            f"Grid end {end_utc!r} is before start {start_utc!r}."
        )
    step = timedelta(days=float(step_days))
    dates: list[str] = []
    cursor = start
    # Guard against an infinite loop from a degenerate timedelta.
    max_steps = int((end - start) / step) + 3
    for _ in range(max_steps + 1):
        if cursor > end:
            break
        dates.append(_from_datetime(cursor))
        cursor = cursor + step
    if not dates:
        raise TrajectoryError("Date grid is empty.")
    end_canonical = parse_utc(end_utc)
    if parse_utc(dates[-1]) != end_canonical:
        dates.append(_from_datetime(end))
    return dates


def _estimate_grid_length(start_utc: str, end_utc: str, step_days: float) -> int:
    """Inclusive step count without allocating the date list. Conservative (+2)."""
    if not np.isfinite(step_days) or step_days <= 0.0:
        raise TrajectoryError(
            f"step_days must be a positive finite number; got {step_days!r}."
        )
    start = _to_datetime(start_utc)
    end = _to_datetime(end_utc)
    if end < start:
        raise TrajectoryError(
            f"Grid end {end_utc!r} is before start {start_utc!r}."
        )
    span_days = (end - start).total_seconds() / float(SECONDS_PER_DAY)
    return int(span_days / float(step_days)) + 2


@dataclass(frozen=True)
class PorkchopCandidate:
    name: str
    departure_utc: str
    arrival_utc: str
    tof_days: float
    c3_km2_s2: float
    earth_vinf_km_s: float
    mars_vinf_km_s: float
    departure_index: int
    arrival_index: int


@dataclass
class PorkchopGrid:
    """2-D launch-window arrays. Shape is (n_departure, n_arrival)."""

    departure_utc: list[str]
    arrival_utc: list[str]
    departure_et_s: np.ndarray
    arrival_et_s: np.ndarray
    tof_days: np.ndarray
    c3_km2_s2: np.ndarray
    earth_vinf_km_s: np.ndarray
    mars_vinf_km_s: np.ndarray
    valid: np.ndarray
    status: np.ndarray
    min_tof_days: float
    max_tof_days: float
    step_days: float
    frame: str
    aberration_correction: str
    mu_km3_s2: float
    n_lambert_attempts: int = 0
    n_lambert_success: int = 0
    n_lambert_failed: int = 0
    n_skipped_tof: int = 0
    runtime_s: float = 0.0
    earth_states_cached: int = 0
    mars_states_cached: int = 0

    @property
    def n_departure(self) -> int:
        return len(self.departure_utc)

    @property
    def n_arrival(self) -> int:
        return len(self.arrival_utc)

    @property
    def n_potential(self) -> int:
        return self.n_departure * self.n_arrival


def compute_porkchop(
    departure_start: str = DEFAULT_DEPARTURE_START,
    departure_end: str = DEFAULT_DEPARTURE_END,
    arrival_start: str = DEFAULT_ARRIVAL_START,
    arrival_end: str = DEFAULT_ARRIVAL_END,
    *,
    step_days: float = DEFAULT_STEP_DAYS,
    min_tof_days: float = DEFAULT_MIN_TOF_DAYS,
    max_tof_days: float = DEFAULT_MAX_TOF_DAYS,
    frame: str = DEFAULT_FRAME,
    aberration_correction: str = DEFAULT_ABERRATION_CORRECTION,
    mu_km3_s2: float = GM_SUN_KM3_S2,
) -> PorkchopGrid:
    """Build a porkchop grid using cached SPICE states and Stage 2 Lambert."""
    if min_tof_days < 0.0 or max_tof_days <= min_tof_days:
        raise TrajectoryError(
            f"Require 0 ≤ min_tof_days < max_tof_days; got {min_tof_days}, {max_tof_days}."
        )

    n_d_est = _estimate_grid_length(departure_start, departure_end, step_days)
    n_a_est = _estimate_grid_length(arrival_start, arrival_end, step_days)
    if n_d_est * n_a_est > MAX_PORKCHOP_CELLS:
        raise TrajectoryError(
            "Porkchop grid exceeds the safety cap of "
            f"{MAX_PORKCHOP_CELLS} cells "
            f"(about {n_d_est} departures × {n_a_est} arrivals = "
            f"{n_d_est * n_a_est}). "
            "Increase step_days or shrink the date window. "
            "The request was rejected, not truncated."
        )

    dep_utc = utc_date_grid(departure_start, departure_end, step_days)
    arr_utc = utc_date_grid(arrival_start, arrival_end, step_days)
    n_d, n_a = len(dep_utc), len(arr_utc)
    n_potential = n_d * n_a
    if n_potential > MAX_PORKCHOP_CELLS:
        raise TrajectoryError(
            "Porkchop grid exceeds the safety cap of "
            f"{MAX_PORKCHOP_CELLS} cells "
            f"({n_d} departures × {n_a} arrivals = {n_potential}). "
            "Increase --step-days (or step_days) or shrink the date window. "
            "The request was rejected, not truncated."
        )
    shape = (n_d, n_a)

    earth_r = np.empty((n_d, 3), dtype=float)
    earth_v = np.empty((n_d, 3), dtype=float)
    earth_et = np.empty(n_d, dtype=float)
    mars_r = np.empty((n_a, 3), dtype=float)
    mars_v = np.empty((n_a, 3), dtype=float)
    mars_et = np.empty(n_a, dtype=float)

    t0 = time.perf_counter()
    for i, utc in enumerate(dep_utc):
        state = earth_heliocentric_state(
            utc, frame=frame, aberration_correction=aberration_correction
        )
        earth_r[i] = state.position_km
        earth_v[i] = state.velocity_km_s
        earth_et[i] = state.et_seconds
    for j, utc in enumerate(arr_utc):
        state = mars_heliocentric_state(
            utc, frame=frame, aberration_correction=aberration_correction
        )
        mars_r[j] = state.position_km
        mars_v[j] = state.velocity_km_s
        mars_et[j] = state.et_seconds

    tof = np.full(shape, np.nan)
    c3 = np.full(shape, np.nan)
    vinf_e = np.full(shape, np.nan)
    vinf_m = np.full(shape, np.nan)
    valid = np.zeros(shape, dtype=bool)
    status = np.full(shape, STATUS_SKIP_TOF, dtype=np.int8)

    n_attempt = n_ok = n_fail = n_skip = 0
    min_s = min_tof_days * SECONDS_PER_DAY
    max_s = max_tof_days * SECONDS_PER_DAY

    for i in range(n_d):
        for j in range(n_a):
            dt = float(mars_et[j] - earth_et[i])
            if not np.isfinite(dt) or dt <= 0.0 or dt < min_s or dt > max_s:
                n_skip += 1
                status[i, j] = STATUS_SKIP_TOF
                continue
            n_attempt += 1
            try:
                _lambert, ev, mv = lambert_energetics(
                    earth_r[i],
                    earth_v[i],
                    mars_r[j],
                    mars_v[j],
                    dt,
                    mu_km3_s2,
                )
            except (LambertError, TrajectoryError):
                n_fail += 1
                status[i, j] = STATUS_LAMBERT_FAIL
                continue
            tof[i, j] = dt / SECONDS_PER_DAY
            c3[i, j] = ev.c3_km2_s2
            vinf_e[i, j] = ev.magnitude_km_s
            vinf_m[i, j] = mv.magnitude_km_s
            valid[i, j] = True
            status[i, j] = STATUS_VALID
            n_ok += 1

    runtime = time.perf_counter() - t0
    return PorkchopGrid(
        departure_utc=dep_utc,
        arrival_utc=arr_utc,
        departure_et_s=earth_et,
        arrival_et_s=mars_et,
        tof_days=tof,
        c3_km2_s2=c3,
        earth_vinf_km_s=vinf_e,
        mars_vinf_km_s=vinf_m,
        valid=valid,
        status=status,
        min_tof_days=min_tof_days,
        max_tof_days=max_tof_days,
        step_days=step_days,
        frame=frame,
        aberration_correction=aberration_correction,
        mu_km3_s2=mu_km3_s2,
        n_lambert_attempts=n_attempt,
        n_lambert_success=n_ok,
        n_lambert_failed=n_fail,
        n_skipped_tof=n_skip,
        runtime_s=runtime,
        earth_states_cached=n_d,
        mars_states_cached=n_a,
    )


def _valid_mask(
    grid: PorkchopGrid,
    *,
    max_c3: float | None = None,
    max_mars_vinf: float | None = None,
    min_tof_days: float | None = None,
    max_tof_days: float | None = None,
) -> np.ndarray:
    mask = grid.valid.copy()
    if max_c3 is not None:
        mask &= grid.c3_km2_s2 <= max_c3
    if max_mars_vinf is not None:
        mask &= grid.mars_vinf_km_s <= max_mars_vinf
    if min_tof_days is not None:
        mask &= grid.tof_days >= min_tof_days
    if max_tof_days is not None:
        mask &= grid.tof_days <= max_tof_days
    return mask


def _argmin_candidate(
    grid: PorkchopGrid, field: np.ndarray, name: str, mask: np.ndarray
) -> PorkchopCandidate | None:
    if not np.any(mask):
        return None
    masked = np.where(mask, field, np.nan)
    index = int(np.nanargmin(masked))
    i, j = np.unravel_index(index, field.shape)
    i, j = int(i), int(j)
    return PorkchopCandidate(
        name=name,
        departure_utc=grid.departure_utc[i],
        arrival_utc=grid.arrival_utc[j],
        tof_days=float(grid.tof_days[i, j]),
        c3_km2_s2=float(grid.c3_km2_s2[i, j]),
        earth_vinf_km_s=float(grid.earth_vinf_km_s[i, j]),
        mars_vinf_km_s=float(grid.mars_vinf_km_s[i, j]),
        departure_index=i,
        arrival_index=j,
    )


def select_candidates(
    grid: PorkchopGrid,
    *,
    max_c3: float | None = None,
    max_mars_vinf: float | None = None,
    min_tof_days: float | None = None,
    max_tof_days: float | None = None,
) -> dict[str, PorkchopCandidate]:
    """Named extrema over valid cells. Not a 'best mission' ranking."""
    mask = _valid_mask(
        grid,
        max_c3=max_c3,
        max_mars_vinf=max_mars_vinf,
        min_tof_days=min_tof_days,
        max_tof_days=max_tof_days,
    )
    found: dict[str, PorkchopCandidate] = {}
    mapping = (
        ("minimum_c3", grid.c3_km2_s2, "Minimum C3 Candidate"),
        ("minimum_earth_vinf", grid.earth_vinf_km_s, "Minimum Earth v∞ Candidate"),
        ("minimum_mars_vinf", grid.mars_vinf_km_s, "Minimum Arrival v∞ Candidate"),
        ("shortest_tof", grid.tof_days, "Shortest TOF Candidate"),
    )
    for key, field, title in mapping:
        cand = _argmin_candidate(grid, field, title, mask)
        if cand is not None:
            found[key] = cand
    return found


def refine_around(
    grid: PorkchopGrid,
    candidate: PorkchopCandidate,
    *,
    half_width_days: float = 15.0,
    step_days: float = 1.0,
) -> PorkchopGrid:
    """1-day (or other) grid around one coarse-grid candidate."""
    dep0 = _to_datetime(candidate.departure_utc)
    arr0 = _to_datetime(candidate.arrival_utc)
    delta = timedelta(days=float(half_width_days))
    return compute_porkchop(
        _from_datetime(dep0 - delta),
        _from_datetime(dep0 + delta),
        _from_datetime(arr0 - delta),
        _from_datetime(arr0 + delta),
        step_days=step_days,
        min_tof_days=grid.min_tof_days,
        max_tof_days=grid.max_tof_days,
        frame=grid.frame,
        aberration_correction=grid.aberration_correction,
        mu_km3_s2=grid.mu_km3_s2,
    )


def cell_indices(
    grid: PorkchopGrid, departure_utc: str, arrival_utc: str
) -> tuple[int, int]:
    """Return (i, j) for a date pair that exists on the grid."""
    dep = parse_utc(departure_utc)
    arr = parse_utc(arrival_utc)
    try:
        i = [parse_utc(u) for u in grid.departure_utc].index(dep)
        j = [parse_utc(u) for u in grid.arrival_utc].index(arr)
    except ValueError as exc:
        raise TrajectoryError(
            "Requested date pair is not a grid node.\n"
            f"  departure: {dep}\n"
            f"  arrival  : {arr}"
        ) from exc
    return i, j


def export_csv(grid: PorkchopGrid, path: Path) -> Path:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.writer(handle)
        writer.writerow(
            [
                "departure_utc",
                "arrival_utc",
                "tof_days",
                "c3_km2_s2",
                "earth_vinf_km_s",
                "mars_vinf_km_s",
                "valid",
                "status",
            ]
        )
        for i, dep in enumerate(grid.departure_utc):
            for j, arr in enumerate(grid.arrival_utc):
                writer.writerow(
                    [
                        dep,
                        arr,
                        "" if not grid.valid[i, j] else f"{grid.tof_days[i, j]:.9f}",
                        "" if not grid.valid[i, j] else f"{grid.c3_km2_s2[i, j]:.9f}",
                        "" if not grid.valid[i, j] else f"{grid.earth_vinf_km_s[i, j]:.9f}",
                        "" if not grid.valid[i, j] else f"{grid.mars_vinf_km_s[i, j]:.9f}",
                        "true" if grid.valid[i, j] else "false",
                        STATUS_LABEL.get(int(grid.status[i, j]), "unknown"),
                    ]
                )
    return path


def _plotly_axis_labels(utc_list: list[str]) -> list[str]:
    return [parse_utc(u).replace(" UTC", "")[:10] for u in utc_list]


def plot_porkchop_html(
    grid: PorkchopGrid,
    path: Path,
    candidates: dict[str, PorkchopCandidate] | None = None,
) -> Path:
    """C3 contour porkchop with hover and candidate markers."""
    try:
        import plotly.graph_objects as go
    except ImportError as exc:
        raise TrajectoryError(
            "plotly is not installed. From the repository root run:\n"
            "  python -m pip install plotly\n"
            "then retry."
        ) from exc

    candidates = candidates or select_candidates(grid)
    x_labels = _plotly_axis_labels(grid.arrival_utc)
    y_labels = _plotly_axis_labels(grid.departure_utc)
    z = np.array(grid.c3_km2_s2, dtype=float)
    z[~grid.valid] = np.nan

    custom = np.stack(
        [
            grid.tof_days,
            grid.c3_km2_s2,
            grid.earth_vinf_km_s,
            grid.mars_vinf_km_s,
        ],
        axis=-1,
    )
    hover = (
        "Departure: %{y}<br>"
        "Arrival: %{x}<br>"
        "TOF: %{customdata[0]:.1f} days<br>"
        "C3: %{customdata[1]:.2f} km²/s²<br>"
        "Earth v∞: %{customdata[2]:.3f} km/s<br>"
        "Mars v∞: %{customdata[3]:.3f} km/s"
        "<extra></extra>"
    )
    fig = go.Figure()
    fig.add_trace(
        go.Heatmap(
            x=x_labels,
            y=y_labels,
            z=z,
            zmin=0.0,
            zmax=C3_PLOT_ZMAX_KM2_S2,
            customdata=custom,
            hovertemplate=hover,
            colorbar={"title": "C3 [km²/s²]"},
            colorscale="Viridis_r",
            name="C3",
        )
    )
    # Contour lines are a visualization aid on sampled valid cells.
    # Failed cells stay NaN (connectgaps=False). CSV values are uninterpolated.
    fig.add_trace(
        go.Contour(
            x=x_labels,
            y=y_labels,
            z=z,
            contours={
                "start": 5,
                "end": C3_PLOT_ZMAX_KM2_S2,
                "size": 5,
                "coloring": "none",
                "showlabels": True,
            },
            line={"width": 1, "color": "white"},
            connectgaps=False,
            showscale=False,
            hoverinfo="skip",
            name="C3 contours",
        )
    )
    marker_style = {
        "minimum_c3": dict(symbol="star", size=14, name="★ Minimum C3"),
        "minimum_mars_vinf": dict(
            symbol="diamond", size=11, name="Minimum Arrival v∞"
        ),
        "shortest_tof": dict(symbol="x", size=11, name="Shortest TOF"),
    }
    used_cells: set[tuple[int, int]] = set()
    for key, style in marker_style.items():
        cand = candidates.get(key)
        if cand is None:
            continue
        cell = (cand.departure_index, cand.arrival_index)
        if cell in used_cells and key != "minimum_c3":
            continue
        used_cells.add(cell)
        fig.add_trace(
            go.Scatter(
                x=[x_labels[cand.arrival_index]],
                y=[y_labels[cand.departure_index]],
                mode="markers",
                marker={
                    "symbol": style["symbol"],
                    "size": style["size"],
                    "color": "white",
                    "line": {"color": "black", "width": 1},
                },
                name=style["name"],
                hovertemplate=(
                    f"{cand.name}<br>"
                    f"Departure: {parse_utc(cand.departure_utc)[:10]}<br>"
                    f"Arrival: {parse_utc(cand.arrival_utc)[:10]}<br>"
                    f"TOF: {cand.tof_days:.1f} days<br>"
                    f"C3: {cand.c3_km2_s2:.2f} km²/s²<br>"
                    f"Earth v∞: {cand.earth_vinf_km_s:.3f} km/s<br>"
                    f"Mars v∞: {cand.mars_vinf_km_s:.3f} km/s"
                    "<extra></extra>"
                ),
            )
        )
    fig.update_layout(
        title="ARES Earth→Mars porkchop — C3 [km²/s²]<br>"
        "Heliocentric two-body Lambert grid (C3 is not launch ΔV). "
        f"Color scale clipped at {C3_PLOT_ZMAX_KM2_S2:g} km²/s² for display.",
        xaxis_title="Arrival date (UTC)",
        yaxis_title="Departure date (UTC)",
        legend={"orientation": "h", "y": -0.22},
        margin={"l": 60, "r": 40, "t": 90, "b": 80},
        width=900,
        height=720,
    )
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    fig.write_html(str(path), include_plotlyjs=True)
    return path


def format_grid_report(
    grid: PorkchopGrid, candidates: dict[str, PorkchopCandidate]
) -> str:
    lines = [
        "ARES Earth → Mars porkchop (heliocentric two-body Lambert)",
        f"Frame: {grid.frame}   Aberration: {grid.aberration_correction}",
        f"Observer/center: SUN (NAIF {NAIF_SUN}) — heliocentric, not SSB (0)",
        f"Earth target: EARTH (NAIF {NAIF_EARTH}) — body center, not EMB (3)",
        f"Mars target:  MARS BARYCENTER (NAIF {NAIF_MARS_BARYCENTER}) "
        "— system barycenter, not Mars body (499)",
        f"μ_sun: {grid.mu_km3_s2:.6f} km^3/s^2",
        f"Departure: {grid.departure_utc[0]} → {grid.departure_utc[-1]}  "
        f"({grid.n_departure} epochs)",
        f"Arrival:   {grid.arrival_utc[0]} → {grid.arrival_utc[-1]}  "
        f"({grid.n_arrival} epochs)",
        f"Step: {grid.step_days} days    TOF limits: {grid.min_tof_days:g}–"
        f"{grid.max_tof_days:g} days",
        f"Potential cells: {grid.n_potential}",
        f"Valid Lambert solutions: {grid.n_lambert_success}",
        f"Lambert failures: {grid.n_lambert_failed}",
        f"Skipped (TOF/order): {grid.n_skipped_tof}",
        f"Cached Earth states: {grid.earth_states_cached}   "
        f"Mars states: {grid.mars_states_cached}",
        f"Runtime: {grid.runtime_s:.2f} s",
        "C3 is |v∞,Earth|² (km²/s²), not launch ΔV.",
        "",
    ]
    order = (
        "minimum_c3",
        "minimum_earth_vinf",
        "minimum_mars_vinf",
        "shortest_tof",
    )
    for key in order:
        cand = candidates.get(key)
        if cand is None:
            continue
        lines.extend(
            [
                cand.name,
                f"  Departure: {cand.departure_utc}",
                f"  Arrival:   {cand.arrival_utc}",
                f"  TOF: {cand.tof_days:.3f} days",
                f"  C3: {cand.c3_km2_s2:.6f} km²/s²",
                f"  Earth v∞: {cand.earth_vinf_km_s:.6f} km/s",
                f"  Mars v∞:  {cand.mars_vinf_km_s:.6f} km/s",
                "",
            ]
        )
    return "\n".join(lines)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        prog="python -m ares.porkchop",
        description="Earth→Mars porkchop grid from Stage 1/2 Lambert physics.",
    )
    parser.add_argument("--departure-start", default=DEFAULT_DEPARTURE_START)
    parser.add_argument("--departure-end", default=DEFAULT_DEPARTURE_END)
    parser.add_argument("--arrival-start", default=DEFAULT_ARRIVAL_START)
    parser.add_argument("--arrival-end", default=DEFAULT_ARRIVAL_END)
    parser.add_argument("--step-days", type=float, default=DEFAULT_STEP_DAYS)
    parser.add_argument("--min-tof", type=float, default=DEFAULT_MIN_TOF_DAYS)
    parser.add_argument("--max-tof", type=float, default=DEFAULT_MAX_TOF_DAYS)
    parser.add_argument(
        "--max-c3",
        type=float,
        default=None,
        help="Optional C3 filter (km²/s²). Not a launch-vehicle capability.",
    )
    parser.add_argument(
        "--max-mars-vinf",
        type=float,
        default=None,
        help="Optional Mars arrival v∞ filter (km/s). Not MOI ΔV.",
    )
    parser.add_argument(
        "--refine-days",
        type=float,
        default=None,
        help="If set, rebuild a 1-day grid ± this many days around min C3.",
    )
    parser.add_argument(
        "--output",
        default="outputs/earth_mars_2026_porkchop",
        help="Prefix for .csv and .html (no extension)",
    )
    parser.add_argument("--no-plot", action="store_true")
    args = parser.parse_args(argv)

    try:
        load_kernels()
        grid = compute_porkchop(
            args.departure_start,
            args.departure_end,
            args.arrival_start,
            args.arrival_end,
            step_days=args.step_days,
            min_tof_days=args.min_tof,
            max_tof_days=args.max_tof,
        )
        candidates = select_candidates(
            grid, max_c3=args.max_c3, max_mars_vinf=args.max_mars_vinf
        )
    except (KernelError, EphemerisError, TimeScaleError, TrajectoryError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1

    print(format_grid_report(grid, candidates))
    prefix = Path(args.output)
    csv_path = export_csv(grid, prefix.with_suffix(".csv"))
    print(f"Wrote CSV: {csv_path}")
    if not args.no_plot:
        try:
            html_path = plot_porkchop_html(
                grid, prefix.with_suffix(".html"), candidates
            )
            print(f"Wrote plot: {html_path}")
        except TrajectoryError as exc:
            print(f"ERROR: {exc}", file=sys.stderr)
            return 1

    if args.refine_days is not None and "minimum_c3" in candidates:
        refined = refine_around(
            grid, candidates["minimum_c3"], half_width_days=args.refine_days
        )
        refined_cands = select_candidates(
            refined, max_c3=args.max_c3, max_mars_vinf=args.max_mars_vinf
        )
        print("\nRefined 1-day grid around Minimum C3 Candidate")
        print(format_grid_report(refined, refined_cands))
        rprefix = prefix.parent / (prefix.name + "_refined")
        print(f"Wrote CSV: {export_csv(refined, rprefix.with_suffix('.csv'))}")
        if not args.no_plot:
            print(
                f"Wrote plot: {plot_porkchop_html(refined, rprefix.with_suffix('.html'), refined_cands)}"
            )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
