"""Earth → Mars heliocentric two-body Lambert transfer.

Pipeline
    Earth heliocentric state at departure UTC (SPICE, J2000, SUN, NONE)
    Mars heliocentric state at arrival UTC
    Δt = ET_arrival − ET_departure
    Lambert (Izzo 2015, M=0, prograde)
    v∞,Earth = v1_transfer − v_Earth
    v∞,Mars  = v2_transfer − v_Mars
    C3 = |v∞,Earth|²
    two-body DOP853 propagation of (r_Earth, v1_transfer) over Δt
    compare to r_Mars

This is not n-body spacecraft propagation. See docs/PHYSICS.md.
"""

from __future__ import annotations

import argparse
import sys
from dataclasses import dataclass
from pathlib import Path

import numpy as np
from scipy.integrate import solve_ivp

from ares.constants import (
    AU_KM,
    DEFAULT_ABERRATION_CORRECTION,
    DEFAULT_FRAME,
    GM_SUN_KM3_S2,
    NAIF_EARTH,
    NAIF_MARS_BARYCENTER,
    NAIF_SUN,
    SECONDS_PER_DAY,
)
from ares.energetics import ExcessVelocity, excess_velocity
from ares.ephemeris import (
    earth_heliocentric_state,
    load_kernels,
    mars_heliocentric_state,
)
from ares.errors import (
    EphemerisError,
    KernelError,
    LambertError,
    TimeScaleError,
    TrajectoryError,
)
from ares.lambert import LambertSolution, solve_lambert
from ares.time import parse_utc, utc_to_et

# DOP853 (Dormand–Prince 8(7)) via scipy.integrate.solve_ivp.
# rtol=1e-12 on a ~1.5e8 km heliocentric radius is a ~0.15 m local scale.
# atol=1e-9 applies to both km and km/s components of the state.
PROPAGATOR_METHOD = "DOP853"
PROPAGATOR_RTOL = 1e-12
PROPAGATOR_ATOL = 1e-9

# Pass criterion for Lambert endpoint check under the same two-body model.
# Justified in docs/PHYSICS.md / docs/VALIDATION.md: with the integrator
# settings above, truncation should be ≪ 1 km; 1 km is a verification
# ceiling, not a fit.
ENDPOINT_ABS_TOLERANCE_KM = 1.0

# Visualization samples of the same two-body Lambert arc. Not a second orbit model.
DEFAULT_TRAJECTORY_SAMPLES = 201
MAX_TRAJECTORY_SAMPLES = 400


def _two_body_rhs(t: float, y: np.ndarray, mu: float) -> np.ndarray:
    """y = [r(km), v(km/s)]; returns [v, −μ r / |r|³]."""
    del t
    r = y[:3]
    v = y[3:]
    r2 = float(np.dot(r, r))
    if r2 <= 0.0:
        raise TrajectoryError("Two-body propagation reached the origin.")
    r3 = r2 * np.sqrt(r2)
    a = -mu * r / r3
    return np.concatenate([v, a])


@dataclass(frozen=True)
class PropagationCheck:
    """Two-body propagation of the Lambert departure state to the arrival epoch."""

    r_final_km: np.ndarray
    v_final_km_s: np.ndarray
    r_target_km: np.ndarray
    position_error_km: np.ndarray
    position_error_magnitude_km: float
    relative_position_error: float
    method: str
    rtol: float
    atol: float
    within_tolerance: bool
    tolerance_km: float


def propagate_two_body(
    r_km: np.ndarray,
    v_km_s: np.ndarray,
    time_of_flight_s: float,
    mu_km3_s2: float = GM_SUN_KM3_S2,
    *,
    dense: bool = False,
):
    """Numerically integrate the restricted two-body problem about the Sun.

    Input units: r km, v km/s, t seconds, μ km^3/s^2.
    Output: scipy OdeResult; y[:3] is km, y[3:] is km/s.

    Method: scipy.integrate.solve_ivp, DOP853, rtol=1e-12, atol=1e-9.
    """
    r = np.asarray(r_km, dtype=float)
    v = np.asarray(v_km_s, dtype=float)
    if r.shape != (3,) or v.shape != (3,):
        raise TrajectoryError("Propagation state must be two 3-vectors.")
    if not (np.all(np.isfinite(r)) and np.all(np.isfinite(v))):
        raise TrajectoryError("Propagation state contains NaN/Inf.")
    tof = float(time_of_flight_s)
    if not np.isfinite(tof) or tof <= 0.0:
        raise TrajectoryError(
            f"Propagation time of flight must be positive; got {time_of_flight_s!r}."
        )

    y0 = np.concatenate([r, v])
    try:
        solution = solve_ivp(
            _two_body_rhs,
            (0.0, tof),
            y0,
            args=(float(mu_km3_s2),),
            method=PROPAGATOR_METHOD,
            rtol=PROPAGATOR_RTOL,
            atol=PROPAGATOR_ATOL,
            dense_output=dense,
            vectorized=False,
        )
    except TrajectoryError:
        raise
    except Exception as exc:
        raise TrajectoryError(
            f"Two-body integrator raised {type(exc).__name__}: {exc}"
        ) from exc

    if not solution.success:
        raise TrajectoryError(
            "Two-body DOP853 integration failed to complete.\n"
            f"  scipy message: {solution.message}\n"
            f"  Δt s: {tof}"
        )
    y_end = solution.y[:, -1]
    if not np.all(np.isfinite(y_end)):
        raise TrajectoryError("Integrator returned a non-finite terminal state.")
    return solution


def check_lambert_endpoint(
    lambert: LambertSolution,
    r_target_km: np.ndarray,
    *,
    tolerance_km: float = ENDPOINT_ABS_TOLERANCE_KM,
) -> PropagationCheck:
    """Propagate Lambert (r1, v1) for Δt and compare to r_target (km)."""
    solution = propagate_two_body(
        lambert.r_departure_km,
        lambert.v_departure_km_s,
        lambert.time_of_flight_s,
        lambert.mu_km3_s2,
    )
    r_final = np.array(solution.y[:3, -1], dtype=float, copy=True)
    v_final = np.array(solution.y[3:, -1], dtype=float, copy=True)
    target = np.asarray(r_target_km, dtype=float)
    error = r_final - target
    mag = float(np.linalg.norm(error))
    target_mag = float(np.linalg.norm(target))
    relative = mag / target_mag if target_mag > 0.0 else float("inf")
    return PropagationCheck(
        r_final_km=r_final,
        v_final_km_s=v_final,
        r_target_km=np.array(target, dtype=float, copy=True),
        position_error_km=error,
        position_error_magnitude_km=mag,
        relative_position_error=relative,
        method=PROPAGATOR_METHOD,
        rtol=PROPAGATOR_RTOL,
        atol=PROPAGATOR_ATOL,
        within_tolerance=mag <= tolerance_km,
        tolerance_km=tolerance_km,
    )


@dataclass(frozen=True)
class TrajectorySample:
    """One heliocentric two-body state on the Lambert transfer, km / seconds."""

    t_s: float
    et_seconds: float
    x_km: float
    y_km: float
    z_km: float


@dataclass(frozen=True)
class EarthMarsTransfer:
    """One heliocentric two-body Earth→Mars Lambert transfer."""

    departure_utc: str
    arrival_utc: str
    departure_et_s: float
    arrival_et_s: float
    time_of_flight_s: float
    time_of_flight_days: float
    frame: str
    aberration_correction: str
    mu_km3_s2: float
    earth_position_km: np.ndarray
    earth_velocity_km_s: np.ndarray
    mars_position_km: np.ndarray
    mars_velocity_km_s: np.ndarray
    transfer_departure_velocity_km_s: np.ndarray
    transfer_arrival_velocity_km_s: np.ndarray
    transfer_angle_rad: float
    earth_vinf: ExcessVelocity
    mars_vinf: ExcessVelocity
    c3_km2_s2: float
    lambert: LambertSolution
    verification: PropagationCheck
    model: str
    earth_target: str
    earth_target_id: int
    mars_target: str
    mars_target_id: int
    observer: str
    observer_id: int


def lambert_energetics(
    earth_position_km: np.ndarray,
    earth_velocity_km_s: np.ndarray,
    mars_position_km: np.ndarray,
    mars_velocity_km_s: np.ndarray,
    time_of_flight_s: float,
    mu_km3_s2: float = GM_SUN_KM3_S2,
) -> tuple[LambertSolution, ExcessVelocity, ExcessVelocity]:
    """Lambert + v∞/C3 from already-known heliocentric states.

    Used by the single-transfer API and by the porkchop grid so C3 is not
    recomputed with a second formula. Does not propagate the trajectory.
    """
    lambert = solve_lambert(
        earth_position_km,
        mars_position_km,
        time_of_flight_s,
        mu_km3_s2,
        revolutions=0,
        prograde=True,
        low_path=True,
    )
    earth_vinf = excess_velocity(lambert.v_departure_km_s, earth_velocity_km_s)
    mars_vinf = excess_velocity(lambert.v_arrival_km_s, mars_velocity_km_s)
    return lambert, earth_vinf, mars_vinf


def compute_earth_mars_transfer(
    departure_utc: str,
    arrival_utc: str,
    *,
    frame: str = DEFAULT_FRAME,
    aberration_correction: str = DEFAULT_ABERRATION_CORRECTION,
    mu_km3_s2: float = GM_SUN_KM3_S2,
) -> EarthMarsTransfer:
    """Compute one Earth→Mars Lambert transfer and verify it under two-body dynamics."""
    dep_canonical = parse_utc(departure_utc)
    arr_canonical = parse_utc(arrival_utc)
    et0 = utc_to_et(dep_canonical)
    et1 = utc_to_et(arr_canonical)
    tof = et1 - et0
    if not np.isfinite(tof) or tof <= 0.0:
        raise TrajectoryError(
            "Arrival must be strictly after departure on the TDB time scale.\n"
            f"  departure UTC: {dep_canonical}\n"
            f"  arrival UTC  : {arr_canonical}\n"
            f"  ΔET s        : {tof!r}\n"
            "Fix: choose arrival_utc later than departure_utc."
        )

    earth = earth_heliocentric_state(
        dep_canonical, frame=frame, aberration_correction=aberration_correction
    )
    mars = mars_heliocentric_state(
        arr_canonical, frame=frame, aberration_correction=aberration_correction
    )
    if earth.frame != mars.frame:
        raise TrajectoryError(
            f"Earth and Mars frames differ ({earth.frame} vs {mars.frame})."
        )
    if earth.observer_id != mars.observer_id:
        raise TrajectoryError(
            f"Earth and Mars observers differ ({earth.observer_id} vs {mars.observer_id})."
        )
    if earth.target_id != NAIF_EARTH:
        raise TrajectoryError(
            "Earth state is not NAIF 399 (Earth body center). "
            f"Got {earth.target} / {earth.target_id}. "
            "Do not silently substitute Earth-Moon barycenter (3)."
        )
    if mars.target_id != NAIF_MARS_BARYCENTER:
        raise TrajectoryError(
            "Mars state is not NAIF 4 (Mars system barycenter). "
            f"Got {mars.target} / {mars.target_id}. "
            "de440s.bsp does not provide Mars body 499; do not invent it."
        )
    if earth.observer_id != NAIF_SUN:
        raise TrajectoryError(
            "Heliocentric Lambert requires observer SUN (NAIF 10), "
            f"not {earth.observer} / {earth.observer_id}."
        )

    try:
        lambert, earth_vinf, mars_vinf = lambert_energetics(
            earth.position_km,
            earth.velocity_km_s,
            mars.position_km,
            mars.velocity_km_s,
            tof,
            mu_km3_s2,
        )
    except LambertError as exc:
        raise TrajectoryError(
            "Lambert solver could not construct an Earth→Mars transfer "
            f"from {dep_canonical} to {arr_canonical}.\n{exc}"
        ) from exc
    verification = check_lambert_endpoint(lambert, mars.position_km)

    return EarthMarsTransfer(
        departure_utc=dep_canonical,
        arrival_utc=arr_canonical,
        departure_et_s=et0,
        arrival_et_s=et1,
        time_of_flight_s=tof,
        time_of_flight_days=tof / SECONDS_PER_DAY,
        frame=earth.frame,
        aberration_correction=earth.aberration_correction,
        mu_km3_s2=mu_km3_s2,
        earth_position_km=earth.position_km,
        earth_velocity_km_s=earth.velocity_km_s,
        mars_position_km=mars.position_km,
        mars_velocity_km_s=mars.velocity_km_s,
        transfer_departure_velocity_km_s=lambert.v_departure_km_s,
        transfer_arrival_velocity_km_s=lambert.v_arrival_km_s,
        transfer_angle_rad=lambert.transfer_angle_rad,
        earth_vinf=earth_vinf,
        mars_vinf=mars_vinf,
        c3_km2_s2=earth_vinf.c3_km2_s2,
        lambert=lambert,
        verification=verification,
        model=(
            "Heliocentric two-body Lambert transfer (Sun as sole gravity; "
            "SPICE planetary states; Izzo 2015, M=0, prograde). "
            "Earth endpoint is body center NAIF 399, not Earth-Moon barycenter 3. "
            "Mars endpoint is system barycenter NAIF 4, not Mars body 499. "
            "Observer is SUN NAIF 10, not SSB 0. "
            "Not an n-body spacecraft trajectory."
        ),
        earth_target=earth.target,
        earth_target_id=earth.target_id,
        mars_target=mars.target,
        mars_target_id=mars.target_id,
        observer=earth.observer,
        observer_id=earth.observer_id,
    )


def sample_transfer_points(
    transfer: EarthMarsTransfer,
    n_points: int = DEFAULT_TRAJECTORY_SAMPLES,
) -> list[TrajectorySample]:
    """Sample the verified two-body Lambert arc. Not a Bezier or decorative curve.

    Uses ``propagate_two_body`` (DOP853) with dense output on (r_Earth, v1).
    """
    n = int(n_points)
    if n < 2 or n > MAX_TRAJECTORY_SAMPLES:
        raise TrajectoryError(
            f"n_points must be in [2, {MAX_TRAJECTORY_SAMPLES}]; got {n_points!r}."
        )
    solution = propagate_two_body(
        transfer.lambert.r_departure_km,
        transfer.lambert.v_departure_km_s,
        transfer.time_of_flight_s,
        transfer.mu_km3_s2,
        dense=True,
    )
    times = np.linspace(0.0, transfer.time_of_flight_s, n)
    states = solution.sol(times)
    samples: list[TrajectorySample] = []
    for i in range(n):
        samples.append(
            TrajectorySample(
                t_s=float(times[i]),
                et_seconds=float(transfer.departure_et_s + times[i]),
                x_km=float(states[0, i]),
                y_km=float(states[1, i]),
                z_km=float(states[2, i]),
            )
        )
    return samples


def format_transfer_report(transfer: EarthMarsTransfer) -> str:
    """Concise labelled CLI report. Numbers are computed, not hardcoded."""
    v = transfer.verification
    angle_deg = transfer.transfer_angle_rad * 180.0 / np.pi
    status = "PASS" if v.within_tolerance else "FAIL"
    lines = [
        "ARES Earth → Mars Transfer",
        "",
        f"Departure: {transfer.departure_utc}",
        f"Arrival:   {transfer.arrival_utc}",
        f"Time of flight: {transfer.time_of_flight_days:.6f} days  "
        f"({transfer.time_of_flight_s:.6f} s, SI 86400-s day)",
        f"Transfer angle: {transfer.transfer_angle_rad:.6f} rad  ({angle_deg:.3f} deg)",
        f"Frame: {transfer.frame}   Aberration: {transfer.aberration_correction}",
        f"Observer/center: {transfer.observer} (NAIF {transfer.observer_id}) "
        "— Sun, heliocentric, not solar-system barycenter (0)",
        f"Earth target: {transfer.earth_target} (NAIF {transfer.earth_target_id}) "
        "— body center / geocenter, not Earth-Moon barycenter (3)",
        f"Mars target:  {transfer.mars_target} (NAIF {transfer.mars_target_id}) "
        "— system barycenter, not Mars body center (499)",
        f"μ_sun: {transfer.mu_km3_s2:.6f} km^3/s^2  (DE440 / Park et al. 2021)",
        "",
        f"Earth departure v∞: {transfer.earth_vinf.magnitude_km_s:.9f} km/s",
        f"  vector km/s: {np.array2string(transfer.earth_vinf.vector_km_s, precision=10)}",
        f"Mars arrival v∞:    {transfer.mars_vinf.magnitude_km_s:.9f} km/s",
        f"  vector km/s: {np.array2string(transfer.mars_vinf.vector_km_s, precision=10)}",
        f"C3: {transfer.c3_km2_s2:.9f} km^2/s^2   (= |v∞,Earth|^2, not ΔV)",
        "",
        f"Lambert target error: {v.position_error_magnitude_km:.6e} km  "
        f"(relative {v.relative_position_error:.3e}, "
        f"tol {v.tolerance_km} km, {status})",
        f"  propagator: {v.method}  rtol={v.rtol}  atol={v.atol}  "
        f"(two-body, μ_sun)",
        "",
        "MODEL:",
        transfer.model,
        "Neglected: planetary perturbations, finite burns, spacecraft mass,",
        "TCMs, SRP, non-spherical gravity, launch-site geometry, atmosphere.",
        f"Solver: {transfer.lambert.solver}  {transfer.lambert.solver_reference}",
    ]
    return "\n".join(lines)


def plot_transfer(transfer: EarthMarsTransfer, path: Path) -> Path:
    """Simple heliocentric inspection plot (Sun, Earth, Mars, transfer)."""
    try:
        import matplotlib

        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
    except ImportError as exc:
        raise TrajectoryError(
            "matplotlib is not installed. From the repository root run:\n"
            '  python -m pip install -e ".[plot]"\n'
            "then retry --plot."
        ) from exc

    sol = propagate_two_body(
        transfer.lambert.r_departure_km,
        transfer.lambert.v_departure_km_s,
        transfer.time_of_flight_s,
        transfer.mu_km3_s2,
        dense=True,
    )
    n = 400
    t = np.linspace(0.0, transfer.time_of_flight_s, n)
    y = sol.sol(t)
    au = AU_KM

    fig, ax = plt.subplots(figsize=(7.5, 7.0))
    ax.plot(y[0] / au, y[1] / au, color="0.2", lw=1.2, label="Lambert transfer")
    ax.scatter([0.0], [0.0], c="C1", s=40, zorder=5, label="Sun")
    ax.scatter(
        [transfer.earth_position_km[0] / au],
        [transfer.earth_position_km[1] / au],
        c="C0",
        s=28,
        zorder=5,
        label="Earth departure",
    )
    ax.scatter(
        [transfer.mars_position_km[0] / au],
        [transfer.mars_position_km[1] / au],
        c="C3",
        s=28,
        zorder=5,
        label="Mars arrival",
    )
    ax.set_aspect("equal", adjustable="box")
    ax.set_xlabel("X [au]  (J2000, heliocentric)")
    ax.set_ylabel("Y [au]  (J2000, heliocentric)")
    ax.set_title(
        "ARES two-body Lambert transfer (XY projection)\n"
        f"{transfer.departure_utc} → {transfer.arrival_utc}"
    )
    ax.grid(True, alpha=0.3)
    ax.legend(loc="best", fontsize=8)
    fig.tight_layout()
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(path, dpi=140)
    plt.close(fig)
    return path


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        prog="python -m ares.trajectory",
        description=(
            "Earth→Mars heliocentric two-body Lambert transfer "
            "(SPICE states + Izzo 2015)."
        ),
    )
    parser.add_argument(
        "--departure",
        required=True,
        help='UTC, ISO-8601, e.g. "2026-10-31T00:00:00"',
    )
    parser.add_argument(
        "--arrival",
        required=True,
        help='UTC, ISO-8601, e.g. "2027-09-07T00:00:00"',
    )
    parser.add_argument(
        "--frame",
        default=DEFAULT_FRAME,
        help=f"SPICE inertial frame (default {DEFAULT_FRAME})",
    )
    parser.add_argument(
        "--plot",
        default=None,
        help="Optional PNG path for a simple XY inspection plot",
    )
    args = parser.parse_args(argv)

    try:
        load_kernels()
        transfer = compute_earth_mars_transfer(
            args.departure, args.arrival, frame=args.frame
        )
    except (KernelError, EphemerisError, LambertError, TimeScaleError, TrajectoryError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1

    print(format_transfer_report(transfer))
    if args.plot:
        try:
            out = plot_transfer(transfer, Path(args.plot))
        except TrajectoryError as exc:
            print(f"ERROR: {exc}", file=sys.stderr)
            return 1
        print(f"\nWrote plot: {out}")
    if not transfer.verification.within_tolerance:
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
