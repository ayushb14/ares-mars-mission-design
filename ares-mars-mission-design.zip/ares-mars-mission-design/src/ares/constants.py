"""Verified constants, NAIF body IDs, and Stage 1 defaults.

Only values with an identified authoritative source are stored here.
Anything not listed must not be invented and used in calculations.

Internal units (project convention):
    distance : km
    velocity : km/s
    time     : seconds
    angles   : radians (Lambert transfer angle in Stage 2)
    mass     : kg (none used in Stage 1)
"""

from __future__ import annotations

# ---------------------------------------------------------------------------
# IAU / SI defining constants
# ---------------------------------------------------------------------------

# IAU 2012 Resolution B2: the astronomical unit is 149 597 870 700 m exactly.
# In internal units that is 149 597 870.7 km exactly.
# Source: IAU 2012 Resolution B2; see docs/SOURCES.md.
AU_M: float = 149_597_870_700.0
AU_KM: float = AU_M / 1000.0

# SI 2019: speed of light in vacuum is 299 792 458 m/s exactly.
# Source: BIPM SI Brochure; see docs/SOURCES.md.
SPEED_OF_LIGHT_M_S: float = 299_792_458.0
SPEED_OF_LIGHT_KM_S: float = SPEED_OF_LIGHT_M_S / 1000.0

# IAU definition of Terrestrial Time: TT = TAI + 32.184 s (exact).
# Source: IAU 1976 / IERS conventions; used by NAIF LSK DELTET/DELTA_T_A.
TT_MINUS_TAI_S: float = 32.184

# SI second-count of one day (IAU/SI day). Used only to *label* TOF in days.
# Source: SI Brochure; 1 d = 86400 s exactly.
SECONDS_PER_DAY: float = 86400.0

# Solar gravitational parameter from JPL DE440, in ARES internal units.
# Park et al. (2021), The Astronomical Journal 161:105, Table 2:
#   GM_Sun = 132712440041.279419 km^3 s^-2  (estimated from DE440)
# Same value appears as GMS in NAIF de440_tech-comments.txt (KM**3/SEC**2)
# and as BODY10_GM in NAIF gm_de440.tpc (1.3271244004127942E+11 km^3/s^2).
# See docs/SOURCES.md.
GM_SUN_KM3_S2: float = 132712440041.279419

# ---------------------------------------------------------------------------
# NAIF integer IDs
# From NAIF IDs Required Reading and the DE440s SPK summary.
# https://naif.jpl.nasa.gov/pub/naif/toolkit_docs/C/req/naif_ids.html
# https://naif.jpl.nasa.gov/pub/naif/generic_kernels/spk/planets/aa_summaries.txt
# ---------------------------------------------------------------------------

NAIF_SOLAR_SYSTEM_BARYCENTER: int = 0
NAIF_EARTH_BARYCENTER: int = 3  # Earth-Moon barycenter
NAIF_MARS_BARYCENTER: int = 4
NAIF_SUN: int = 10
NAIF_MOON: int = 301
NAIF_EARTH: int = 399  # Earth geocenter / Earth body center
NAIF_MARS: int = 499  # Mars body center — NOT present in de440s.bsp

BODY_EARTH: str = "EARTH"
BODY_MARS_BARYCENTER: str = "MARS BARYCENTER"
BODY_SUN: str = "SUN"

# ---------------------------------------------------------------------------
# Stage 1 default geometry request
# ---------------------------------------------------------------------------

# SPICE frame name. DE440 is aligned to the ICRF (Park et al. 2021).
# ARES requests the SPICE built-in inertial frame "J2000" and does not apply
# an additional J2000↔ICRF rotation. See docs/PHYSICS.md.
DEFAULT_FRAME: str = "J2000"

# Geometric state: no light-time and no stellar aberration.
# NAIF SPKEZR abcorr value "NONE". See SPKEZR and abcorr.req.
DEFAULT_ABERRATION_CORRECTION: str = "NONE"

DEFAULT_OBSERVER: str = BODY_SUN

# Identity of the validated physics engine (API/health/UI metadata).
ENGINE_NAME: str = "ARES"
PHYSICS_MODEL: str = "heliocentric two-body Lambert"

# Default mission-design civil dates: NASA/TM-2010-216764 Table 2 Type II
# pair. These are example parameters, not an ARES-claimed optimum.
DEFAULT_MISSION_DEPARTURE_UTC: str = "2026-10-31T00:00:00"
DEFAULT_MISSION_ARRIVAL_UTC: str = "2027-08-19T00:00:00"


def engine_identity() -> dict[str, object]:
    """Canonical engine/frame/target metadata. One source for API and CLI."""
    import ares

    return {
        "engine": ENGINE_NAME,
        "version": ares.__version__,
        "physics_model": PHYSICS_MODEL,
        "frame": DEFAULT_FRAME,
        "earth_target": NAIF_EARTH,
        "earth_target_name": BODY_EARTH,
        "mars_target": NAIF_MARS_BARYCENTER,
        "mars_target_name": BODY_MARS_BARYCENTER,
        "observer": NAIF_SUN,
        "observer_name": DEFAULT_OBSERVER,
        "aberration_correction": DEFAULT_ABERRATION_CORRECTION,
    }

# Frames that Stage 1 will request. Body-fixed frames are not supported:
# they require a PCK that Stage 1 does not load.
SUPPORTED_INERTIAL_FRAMES: frozenset[str] = frozenset({"J2000", "ECLIPJ2000"})

# Aberration flags Stage 1 will pass through to SPKEZR.
# Geometric ("NONE") is the default for mission-design states.
SUPPORTED_ABERRATION_CORRECTIONS: frozenset[str] = frozenset(
    {
        "NONE",
        "LT",
        "LT+S",
        "CN",
        "CN+S",
        "XLT",
        "XLT+S",
        "XCN",
        "XCN+S",
    }
)

# ---------------------------------------------------------------------------
# Official Stage 1 kernels (NASA/JPL NAIF generic kernels)
# ---------------------------------------------------------------------------

NAIF_GENERIC_KERNEL_BASE: str = "https://naif.jpl.nasa.gov/pub/naif/generic_kernels"

LSK_FILENAME: str = "naif0012.tls"
LSK_WINDOWS_FILENAME: str = "naif0012.tls.pc"
SPK_FILENAME: str = "de440s.bsp"

# MD5 published by NAIF in:
# https://naif.jpl.nasa.gov/pub/naif/generic_kernels/spk/planets/aa_checksums.txt
DE440S_MD5: str = "3917ee56769db332790c751e2168843d"

# Coverage from NAIF aa_summaries.txt for de440s.bsp (ET calendar labels).
DE440S_COVERAGE_BEGIN_ET_LABEL: str = "1849 DEC 26 00:00:00.000"
DE440S_COVERAGE_END_ET_LABEL: str = "2150 JAN 22 00:00:00.000"

# ---------------------------------------------------------------------------
# NSSDCA planetary fact-sheet heliocentric distances / speeds
# Used ONLY as physically-meaningful sanity envelopes in tests, not as
# ephemeris values. See docs/SOURCES.md.
# ---------------------------------------------------------------------------

# Earth Fact Sheet orbital parameters, perihelion/aphelion in 10^6 km.
NSSDCA_EARTH_PERIHELION_KM: float = 147.095e6
NSSDCA_EARTH_APHELION_KM: float = 152.100e6
NSSDCA_EARTH_MIN_ORBITAL_VELOCITY_KM_S: float = 29.29
NSSDCA_EARTH_MAX_ORBITAL_VELOCITY_KM_S: float = 30.29

# Mars Fact Sheet orbital parameters, perihelion/aphelion in 10^6 km.
NSSDCA_MARS_PERIHELION_KM: float = 206.650e6
NSSDCA_MARS_APHELION_KM: float = 249.261e6
NSSDCA_MARS_MIN_ORBITAL_VELOCITY_KM_S: float = 21.97
NSSDCA_MARS_MAX_ORBITAL_VELOCITY_KM_S: float = 26.50

# Plausibility envelope applied around the fact-sheet extrema.
# Fact sheets are rounded; DE440 is an N-body ephemeris, so instantaneous
# heliocentric distance/speed can differ slightly from two-body extrema.
# This margin is a test envelope, not a physical constant.
SANITY_ENVELOPE_FRACTION: float = 0.02
