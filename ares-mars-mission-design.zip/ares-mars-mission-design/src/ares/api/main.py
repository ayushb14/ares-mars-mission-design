"""ARES FastAPI application. Presentation only; physics lives in `src/ares/`."""

from __future__ import annotations

from contextlib import asynccontextmanager

import logging

from fastapi import FastAPI, Request
from fastapi.exceptions import RequestValidationError
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from starlette.exceptions import HTTPException as StarletteHTTPException

from ares.api.models import ReferenceCaseResponse
from ares.api.routes import health as health_routes
from ares.api.routes import porkchop as porkchop_routes
from ares.api.routes import trajectory as trajectory_routes
from ares.api.serialize import trajectory_to_response
from ares.constants import (
    DEFAULT_MISSION_ARRIVAL_UTC,
    DEFAULT_MISSION_DEPARTURE_UTC,
    engine_identity,
)
from ares.ephemeris import load_kernels
from ares.errors import (
    AresError,
    EphemerisError,
    KernelError,
    LambertError,
    TimeScaleError,
    TrajectoryError,
)
from ares.trajectory import DEFAULT_TRAJECTORY_SAMPLES, compute_earth_mars_transfer

_LOG = logging.getLogger("ares.api")


@asynccontextmanager
async def lifespan(_app: FastAPI):
    try:
        load_kernels()
    except KernelError:
        # Health/trajectory handlers report this; do not crash the process.
        pass
    yield


def create_app() -> FastAPI:
    meta = engine_identity()
    application = FastAPI(
        title="ARES Mission Design API",
        description=(
            "Local HTTP facade over the validated ARES Python physics engine "
            "(SPICE ephemerides, heliocentric two-body Lambert, porkchop grids). "
            "This API does not re-implement orbital equations."
        ),
        version=str(meta["version"]),
        lifespan=lifespan,
    )
    application.add_middleware(
        CORSMiddleware,
        allow_origins=[
            "http://127.0.0.1:4177",
            "http://localhost:4177",
            "http://127.0.0.1:5173",
            "http://localhost:5173",
        ],
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )
    application.include_router(health_routes.router, prefix="/api", tags=["health"])
    application.include_router(
        trajectory_routes.router, prefix="/api", tags=["trajectory"]
    )
    application.include_router(
        porkchop_routes.router, prefix="/api", tags=["porkchop"]
    )

    @application.get("/api/reference-case", response_model=ReferenceCaseResponse)
    def reference_case() -> ReferenceCaseResponse:
        """NASA/TM-2010-216764 Table 2 Type II civil dates, computed by ARES."""
        load_kernels()
        transfer = compute_earth_mars_transfer(
            DEFAULT_MISSION_DEPARTURE_UTC, DEFAULT_MISSION_ARRIVAL_UTC
        )
        return ReferenceCaseResponse(
            label=(
                "NASA/TM-2010-216764 Table 2 Type II civil dates, "
                "evaluated by ARES (not a NASA result)"
            ),
            departure=DEFAULT_MISSION_DEPARTURE_UTC,
            arrival=DEFAULT_MISSION_ARRIVAL_UTC,
            nasa_published_c3_km2_s2=9.144,
            nasa_source="NASA/TM-2010-216764 Table 2, Type II ballistic energy minimum",
            note=(
                "ARES uses heliocentric two-body Lambert on DE440 geometric states. "
                "Exact equality with MIDAS/patched-conic NASA products is not expected. "
                "Compared against published NASA mission-design data; not NASA-certified."
            ),
            transfer=trajectory_to_response(transfer, DEFAULT_TRAJECTORY_SAMPLES),
        )

    @application.exception_handler(TimeScaleError)
    async def _time_error(_request: Request, exc: TimeScaleError) -> JSONResponse:
        return JSONResponse(status_code=400, content={"error": "time_scale", "detail": str(exc)})

    @application.exception_handler(TrajectoryError)
    async def _traj_error(_request: Request, exc: TrajectoryError) -> JSONResponse:
        return JSONResponse(status_code=400, content={"error": "trajectory", "detail": str(exc)})

    @application.exception_handler(LambertError)
    async def _lambert_error(_request: Request, exc: LambertError) -> JSONResponse:
        return JSONResponse(status_code=422, content={"error": "lambert", "detail": str(exc)})

    @application.exception_handler(KernelError)
    async def _kernel_error(_request: Request, exc: KernelError) -> JSONResponse:
        return JSONResponse(
            status_code=503,
            content={"error": "kernels", "detail": str(exc)},
        )

    @application.exception_handler(EphemerisError)
    async def _eph_error(_request: Request, exc: EphemerisError) -> JSONResponse:
        return JSONResponse(status_code=503, content={"error": "ephemeris", "detail": str(exc)})

    @application.exception_handler(AresError)
    async def _ares_error(_request: Request, exc: AresError) -> JSONResponse:
        return JSONResponse(status_code=400, content={"error": "ares", "detail": str(exc)})

    @application.exception_handler(Exception)
    async def _unhandled(_request: Request, exc: Exception) -> JSONResponse:
        if isinstance(exc, (StarletteHTTPException, RequestValidationError)):
            raise exc
        _LOG.exception("Unhandled API error")
        return JSONResponse(
            status_code=500,
            content={
                "error": "internal",
                "detail": "ARES physics engine unavailable.",
            },
        )

    return application


app = create_app()
