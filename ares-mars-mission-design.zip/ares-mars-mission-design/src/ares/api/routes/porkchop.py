"""POST /api/porkchop — wraps `compute_porkchop` / `select_candidates`."""

from __future__ import annotations

from fastapi import APIRouter

from ares.api.models import PorkchopRequest, PorkchopResponse
from ares.api.serialize import porkchop_to_response
from ares.ephemeris import load_kernels
from ares.porkchop import compute_porkchop

router = APIRouter()


@router.post("/porkchop", response_model=PorkchopResponse)
def post_porkchop(body: PorkchopRequest) -> PorkchopResponse:
    load_kernels()
    grid = compute_porkchop(
        body.departure_start,
        body.departure_end,
        body.arrival_start,
        body.arrival_end,
        step_days=body.step_days,
        min_tof_days=body.min_tof_days,
        max_tof_days=body.max_tof_days,
    )
    return porkchop_to_response(
        grid, max_c3=body.max_c3, max_mars_vinf=body.max_mars_vinf
    )
