"""GET /api/health — engine identity from `ares.constants.engine_identity`."""

from __future__ import annotations

from fastapi import APIRouter

from ares.api.models import HealthResponse
from ares.constants import engine_identity
from ares.ephemeris import load_kernels
from ares.errors import KernelError
from ares.porkchop import MAX_PORKCHOP_CELLS

router = APIRouter()


@router.get("/health", response_model=HealthResponse)
def health() -> HealthResponse:
    meta = engine_identity()
    kernel_detail: str | None = None
    loaded = True
    try:
        load_kernels()
    except KernelError as exc:
        loaded = False
        kernel_detail = str(exc)
    return HealthResponse(
        status="ok" if loaded else "kernels_missing",
        engine=str(meta["engine"]),
        version=str(meta["version"]),
        physics_model=str(meta["physics_model"]),
        frame=str(meta["frame"]),
        earth_target=int(meta["earth_target"]),  # type: ignore[arg-type]
        earth_target_name=str(meta["earth_target_name"]),
        mars_target=int(meta["mars_target"]),  # type: ignore[arg-type]
        mars_target_name=str(meta["mars_target_name"]),
        observer=int(meta["observer"]),  # type: ignore[arg-type]
        observer_name=str(meta["observer_name"]),
        aberration_correction=str(meta["aberration_correction"]),
        kernels_loaded=loaded,
        kernel_detail=kernel_detail,
        max_porkchop_cells=MAX_PORKCHOP_CELLS,
    )
