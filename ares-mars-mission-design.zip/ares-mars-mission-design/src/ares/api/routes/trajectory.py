"""POST /api/trajectory — wraps `compute_earth_mars_transfer`."""

from __future__ import annotations

from fastapi import APIRouter

from ares.api.models import TrajectoryRequest, TrajectoryResponse
from ares.api.serialize import trajectory_to_response
from ares.ephemeris import load_kernels
from ares.trajectory import compute_earth_mars_transfer

router = APIRouter()


@router.post("/trajectory", response_model=TrajectoryResponse)
def post_trajectory(body: TrajectoryRequest) -> TrajectoryResponse:
    load_kernels()
    transfer = compute_earth_mars_transfer(body.departure, body.arrival)
    return trajectory_to_response(transfer, body.n_points)
