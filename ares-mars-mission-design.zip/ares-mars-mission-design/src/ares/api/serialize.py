"""Serialize Stage 2/3 engine objects to API models. No physics here."""

from __future__ import annotations

import numpy as np

from ares.api.models import (
    BodyState,
    PorkchopCandidateModel,
    PorkchopResponse,
    TrajectoryPoint,
    TrajectoryResponse,
)
from ares.constants import (
    NAIF_EARTH,
    NAIF_MARS_BARYCENTER,
    NAIF_SUN,
    PHYSICS_MODEL,
)
from ares.porkchop import STATUS_LABEL, MAX_PORKCHOP_CELLS, PorkchopGrid, select_candidates
from ares.trajectory import (
    EarthMarsTransfer,
    sample_transfer_points,
)


def _vec(arr: np.ndarray) -> list[float]:
    return [float(arr[0]), float(arr[1]), float(arr[2])]


def _grid_floats(values: np.ndarray, valid: np.ndarray) -> list[list[float | None]]:
    out: list[list[float | None]] = []
    n_i, n_j = values.shape
    for i in range(n_i):
        row: list[float | None] = []
        for j in range(n_j):
            if not bool(valid[i, j]) or not np.isfinite(values[i, j]):
                row.append(None)
            else:
                row.append(float(values[i, j]))
        out.append(row)
    return out


def trajectory_to_response(
    transfer: EarthMarsTransfer, n_points: int
) -> TrajectoryResponse:
    samples = sample_transfer_points(transfer, n_points)
    return TrajectoryResponse(
        departure=transfer.departure_utc,
        arrival=transfer.arrival_utc,
        time_of_flight_days=float(transfer.time_of_flight_days),
        time_of_flight_s=float(transfer.time_of_flight_s),
        c3_km2_s2=float(transfer.c3_km2_s2),
        earth_vinf_km_s=float(transfer.earth_vinf.magnitude_km_s),
        mars_vinf_km_s=float(transfer.mars_vinf.magnitude_km_s),
        earth_vinf_vector_km_s=_vec(transfer.earth_vinf.vector_km_s),
        mars_vinf_vector_km_s=_vec(transfer.mars_vinf.vector_km_s),
        transfer_departure_velocity_km_s=_vec(transfer.transfer_departure_velocity_km_s),
        transfer_arrival_velocity_km_s=_vec(transfer.transfer_arrival_velocity_km_s),
        transfer_angle_rad=float(transfer.transfer_angle_rad),
        earth=BodyState(
            target=transfer.earth_target,
            target_id=transfer.earth_target_id,
            meaning="Earth body center / geocenter, not Earth-Moon barycenter (3)",
            utc=transfer.departure_utc,
            et_seconds=float(transfer.departure_et_s),
            position_km=_vec(transfer.earth_position_km),
            velocity_km_s=_vec(transfer.earth_velocity_km_s),
        ),
        mars=BodyState(
            target=transfer.mars_target,
            target_id=transfer.mars_target_id,
            meaning="Mars system barycenter, not Mars body center (499)",
            utc=transfer.arrival_utc,
            et_seconds=float(transfer.arrival_et_s),
            position_km=_vec(transfer.mars_position_km),
            velocity_km_s=_vec(transfer.mars_velocity_km_s),
        ),
        trajectory_points=[
            TrajectoryPoint(
                t_s=p.t_s,
                et_seconds=p.et_seconds,
                x_km=p.x_km,
                y_km=p.y_km,
                z_km=p.z_km,
            )
            for p in samples
        ],
        verification_position_error_km=float(
            transfer.verification.position_error_magnitude_km
        ),
        verification_within_tolerance=bool(transfer.verification.within_tolerance),
        model=transfer.model,
        frame=transfer.frame,
        aberration_correction=transfer.aberration_correction,
        observer=transfer.observer,
        observer_id=transfer.observer_id,
        earth_target=transfer.earth_target,
        earth_target_id=transfer.earth_target_id,
        mars_target=transfer.mars_target,
        mars_target_id=transfer.mars_target_id,
        mu_km3_s2=float(transfer.mu_km3_s2),
    )


def porkchop_to_response(
    grid: PorkchopGrid,
    *,
    max_c3: float | None = None,
    max_mars_vinf: float | None = None,
) -> PorkchopResponse:
    found = select_candidates(grid, max_c3=max_c3, max_mars_vinf=max_mars_vinf)
    candidates = {
        key: PorkchopCandidateModel(
            name=cand.name,
            key=key,
            departure_utc=cand.departure_utc,
            arrival_utc=cand.arrival_utc,
            tof_days=cand.tof_days,
            c3_km2_s2=cand.c3_km2_s2,
            earth_vinf_km_s=cand.earth_vinf_km_s,
            mars_vinf_km_s=cand.mars_vinf_km_s,
            departure_index=cand.departure_index,
            arrival_index=cand.arrival_index,
        )
        for key, cand in found.items()
    }
    status = [
        [STATUS_LABEL.get(int(grid.status[i, j]), "unknown") for j in range(grid.n_arrival)]
        for i in range(grid.n_departure)
    ]
    return PorkchopResponse(
        departure_utc=grid.departure_utc,
        arrival_utc=grid.arrival_utc,
        tof_days=_grid_floats(grid.tof_days, grid.valid),
        c3_km2_s2=_grid_floats(grid.c3_km2_s2, grid.valid),
        earth_vinf_km_s=_grid_floats(grid.earth_vinf_km_s, grid.valid),
        mars_vinf_km_s=_grid_floats(grid.mars_vinf_km_s, grid.valid),
        valid=grid.valid.astype(bool).tolist(),
        status=status,
        n_departure=grid.n_departure,
        n_arrival=grid.n_arrival,
        n_potential=grid.n_potential,
        n_lambert_success=grid.n_lambert_success,
        n_lambert_failed=grid.n_lambert_failed,
        n_skipped_tof=grid.n_skipped_tof,
        runtime_s=float(grid.runtime_s),
        step_days=float(grid.step_days),
        min_tof_days=float(grid.min_tof_days),
        max_tof_days=float(grid.max_tof_days),
        max_cells=MAX_PORKCHOP_CELLS,
        frame=grid.frame,
        aberration_correction=grid.aberration_correction,
        earth_target_id=NAIF_EARTH,
        mars_target_id=NAIF_MARS_BARYCENTER,
        observer_id=NAIF_SUN,
        mu_km3_s2=float(grid.mu_km3_s2),
        candidates=candidates,
        model=PHYSICS_MODEL,
    )
