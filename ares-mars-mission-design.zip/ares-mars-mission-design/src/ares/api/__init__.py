"""FastAPI presentation layer over the validated ARES physics engine.

This package serializes Stage 1–3 results. It does not re-implement Lambert,
C3, SPICE, or time conversion.
"""
