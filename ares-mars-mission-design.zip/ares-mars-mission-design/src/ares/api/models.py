"""Pydantic request/response models. Physics values are filled from `src/ares/`."""

from __future__ import annotations

from typing import Any

from pydantic import BaseModel, Field, field_validator, model_validator

from ares.constants import (
    DEFAULT_MISSION_ARRIVAL_UTC,
    DEFAULT_MISSION_DEPARTURE_UTC,
)
from ares.porkchop import (
    DEFAULT_ARRIVAL_END,
    DEFAULT_ARRIVAL_START,
    DEFAULT_DEPARTURE_END,
    DEFAULT_DEPARTURE_START,
    DEFAULT_MAX_TOF_DAYS,
    DEFAULT_MIN_TOF_DAYS,
    DEFAULT_STEP_DAYS,
    MAX_PORKCHOP_CELLS,
)
from ares.trajectory import DEFAULT_TRAJECTORY_SAMPLES, MAX_TRAJECTORY_SAMPLES


class Vec3(BaseModel):
    x_km: float | None = None
    y_km: float | None = None
    z_km: float | None = None
    vx_km_s: float | None = None
    vy_km_s: float | None = None
    vz_km_s: float | None = None


class TrajectoryRequest(BaseModel):
    departure: str = Field(
        default=DEFAULT_MISSION_DEPARTURE_UTC,
        description="Earth departure UTC (ISO-8601).",
        examples=[DEFAULT_MISSION_DEPARTURE_UTC],
    )
    arrival: str = Field(
        default=DEFAULT_MISSION_ARRIVAL_UTC,
        description="Mars arrival UTC (ISO-8601).",
        examples=[DEFAULT_MISSION_ARRIVAL_UTC],
    )
    n_points: int = Field(
        default=DEFAULT_TRAJECTORY_SAMPLES,
        ge=2,
        le=MAX_TRAJECTORY_SAMPLES,
        description="Two-body sample count along the Lambert arc.",
    )


class TrajectoryPoint(BaseModel):
    t_s: float
    et_seconds: float
    x_km: float
    y_km: float
    z_km: float


class BodyState(BaseModel):
    target: str
    target_id: int
    meaning: str
    utc: str
    et_seconds: float
    position_km: list[float]
    velocity_km_s: list[float]


class TrajectoryResponse(BaseModel):
    departure: str
    arrival: str
    time_of_flight_days: float
    time_of_flight_s: float
    c3_km2_s2: float
    earth_vinf_km_s: float
    mars_vinf_km_s: float
    earth_vinf_vector_km_s: list[float]
    mars_vinf_vector_km_s: list[float]
    transfer_departure_velocity_km_s: list[float]
    transfer_arrival_velocity_km_s: list[float]
    transfer_angle_rad: float
    earth: BodyState
    mars: BodyState
    trajectory_points: list[TrajectoryPoint]
    verification_position_error_km: float
    verification_within_tolerance: bool
    model: str
    frame: str
    aberration_correction: str
    observer: str
    observer_id: int
    earth_target: str
    earth_target_id: int
    mars_target: str
    mars_target_id: int
    mu_km3_s2: float


class PorkchopRequest(BaseModel):
    departure_start: str = Field(default=DEFAULT_DEPARTURE_START)
    departure_end: str = Field(default=DEFAULT_DEPARTURE_END)
    arrival_start: str = Field(default=DEFAULT_ARRIVAL_START)
    arrival_end: str = Field(default=DEFAULT_ARRIVAL_END)
    step_days: float = Field(default=DEFAULT_STEP_DAYS, gt=0.0, le=60.0)
    min_tof_days: float = Field(default=DEFAULT_MIN_TOF_DAYS, ge=0.0)
    max_tof_days: float = Field(default=DEFAULT_MAX_TOF_DAYS, gt=0.0)
    max_c3: float | None = Field(default=None, description="Optional C3 filter, km²/s².")
    max_mars_vinf: float | None = Field(
        default=None, description="Optional Mars arrival v∞ filter, km/s."
    )

    @field_validator("step_days")
    @classmethod
    def _finite_step(cls, value: float) -> float:
        if value != value:  # NaN
            raise ValueError("step_days must be finite.")
        return value

    @model_validator(mode="after")
    def _tof_order(self) -> "PorkchopRequest":
        if self.max_tof_days <= self.min_tof_days:
            raise ValueError("max_tof_days must be greater than min_tof_days.")
        return self


class PorkchopCandidateModel(BaseModel):
    name: str
    key: str
    departure_utc: str
    arrival_utc: str
    tof_days: float
    c3_km2_s2: float
    earth_vinf_km_s: float
    mars_vinf_km_s: float
    departure_index: int
    arrival_index: int


class PorkchopResponse(BaseModel):
    departure_utc: list[str]
    arrival_utc: list[str]
    tof_days: list[list[float | None]]
    c3_km2_s2: list[list[float | None]]
    earth_vinf_km_s: list[list[float | None]]
    mars_vinf_km_s: list[list[float | None]]
    valid: list[list[bool]]
    status: list[list[str]]
    n_departure: int
    n_arrival: int
    n_potential: int
    n_lambert_success: int
    n_lambert_failed: int
    n_skipped_tof: int
    runtime_s: float
    step_days: float
    min_tof_days: float
    max_tof_days: float
    max_cells: int
    frame: str
    aberration_correction: str
    earth_target_id: int
    mars_target_id: int
    observer_id: int
    mu_km3_s2: float
    candidates: dict[str, PorkchopCandidateModel]
    model: str


class HealthResponse(BaseModel):
    status: str
    engine: str
    version: str
    physics_model: str
    frame: str
    earth_target: int
    earth_target_name: str
    mars_target: int
    mars_target_name: str
    observer: int
    observer_name: str
    aberration_correction: str
    kernels_loaded: bool
    kernel_detail: str | None = None
    max_porkchop_cells: int = MAX_PORKCHOP_CELLS


class ErrorBody(BaseModel):
    error: str
    detail: str


class ReferenceCaseResponse(BaseModel):
    label: str
    departure: str
    arrival: str
    nasa_published_c3_km2_s2: float
    nasa_source: str
    note: str
    transfer: TrajectoryResponse | None = None
    extra: dict[str, Any] | None = None
